<?php
/**
 * Plugin Name: AI Writer Drafts
 * Plugin URI: https://congcuseoai.com/
 * Description: Tạo bài viết AI với hỗ trợ nhiều nhà cung cấp (OpenAI, Claude, OpenAI-compatible) và lưu thành bản nháp tự động.
 * Version: 2.3
 * Author: Phạm Ngọc Tú
 * Author URI: https://congcuseoai.com/
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: ai-writer-drafts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define plugin constants.
define( 'AIWD_VERSION', '2.3' );
define( 'AIWD_PLUGIN_FILE', __FILE__ );
define( 'AIWD_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'AIWD_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Load plugin classes
 */
function aiwd_load_classes() {
	// Core classes.
	require_once AIWD_PLUGIN_DIR . 'includes/class-ai-provider-base.php';
	require_once AIWD_PLUGIN_DIR . 'includes/class-openai-provider.php';
	require_once AIWD_PLUGIN_DIR . 'includes/class-claude-provider.php';
	require_once AIWD_PLUGIN_DIR . 'includes/class-openai-compatible-provider.php';
	require_once AIWD_PLUGIN_DIR . 'includes/class-gemini-provider.php';
	require_once AIWD_PLUGIN_DIR . 'includes/class-prompt-builder.php';
	require_once AIWD_PLUGIN_DIR . 'includes/class-article-generator.php';

	// Admin pages.
	if ( is_admin() ) {
		require_once AIWD_PLUGIN_DIR . 'includes/admin/class-settings-page.php';
		require_once AIWD_PLUGIN_DIR . 'includes/admin/class-generator-page.php';
	}
}
add_action( 'plugins_loaded', 'aiwd_load_classes' );

/**
 * Register admin menus
 */
function aiwd_register_admin_menus() {
	// Main generator page under Posts menu.
	add_posts_page(
		__( 'AI Writer', 'ai-writer-drafts' ),
		__( 'AI Writer', 'ai-writer-drafts' ),
		'edit_posts',
		'ai-writer-drafts',
		array( 'AIWD_Generator_Page', 'render' ),
		10
	);

	// Settings page under Settings menu.
	add_options_page(
		__( 'AI Writer Settings', 'ai-writer-drafts' ),
		__( 'Cấu hình AI Writer', 'ai-writer-drafts' ),
		'manage_options',
		'ai-writer-settings',
		array( 'AIWD_Settings_Page', 'render' )
	);
}
add_action( 'admin_menu', 'aiwd_register_admin_menus' );

/**
 * Enqueue admin styles
 *
 * @param string $hook Current admin page hook.
 */
function aiwd_enqueue_admin_styles( $hook ) {
	// Only load on our plugin pages.
	if ( 'edit_page_ai-writer-drafts' !== $hook && 'settings_page_ai-writer-settings' !== $hook ) {
		return;
	}

	// Add custom inline styles.
	$custom_css = '
		.aiwd-form-table th {
			width: 200px;
			font-weight: 600;
		}
		.aiwd-form-table td {
			padding: 15px 10px;
		}
		.aiwd-form-table input[type="text"],
		.aiwd-form-table input[type="url"],
		.aiwd-form-table input[type="password"],
		.aiwd-form-table textarea,
		.aiwd-form-table select {
			font-size: 14px;
		}
		.aiwd-form-table .description {
			margin-top: 5px;
			font-style: italic;
		}
		#aiwd-content h1, #aiwd-content h2, #aiwd-content h3 {
			margin-top: 20px;
			margin-bottom: 10px;
		}
		#aiwd-content p {
			margin-bottom: 15px;
			line-height: 1.6;
		}
		#aiwd-content ul, #aiwd-content ol {
			margin-left: 20px;
			margin-bottom: 15px;
		}
		#aiwd-content li {
			margin-bottom: 8px;
			line-height: 1.6;
		}
		.button-hero {
			padding: 10px 20px !important;
			font-size: 16px !important;
			height: auto !important;
		}
	';
	wp_add_inline_style( 'wp-admin', $custom_css );
}
add_action( 'admin_enqueue_scripts', 'aiwd_enqueue_admin_styles' );

/**
 * Plugin activation hook
 */
function aiwd_activate_plugin() {
	// Set default options if not exist.
	if ( ! get_option( 'aiwd_active_provider' ) ) {
		add_option( 'aiwd_active_provider', 'openai' );
	}

	if ( ! get_option( 'aiwd_openai_model' ) ) {
		add_option( 'aiwd_openai_model', 'gpt-4o-mini' );
	}

	if ( ! get_option( 'aiwd_openai_temperature' ) ) {
		add_option( 'aiwd_openai_temperature', '0.7' );
	}

	if ( ! get_option( 'aiwd_claude_model' ) ) {
		add_option( 'aiwd_claude_model', 'claude-3-5-sonnet-20241022' );
	}

	if ( ! get_option( 'aiwd_claude_temperature' ) ) {
		add_option( 'aiwd_claude_temperature', '0.7' );
	}

	if ( ! get_option( 'aiwd_compatible_temperature' ) ) {
		add_option( 'aiwd_compatible_temperature', '0.7' );
	}

	if ( ! get_option( 'aiwd_gemini_model' ) ) {
		add_option( 'aiwd_gemini_model', 'gemini-2.5-flash' );
	}

	if ( ! get_option( 'aiwd_gemini_temperature' ) ) {
		add_option( 'aiwd_gemini_temperature', '0.7' );
	}
	
	// Brand settings defaults
	if ( ! get_option( 'aiwd_brand_name' ) ) {
		add_option( 'aiwd_brand_name', 'Công Cụ SEO AI' );
	}
	
	if ( ! get_option( 'aiwd_brand_description' ) ) {
		add_option( 'aiwd_brand_description', 'Tối ưu hóa mọi khía cạnh SEO của bạn với sức mạnh của Trí tuệ nhân tạo. Nhanh chóng, chính xác và hiệu quả.' );
	}
	
	if ( ! get_option( 'aiwd_brand_website' ) ) {
		add_option( 'aiwd_brand_website', 'congcuseoai.com' );
	}
	
	if ( ! get_option( 'aiwd_brand_contact_name' ) ) {
		add_option( 'aiwd_brand_contact_name', 'Phạm Ngọc Tú' );
	}
	
	if ( ! get_option( 'aiwd_brand_contact_phone' ) ) {
		add_option( 'aiwd_brand_contact_phone', '0896009111' );
	}
}
register_activation_hook( __FILE__, 'aiwd_activate_plugin' );

/**
 * Add settings link on plugins page
 *
 * @param array $links Plugin action links.
 * @return array
 */
function aiwd_add_settings_link( $links ) {
	$settings_link  = '<a href="' . admin_url( 'options-general.php?page=ai-writer-settings' ) . '">' . __( 'Cài đặt', 'ai-writer-drafts' ) . '</a>';
	$generator_link = '<a href="' . admin_url( 'edit.php?page=ai-writer-drafts' ) . '" style="font-weight:bold;color:#00a32a">' . __( 'Tạo bài viết', 'ai-writer-drafts' ) . '</a>';
	array_unshift( $links, $generator_link, $settings_link );
	return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'aiwd_add_settings_link' );

/**
 * Add admin notice if no API key is configured
 */
function aiwd_admin_notice_no_api_key() {
	$screen = get_current_screen();

	// Don't show on settings page.
	if ( $screen && 'settings_page_ai-writer-settings' === $screen->id ) {
		return;
	}

	$active_provider = get_option( 'aiwd_active_provider', 'openai' );
	$api_key         = '';

	switch ( $active_provider ) {
		case 'openai':
			$api_key = get_option( 'aiwd_openai_api_key', '' );
			break;
		case 'claude':
			$api_key = get_option( 'aiwd_claude_api_key', '' );
			break;
		case 'openai_compatible':
			$api_key = get_option( 'aiwd_compatible_api_key', '' );
			break;
		case 'gemini':
			$api_key = get_option( 'aiwd_gemini_api_key', '' );
			break;
	}

	if ( empty( $api_key ) && current_user_can( 'manage_options' ) ) {
		?>
		<div class="notice notice-warning">
			<p>
				<strong><?php esc_html_e( 'AI Writer:', 'ai-writer-drafts' ); ?></strong>
				<?php esc_html_e( 'Vui lòng cấu hình API key để sử dụng plugin.', 'ai-writer-drafts' ); ?>
				<a href="<?php echo esc_url( admin_url( 'options-general.php?page=ai-writer-settings' ) ); ?>" class="button button-small" style="margin-left:10px">
					<?php esc_html_e( 'Cài đặt ngay', 'ai-writer-drafts' ); ?>
				</a>
			</p>
		</div>
		<?php
	}
}
add_action( 'admin_notices', 'aiwd_admin_notice_no_api_key' );

/**
 * Register AJAX handler for article generation
 */
add_action( 'wp_ajax_aiwd_generate_article', array( 'AIWD_Generator_Page', 'handle_ajax_request' ) );