<?php
/**
 * Claude (Anthropic) Provider Implementation
 *
 * @package AI_Writer_Drafts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once plugin_dir_path( __FILE__ ) . 'class-ai-provider-base.php';

class AIWD_Claude_Provider extends AIWD_AI_Provider_Base {
    
    /**
     * Provider name
     *
     * @var string
     */
    protected $provider_name = 'Claude';
    
    /**
     * API endpoint
     *
     * @var string
     */
    protected $api_endpoint = 'https://api.anthropic.com/v1/messages';
    
    /**
     * API version
     *
     * @var string
     */
    protected $api_version = '2023-06-01';
    
    /**
     * Constructor
     *
     * @param array $config Configuration array.
     */
    public function __construct( $config = array() ) {
        parent::__construct( $config );
        
        // Default model
        if ( empty( $this->model ) ) {
            $this->model = 'claude-3-5-sonnet-20241022';
        }
    }
    
    /**
     * Generate article content
     *
     * @param string $prompt The prompt to generate content from.
     * @return array
     */
    public function generate_content( $prompt ) {
        if ( ! $this->validate_api_key() ) {
            return array(
                'success' => false,
                'error'   => __( 'API key không hợp lệ', 'ai-writer-drafts' ),
            );
        }
        
        $headers = array(
            'Content-Type'      => 'application/json',
            'x-api-key'         => $this->api_key,
            'anthropic-version' => $this->api_version,
        );
        
        // Parse combined prompt to split SYSTEM and USER
        $system_content = '';
        $user_content = $prompt;
        
        if ( strpos( $prompt, 'SYSTEM:' ) !== false && strpos( $prompt, 'USER:' ) !== false ) {
            $parts = explode( 'USER:', $prompt, 2 );
            if ( count( $parts ) === 2 ) {
                $system_content = trim( str_replace( 'SYSTEM:', '', $parts[0] ) );
                $user_content = trim( $parts[1] );
            }
        }
        
        $body = array(
            'model'       => $this->model,
            'temperature' => $this->temperature,
            'messages'    => array(
                array(
                    'role'    => 'user',
                    'content' => $user_content,
                ),
            ),
        );
        
        // Add system prompt if available
        if ( ! empty( $system_content ) ) {
            $body['system'] = $system_content;
        }
        
        $response = $this->make_request( $this->api_endpoint, $body, $headers, 180 );
        
        if ( is_wp_error( $response ) ) {
            return array(
                'success' => false,
                'error'   => $this->parse_error( $response ),
            );
        }
        
        $code = wp_remote_retrieve_response_code( $response );
        if ( $code !== 200 ) {
            return array(
                'success' => false,
                'error'   => $this->parse_error( $response ),
            );
        }
        
        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );
        
        if ( ! isset( $data['content'][0]['text'] ) ) {
            return array(
                'success' => false,
                'error'   => __( 'Không nhận được nội dung từ API', 'ai-writer-drafts' ),
            );
        }
        
        return array(
            'success' => true,
            'content' => $data['content'][0]['text'],
        );
    }
    
    /**
     * Test API connection
     *
     * @return array
     */
    public function test_connection() {
        if ( ! $this->validate_api_key() ) {
            return array(
                'success' => false,
                'message' => __( 'API key không hợp lệ', 'ai-writer-drafts' ),
            );
        }
        
        $headers = array(
            'Content-Type'      => 'application/json',
            'x-api-key'         => $this->api_key,
            'anthropic-version' => $this->api_version,
        );
        
        $body = array(
            'model'      => $this->model,
            'messages'   => array(
                array(
                    'role'    => 'user',
                    'content' => 'Hello',
                ),
            ),
        );
        
        $response = $this->make_request( $this->api_endpoint, $body, $headers, 30 );
        
        if ( is_wp_error( $response ) ) {
            return array(
                'success' => false,
                'message' => $this->parse_error( $response ),
            );
        }
        
        $code = wp_remote_retrieve_response_code( $response );
        if ( $code !== 200 ) {
            return array(
                'success' => false,
                'message' => $this->parse_error( $response ),
            );
        }
        
        return array(
            'success' => true,
            'message' => __( 'Kết nối thành công với Claude!', 'ai-writer-drafts' ),
        );
    }
}
