<?php
/**
 * Prompt Builder for AI Content Generation (SEO E-E-A-T, Topic Cluster, Links, Anti-Cliché & Smart CTA)
 *
 * @package AI_Writer_Drafts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AIWD_Prompt_Builder {
    
    /**
     * Build prompt from article parameters
     *
     * @param array $params Article parameters.
     * @return string
     */
    public static function build_article_prompt( $params ) {$domain             = isset( $params['domain'] ) ?$params['domain'] : 'Tổng hợp';
        $audience           = isset( $params['audience'] ) ?$params['audience'] : 'Người đọc phổ thông';
        $word_count         = isset( $params['word_count'] ) ? intval( $params['word_count'] ) : 2000;
        $topic              = isset( $params['topic'] ) ?$params['topic'] : '';
        $main_keyword       = isset($params['main_keyword'] ) ? $params['main_keyword'] : '';$secondary_keywords = isset( $params['secondary_keywords'] ) ?$params['secondary_keywords'] : '';
        $content_gap        = isset($params['content_gap'] ) ? $params['content_gap'] : '';$structure          = isset( $params['structure'] ) ?$params['structure'] : 'Bài viết chuẩn SEO';
        $style              = isset( $params['style'] ) ?$params['style'] : 'Chuyên nghiệp và đáng tin cậy';
        $intent             = isset( $params['intent'] ) ?$params['intent'] : 'Thông tin (Informational)';

        // Lấy thông tin thương hiệu từ Database (Người dùng tự cấu hình trong Cài đặt)
        $brand_name  = get_option( 'aiwd_brand_name', '' );
        $brand_phone = get_option( 'aiwd_brand_contact_phone', '' );$brand_web   = get_option( 'aiwd_brand_website', '' );

        // 1. BUILD SYSTEM PROMPT - ĐỊNH HÌNH CHUYÊN GIA
        $system_prompt = "Bạn là một Chuyên gia SEO Master, một Copywriter thực chiến xuất sắc trong lĩnh vực '{$domain}'.\n";
        $system_prompt .= "Nhiệm vụ của bạn là tạo ra một bài viết chuẩn SEO Top 1 Google, mang lại giá trị thực tế cao nhất cho độc giả là {$audience}.\n";
        
        // 2. BUILD USER PROMPT - THÔNG TIN CƠ BẢN
        $user_prompt = "# THÔNG TIN BÀI VIẾT:\n";
        $user_prompt .= "- Chủ đề chính: {$topic}.\n";
        $user_prompt .= "- Từ khóa chính (Keyword): {$main_keyword}.\n";
        
        if ( ! empty( $secondary_keywords ) ) {
            $user_prompt .= "- Từ khóa phụ (LSI Keywords): {$secondary_keywords}.\n";
        }
        
        $user_prompt .= "- Search Intent (Ý định tìm kiếm): {$intent}.\n";
        $user_prompt .= "- Độ dài mục tiêu: Khoảng {$word_count} từ.\n\n";
        
        if ( ! empty( $content_gap ) ) {$user_prompt .= "# HƯỚNG DẪN ĐẶC BIỆT TỪ NGƯỜI DÙNG:\n";
            $user_prompt .= "*{$content_gap}*\n\n";
        }

        // 3. TỐI ƯU CỤM CHỦ ĐỀ & CHỐNG TRÙNG LẶP (ANTI-CANNIBALIZATION)
        if ( ! empty( $params['internal_links_data'] ) ) {$titles_list = "";
            foreach ( $params['internal_links_data'] as$link_item ) {
                $titles_list .= "- " . $link_item['title'] . "\n";
            }
            $user_prompt .= "# CHIẾN LƯỢC NỘI DUNG (CHỐNG TRÙNG LẶP & ĂN THỊT TỪ KHÓA):\n";
            $user_prompt .= "Website của tôi ĐÃ CÓ SẴN các bài viết với những tiêu đề sau:\n{$titles_list}\n";
            $user_prompt .= "YÊU CẦU BẮT BUỘC: \n";
            $user_prompt .= "- KHÔNG ĐƯỢC lặp lại các kiến thức cơ bản hoặc nội dung mang tính định nghĩa chung chung đã có ở các bài viết trên.\n";
            $user_prompt .= "- Bài viết này ('{$topic}') phải là một MẢNH GHÉP CHUYÊN SÂU. Phải đi thẳng vào góc nhìn ngách, chi tiết và khác biệt hoàn toàn.\n";
            $user_prompt .= "- Ví dụ: Nếu website đã có bài 'Tổng quan/Tư vấn', thì bài mới về 'Chi phí/Thời gian' chỉ tập trung 100% phân tích số liệu, bảng giá, tiến độ... tuyệt đối không tốn chữ để giải thích lại khái niệm cơ bản.\n\n";
        }

        // 4. YÊU CẦU SEO ON-PAGE VÀ BỐ CỤC THÔNG MINH
        $user_prompt .= "# YÊU CẦU SEO & BỐ CỤC (QUAN TRỌNG):\n";
        $user_prompt .= "- Cấu trúc bài viết: {$structure}.\n";
        $user_prompt .= "- Mật độ từ khóa: Phân bổ từ khóa chính ở đoạn Sapo đầu tiên, rải đều tự nhiên ở thân bài, và xuất hiện ở kết luận. Sử dụng từ đồng nghĩa để tránh nhồi nhét.\n";
        $user_prompt .= "- Bố cục Heading: Sử dụng các thẻ (H2, H3, H4) logic. KHÔNG bỏ sót cấp độ nào. TUYỆT ĐỐI KHÔNG dùng H1 trong nội dung.\n";
        $user_prompt .= "- Khả năng đọc: Mỗi đoạn văn ngắn gọn (tối đa 3-4 câu/đoạn). Mỗi thẻ H2 nên chứa 200-400 từ phân tích sâu sắc.\n";
        $user_prompt .= "- Đa dạng định dạng: BẮT BUỘC có ít nhất 1 Bảng biểu (Table) tóm tắt, so sánh. Sử dụng danh sách (<ul>, <ol>) và in đậm (<strong>) các từ khóa quan trọng để tối ưu Featured Snippet.\n";
        $user_prompt .= "- FAQ: Thêm một mục FAQ (Câu hỏi thường gặp) ở phần gần cuối bài.\n\n";

        // 5. TIÊU CHUẨN E-E-A-T VÀ PHONG CÁCH VIẾT
        $user_prompt .= "# TIÊU CHUẨN E-E-A-T & PHONG CÁCH (NÓI KHÔNG VỚI RẬP KHUÔN):\n";
        $user_prompt .= "- Phong cách: {$style}.\n";
        $user_prompt .= "- Viết như một CHUYÊN GIA THỰC TẾ đang chia sẻ trải nghiệm thật, xưng 'tôi' hoặc 'chúng tôi' để tăng tính gần gũi.\n";
        $user_prompt .= "- Đưa ra các 'Lời khuyên chuyên gia' (Expert Tips) hoặc 'Tóm tắt ý chính' (Key Takeaways) ở cuối mỗi phần H2.\n";
        $user_prompt .= "- TUYỆT ĐỐI TRÁNH XA lối viết văn hoa sáo rỗng của AI như: 'không thể phủ nhận', 'sự thật là', 'tuy nhiên', 'như chúng ta đã biết', 'chìa khóa nằm ở'. Hãy dùng văn phong trực diện, tự nhiên.\n\n";

        // 6. MỞ BÀI (SAPO) - ÉP BUỘC BẮT ĐẦU BẰNG TIÊU ĐỀ
        $user_prompt .= "# QUY TẮC MỞ BÀI (KỶ LUẬT SẮT - NẾU LÀM SAI SẼ BỊ HỦY BÀI):\n";
        $user_prompt .= "- CÚ PHÁP BẮT BUỘC: Những từ đầu tiên của bài viết PHẢI LÀ chính xác cụm từ: \"{$topic}\".\n";
        $user_prompt .= "- TUYỆT ĐỐI KHÔNG ĐƯỢC đặt bất kỳ từ ngữ nào (như 'Trong bối cảnh', 'Ngày nay', 'Hiện nay', 'Chào bạn') trước cụm từ \"{$topic}\".\n";
        $user_prompt .= "- Ví dụ đúng: \"<p>{$topic} đang là giải pháp hàng đầu giúp doanh nghiệp...\"\n";
        $user_prompt .= "- Ví dụ SAI (Cấm dùng): \"<p>Trong bối cảnh hiện nay, {$topic} đang là...\"\n";
        $user_prompt .= "- Viết 1-2 đoạn văn (thẻ <p>) ngắn gọn để giữ chân độc giả bằng công thức PAS (Problem - Agitate - Solution). Khơi gợi nỗi đau ngay lập tức.\n";
        $user_prompt .= "- LƯU Ý KỸ THUẬT: Chữ đầu tiên của bài viết PHẢI NẰM TRONG thẻ <p>. Không được phép xuất hiện thẻ Heading (H1, H2...) ở phần mở bài.\n\n";

        // Thêm hướng dẫn chi tiết theo cấu trúc bài
        $user_prompt .= self::get_structure_instructions($structure );

        // 7. KẾT LUẬN & CALL-TO-ACTION (CTA)
        $user_prompt .= "\n# KẾT LUẬN & CALL-TO-ACTION (CTA):\n";
        $user_prompt .= "- Viết một thẻ H2 cho phần Kết luận để tóm tắt lại giá trị bài viết.\n";
        if ( ! empty( $brand_name ) ) {
            $user_prompt .= "- Ngay dưới phần kết luận, hãy chèn một lời kêu gọi hành động (CTA) thật khéo léo và tự nhiên, mời độc giả liên hệ với '{$brand_name}' nếu họ cần tư vấn hoặc hỗ trợ.\n";
            if ( ! empty( $brand_phone ) ) $user_prompt .= "- Nhắc đến Số điện thoại/Zalo liên hệ: {$brand_phone}.\n";
            if ( ! empty( $brand_web ) ) $user_prompt .= "- Nhắc đến Website: {$brand_web}.\n";
            $user_prompt .= "- LƯU Ý: Lời kêu gọi phải tinh tế, mang tính chất chuyên gia muốn giúp đỡ, tuyệt đối không dùng ngôn từ chèo kéo, quảng cáo rẻ tiền.\n";
        }

        // 8. INTERNAL LINKS AUTOMATION (KỶ LUẬT SẮT)
        if ( ! empty( $params['enable_internal_links'] ) && ! empty( $params['internal_links_data'] ) ) {$max_links = isset( $params['max_internal_links'] ) ?$params['max_internal_links'] : 3;
            $links_list = "";
            foreach ( $params['internal_links_data'] as $link_item ) {$links_list .= "- Tên bài: \"" . $link_item['title'] . "\" \vert{} URL: " . $link_item['url'] . "\n";
            }
            $user_prompt .= "\n# LỆNH BẮT BUỘC CHÈN INTERNAL LINK:\n";
            $user_prompt .= "Dưới đây là danh sách bài viết trên website của tôi:\n{$links_list}\n";
            $user_prompt .= "NHIỆM VỤ CỦA BẠN: Phải chọn ra {$max_links} bài viết trong danh sách trên để lồng ghép tự nhiên vào bài mới.\n";
            $user_prompt .= "- CÚ PHÁP CHUẨN: `<a href=\"URL bài viết\" target=\"_blank\">Anchor text tự nhiên</a>`.\n";
            $user_prompt .= "- KHÔNG chèn dồn dập tại một chỗ. TUYỆT ĐỐI KHÔNG được trả về kết quả nếu thiếu các thẻ <a> này!\n";
        }

        // 9. EXTERNAL LINKS (Trích dẫn uy tín)
        if ( ! empty( $params['seo_external_links'] ) ) {$user_prompt .= "\n# EXTERNAL LINKS (THẨM QUYỀN E-E-A-T):\n";
            $user_prompt .= "- Chủ động chèn 1-2 liên kết ngoài (External link) trỏ đến các nguồn thông tin uy tín (như Wikipedia, tổ chức chính phủ, báo cáo toàn cầu).\n";
            $user_prompt .= "- Đảm bảo định dạng HTML: `<a href=\"URL\" target=\"_blank\" rel=\"nofollow\">Anchor Text</a>`.\n";
        }

        // 10. TỐI ƯU HÌNH ẢNH (Image Alt)
        if ( ! empty( $params['seo_image_alt'] ) ) {$user_prompt .= "\n# TỐI ƯU HÌNH ẢNH:\n";
            $user_prompt .= "- Đề xuất 2-3 vị trí cần chèn ảnh minh họa. Tại mỗi vị trí, hãy viết rõ mô tả bức ảnh và tạo thẻ Alt chứa từ khóa.\n";
            $user_prompt .= "- Cú pháp bắt buộc: `<em>[Gợi ý hình ảnh: ... | Alt text: ...]</em>`.\n";
        }

        // 11. THẺ META (Cuối bài)
        if ( ! empty( $params['seo_meta_tags'] ) ) {$user_prompt .= "\n# THẺ META TAGS (BẮT BUỘC Ở DƯỚI CÙNG CỦA BÀI VIẾT):\n";
            $user_prompt .= "- Cung cấp Meta Title (Dưới 65 ký tự) và Meta Description (150-160 ký tự, hấp dẫn, chứa từ khóa chính).\n";
            $user_prompt .= "- Định dạng bằng HTML: `<div style=\"background:#f1f1f1; padding:15px; border-radius:5px; margin-top:30px;\"><strong>Meta Title:</strong> [Nội dung]<br><br><strong>Meta Description:</strong> [Nội dung]</div>`.\n";
        }

        // 12. KẾT QUẢ ĐẦU RA (ĐỊNH DẠNG NGHIÊM NGẶT)
        $user_prompt .= "\n# QUY TẮC ĐỊNH DẠNG OUTPUT THUẦN TÚY:\n";
        $user_prompt .= "- CẤM SỬ DỤNG cấu trúc Markdown (*, #, **, __, -, >, ```). CHỈ SỬ DỤNG HTML THUẦN.\n";
        $user_prompt .= "- Các thẻ hợp lệ: <p>, <h2>, <h3>, <h4>, <strong>, <em>, <ul>, <ol>, <li>, <table>, <tr>, <td>, <th>, <a>, <div>, <br>.\n";
        $user_prompt .= "- TUYỆT ĐỐI KHÔNG thêm bất kỳ lời chào hỏi (như 'Dưới đây là bài viết...'), chú thích hay văn bản thừa thãi nào ngoài nội dung chính của bài.\n";
        
        return "SYSTEM:\n{$system_prompt}\n\nUSER:\n{$user_prompt}";
    }
    
    /**
     * Get structure-specific instructions
     *
     * @param string $structure Article structure.
     * @return string
     */
    private static function get_structure_instructions( $structure ) {
        $instructions = "\n# YÊU CẦU RIÊNG CHO ĐỊNH DẠNG: {$structure}\n";
        
        switch ( $structure ) {
            case 'Bài viết dạng danh sách (Listicle)':
                $instructions .= "- Mỗi mục trong danh sách phải là một heading (H2 hoặc H3).\n";
                $instructions .= "- Đánh số thứ tự hấp dẫn ở tiêu đề (Ví dụ: 1. Tuyệt chiêu..., 2. Bí quyết...).\n";
                break;
                
            case 'Bài viết hướng dẫn (How-to Guide)':
                $instructions .= "- Chia thành các 'Bước' rõ ràng theo trình tự thực hiện.\n";
                $instructions .= "- Mỗi bước là một thẻ H2/H3. Cung cấp chi tiết 'Tại sao phải làm' và 'Làm như thế nào'.\n";
                $instructions .= "- Nêu bật các cảnh báo hoặc mẹo (Tips) ở từng bước.\n";
                break;
                
            case 'Bài viết đánh giá (Review Article)':
                $instructions .= "- Đánh giá khách quan, có ưu nhược điểm (Pros & Cons) trình bày bằng HTML Table.\n";
                $instructions .= "- Đưa ra kết luận rõ ràng (sản phẩm/dịch vụ này phù hợp với ai nhất).\n";
                break;
                
            case 'Bài viết so sánh (Comparison Article)':
                $instructions .= "- Bắt buộc sử dụng Bảng (Table) so sánh trực quan các tính năng, thông số giữa các đối tượng.\n";
                $instructions .= "- Phân tích ưu/nhược điểm từng bên và đưa ra lời khuyên lựa chọn.\n";
                break;
                
            default:
                // Bài viết chuẩn SEO thông thường
                $instructions .= "- Phần thân bài đi sâu vào giải quyết ý định tìm kiếm, giải thích cặn kẽ thuật ngữ.\n";
                break;
        }
        
        return $instructions;
    }
}
