<?php
/**
 * Base abstract class for AI providers
 *
 * @package AI_Writer_Drafts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

abstract class AIWD_AI_Provider_Base {
    
    /**
     * Provider name
     *
     * @var string
     */
    protected $provider_name = '';
    
    /**
     * API key
     *
     * @var string
     */
    protected $api_key = '';
    
    /**
     * API endpoint
     *
     * @var string
     */
    protected $api_endpoint = '';
    
    /**
     * Model name
     *
     * @var string
     */
    protected $model = '';
    
    /**
     * Temperature setting
     *
     * @var float
     */
    protected $temperature = 0.7;
    
    /**
     * Constructor
     *
     * @param array $config Configuration array.
     */
    public function __construct( $config = array() ) {
        if ( isset( $config['api_key'] ) ) {
            $this->api_key = $config['api_key'];
        }
        if ( isset( $config['model'] ) ) {
            $this->model = $config['model'];
        }
        if ( isset( $config['temperature'] ) ) {
            $this->temperature = floatval( $config['temperature'] );
        }
    }
    
    /**
     * Generate article content
     *
     * @param string $prompt The prompt to generate content from.
     * @return array {
     *     @type bool   $success Whether the request was successful.
     *     @type string $content The generated content.
     *     @type string $error   Error message if failed.
     * }
     */
    abstract public function generate_content( $prompt );
    
    /**
     * Test API connection
     *
     * @return array {
     *     @type bool   $success Whether the connection was successful.
     *     @type string $message Success or error message.
     * }
     */
    abstract public function test_connection();
    
    /**
     * Get provider name
     *
     * @return string
     */
    public function get_provider_name() {
        return $this->provider_name;
    }
    
    /**
     * Make HTTP request to API
     *
     * @param string $url     API endpoint URL.
     * @param array  $body    Request body.
     * @param array  $headers Request headers.
     * @param int    $timeout Request timeout in seconds.
     * @return array|WP_Error Response or error.
     */
    protected function make_request( $url, $body, $headers = array(), $timeout = 120 ) {
        // Add default headers to bypass some WAFs
        if ( ! isset( $headers['User-Agent'] ) ) {
            $headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
        }
        if ( ! isset( $headers['Accept'] ) ) {
            $headers['Accept'] = 'application/json';
        }

        $args = array(
            'method'  => 'POST',
            'headers' => $headers,
            'body'    => wp_json_encode( $body ),
            'timeout' => $timeout,
        );
        
        return wp_remote_post( $url, $args );
    }
    
    /**
     * Parse error from response
     *
     * @param WP_Error|array $response The response.
     * @return string Error message.
     */
    protected function parse_error( $response ) {
        // Handle WordPress Error object
        if ( is_wp_error( $response ) ) {
            $error_message = $response->get_error_message();
            $error_code = $response->get_error_code();
            return sprintf( 
                /* translators: %1$s: error code, %2$s: error message */
                __( '[Lỗi %1$s] %2$s', 'ai-writer-drafts' ), 
                $error_code, 
                $error_message 
            );
        }
        
        // Get response body and code
        $body = wp_remote_retrieve_body( $response );
        $code = wp_remote_retrieve_response_code( $response );
        $data = json_decode( $body, true );
        
        // Try to extract detailed error from API response
        $error_message = '';
        $error_type = '';
        $error_code = '';
        
        if ( is_array( $data ) ) {
            // OpenAI/Compatible format
            if ( isset( $data['error'] ) ) {
                if ( is_array( $data['error'] ) ) {
                    $error_message = isset( $data['error']['message'] ) ? $data['error']['message'] : '';
                    $error_type = isset( $data['error']['type'] ) ? $data['error']['type'] : '';
                    $error_code = isset( $data['error']['code'] ) ? $data['error']['code'] : '';
                } else {
                    $error_message = $data['error'];
                }
            }
            
            // Gemini format
            if ( isset( $data['error']['message'] ) ) {
                $error_message = $data['error']['message'];
                $error_code = isset( $data['error']['code'] ) ? $data['error']['code'] : '';
                $error_type = isset( $data['error']['status'] ) ? $data['error']['status'] : '';
            }
        }
        
        // Build detailed error message
        $detailed_error = '';
        
        if ( ! empty( $error_message ) ) {
            $detailed_error = $error_message;
            
            if ( ! empty( $error_type ) || ! empty( $error_code ) ) {
                $details = array();
                if ( ! empty( $error_type ) ) {
                    $details[] = sprintf( __( 'Loại: %s', 'ai-writer-drafts' ), $error_type );
                }
                if ( ! empty( $error_code ) ) {
                    $details[] = sprintf( __( 'Mã: %s', 'ai-writer-drafts' ), $error_code );
                }
                $detailed_error .= ' (' . implode( ', ', $details ) . ')';
            }
        } else {
            // Fallback to generic HTTP error
            $detailed_error = sprintf(
                /* translators: %d: HTTP status code */
                __( 'Lỗi HTTP %d', 'ai-writer-drafts' ),
                $code
            );
            
            if ( ! empty( $body ) && strlen( $body ) < 200 ) {
                $detailed_error .= ': ' . $body;
            }
        }
        
        return sprintf(
            /* translators: %s: detailed error message */
            __( 'Lỗi API: %s', 'ai-writer-drafts' ),
            $detailed_error
        );
    }
    
    /**
     * Validate API key format
     *
     * @return bool
     */
    protected function validate_api_key() {
        return ! empty( $this->api_key ) && strlen( $this->api_key ) > 10;
    }
}
