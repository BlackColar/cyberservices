<?php
/**
 * OpenAI-Compatible API Provider Implementation
 *
 * @package AI_Writer_Drafts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once plugin_dir_path( __FILE__ ) . 'class-ai-provider-base.php';

class AIWD_OpenAI_Compatible_Provider extends AIWD_AI_Provider_Base {
    
    /**
     * Provider name
     *
     * @var string
     */
    protected $provider_name = 'OpenAI Compatible';
    
    /**
     * Constructor
     *
     * @param array $config Configuration array.
     */
    public function __construct( $config = array() ) {
        parent::__construct( $config );
        
        // Allow custom endpoint
        if ( isset( $config['endpoint'] ) ) {
            $this->api_endpoint = $config['endpoint'];
        }
        
        // Default model
        if ( empty( $this->model ) ) {
            $this->model = 'gpt-3.5-turbo';
        }
    }
    
    /**
     * Generate article content
     *
     * @param string $prompt The prompt to generate content from.
     * @return array
     */
    public function generate_content( $prompt ) {
        if ( empty( $this->api_endpoint ) ) {
            return array(
                'success' => false,
                'error'   => __( 'Endpoint API chưa được cấu hình', 'ai-writer-drafts' ),
            );
        }
        
        if ( ! $this->validate_api_key() ) {
            return array(
                'success' => false,
                'error'   => __( 'API key không hợp lệ', 'ai-writer-drafts' ),
            );
        }
        
        $headers = array(
            'Content-Type'  => 'application/json',
            'Authorization' => 'Bearer ' . $this->api_key,
        );
        
        // Parse combined prompt to split SYSTEM and USER
        $system_content = '';
        $user_content = $prompt;
        
        if ( strpos( $prompt, 'SYSTEM:' ) !== false && strpos( $prompt, 'USER:' ) !== false ) {
            $parts = explode( 'USER:', $prompt, 2 );
            if ( count( $parts ) === 2 ) {
                $system_content = trim( str_replace( 'SYSTEM:', '', $parts[0] ) );
                $user_content = trim( $parts[1] );
            }
        }
        
        $messages = array();
        
        if ( ! empty( $system_content ) ) {
            $messages[] = array(
                'role'    => 'system',
                'content' => $system_content,
            );
        }
        
        $messages[] = array(
            'role'    => 'user',
            'content' => $user_content,
        );
        
        $body = array(
            'model'       => $this->model,
            'messages'    => $messages,
            'temperature' => $this->temperature,
        );
        
        $response = $this->make_request( $this->api_endpoint, $body, $headers, 180 );
        
        if ( is_wp_error( $response ) ) {
            return array(
                'success' => false,
                'error'   => $this->parse_error( $response ),
            );
        }
        
        $code = wp_remote_retrieve_response_code( $response );
        if ( $code !== 200 ) {
            return array(
                'success' => false,
                'error'   => $this->parse_error( $response ),
            );
        }
        
        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );
        
        if ( ! isset( $data['choices'][0]['message']['content'] ) ) {
            return array(
                'success' => false,
                'error'   => __( 'Không nhận được nội dung từ API', 'ai-writer-drafts' ),
            );
        }
        
        return array(
            'success' => true,
            'content' => $data['choices'][0]['message']['content'],
        );
    }
    
    /**
     * Test API connection
     *
     * @return array
     */
    public function test_connection() {
        if ( empty( $this->api_endpoint ) ) {
            return array(
                'success' => false,
                'message' => __( 'Endpoint API chưa được cấu hình', 'ai-writer-drafts' ),
            );
        }
        
        if ( ! $this->validate_api_key() ) {
            return array(
                'success' => false,
                'message' => __( 'API key không hợp lệ', 'ai-writer-drafts' ),
            );
        }
        
        $headers = array(
            'Content-Type'  => 'application/json',
            'Authorization' => 'Bearer ' . $this->api_key,
        );
        
        $body = array(
            'model'      => $this->model,
            'messages'   => array(
                array(
                    'role'    => 'user',
                    'content' => 'Hello',
                ),
            ),
        );
        
        $response = $this->make_request( $this->api_endpoint, $body, $headers, 30 );
        
        if ( is_wp_error( $response ) ) {
            return array(
                'success' => false,
                'message' => $this->parse_error( $response ),
            );
        }
        
        $code = wp_remote_retrieve_response_code( $response );
        if ( $code !== 200 ) {
            return array(
                'success' => false,
                'message' => $this->parse_error( $response ),
            );
        }
        
        return array(
            'success' => true,
            'message' => __( 'Kết nối thành công với API!', 'ai-writer-drafts' ),
        );
    }
}
