<?php
/**
 * Article Generator Admin Page
 *
 * @package AI_Writer_Drafts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once plugin_dir_path( dirname( __FILE__ ) ) . 'class-article-generator.php';

class AIWD_Generator_Page {
    
    /**
     * Render generator page
     */
    public static function render() {
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_die( esc_html__( 'Bạn không có quyền truy cập trang này.', 'ai-writer-drafts' ) );
        }
        
        $active_provider = get_option( 'aiwd_active_provider', 'openai' );
        $provider_names  = array(
            'openai'            => 'OpenAI',
            'claude'            => 'Claude',
            'openai_compatible' => 'Tương Thích OpenAI',
            'gemini'            => 'Google Gemini',
        );
        $provider_display = isset( $provider_names[ $active_provider ] ) ? $provider_names[ $active_provider ] : $active_provider;
        
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline"><?php esc_html_e( 'AI Writer - Tạo Bài Viết SEO', 'ai-writer-drafts' ); ?></h1>
            <hr class="wp-header-end">
            
            <div class="notice notice-info inline" style="margin-top: 15px;">
                <p>
                    <strong><?php esc_html_e( 'Mô hình AI đang kết nối:', 'ai-writer-drafts' ); ?></strong> 
                    <span style="color: #2271b1; font-weight: bold;"><?php echo esc_html( $provider_display ); ?></span>
                    &nbsp;|&nbsp;
                    <a href="<?php echo esc_url( admin_url( 'options-general.php?page=ai-writer-settings' ) ); ?>">
                        <?php esc_html_e( 'Cấu hình API Key', 'ai-writer-drafts' ); ?>
                    </a>
                </p>
            </div>
            
            <div id="aiwd-message-container"></div>
            
            <div class="aiwd-layout-container" style="display: flex; flex-wrap: wrap; gap: 20px; margin-top: 20px;">
                
                <div class="aiwd-left-column" style="flex: 1; min-width: 350px; max-width: 100%;">
                    <div class="postbox" style="padding: 20px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                        <h2 class="hndle" style="margin-top: 0; border-bottom: 1px solid #f0f0f0; padding-bottom: 10px;"><?php esc_html_e( 'Thông tin bài viết', 'ai-writer-drafts' ); ?></h2>
                        
                        <form id="aiwd-form" method="post" action="">
                            <?php wp_nonce_field( 'aiwd_generate_article', 'aiwd_nonce' ); ?>
                            <input type="hidden" name="action" value="aiwd_generate_article" />
                            
                            <table class="form-table" role="presentation" style="margin-top: 10px;">
                                <tbody>
                                    <tr>
                                        <th scope="row">
                                            <label for="topic"><?php esc_html_e( 'Chủ đề bài viết', 'ai-writer-drafts' ); ?> <span style="color:#d63638">*</span></label>
                                        </th>
                                        <td>
                                            <input name="topic" id="topic" type="text" class="large-text" required
                                                   placeholder="VD: 10 cách tối ưu SEO On-page hiệu quả cho website" />
                                        </td>
                                    </tr>
                                    
                                    <tr>
                                        <th scope="row">
                                            <label for="mainKeyword"><?php esc_html_e( 'Từ khóa chính', 'ai-writer-drafts' ); ?> <span style="color:#d63638">*</span></label>
                                        </th>
                                        <td>
                                            <input name="mainKeyword" id="mainKeyword" type="text" class="regular-text" required
                                                   placeholder="VD: tối ưu SEO On-page" />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th scope="row">
                                            <label for="wordCount"><?php esc_html_e( 'Số từ dự kiến', 'ai-writer-drafts' ); ?></label>
                                        </th>
                                        <td>
                                            <select name="wordCount" id="wordCount">
                                                <option value="1000">1000 từ</option>
                                                <option value="1500">1500 từ</option>
                                                <option value="2000" selected>2000 từ</option>
                                                <option value="2500">2500 từ</option>
                                                <option value="3000">3000 từ</option>
                                            </select>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>

                            <!-- SECTION: TỰ ĐỘNG CHÈN INTERNAL LINK -->
                            <div style="margin-top: 15px; border: 1px solid #c3c4c7; border-radius: 6px; background: #f6f7f7; padding: 15px;">
                                <h3 style="margin-top: 0; margin-bottom: 10px; font-size: 14px; display: flex; align-items: center;">
                                    <span class="dashicons dashicons-admin-links" style="margin-right: 5px; color: #2271b1;"></span>
                                    <?php esc_html_e( 'Tự động chèn Internal Link (Liên kết nội bộ)', 'ai-writer-drafts' ); ?>
                                </h3>
                                
                                <label style="display: block; margin-bottom: 8px; font-weight: 600;">
                                    <input type="checkbox" name="enable_internal_links" id="enable_internal_links" value="1" checked />
                                    <?php esc_html_e( 'Quét website và tự động gắn link bài viết liên quan vào nội dung mới', 'ai-writer-drafts' ); ?>
                                </label>

                                <div id="internal-link-options" style="margin-top: 10px; padding-left: 24px;">
                                    <label for="max_internal_links" style="font-size: 13px;">
                                        <?php esc_html_e( 'Số lượng Internal Link tối đa:', 'ai-writer-drafts' ); ?>
                                    </label>
                                    <select name="max_internal_links" id="max_internal_links" style="margin-left: 5px;">
                                        <option value="2">2 liên kết</option>
                                        <option value="3" selected>3 liên kết</option>
                                        <option value="4">4 liên kết</option>
                                        <option value="5">5 liên kết</option>
                                    </select>
                                    <p class="description" style="margin-top: 4px;">
                                        <?php esc_html_e( 'Hệ thống sẽ tự động quét danh sách bài viết/trang đã xuất bản trên website, phân tích ngữ cảnh và yêu cầu AI gắn liên kết tự nhiên nhất.', 'ai-writer-drafts' ); ?>
                                    </p>
                                </div>
                            </div>

                            <!-- SECTION: TỐI ƯU ON-PAGE NÂNG CAO -->
                            <div style="margin-top: 15px; border: 1px solid #c3c4c7; border-radius: 6px; background: #fdfaf3; padding: 15px;">
                                <h3 style="margin-top: 0; margin-bottom: 10px; font-size: 14px; display: flex; align-items: center; color: #d63638;">
                                    <span class="dashicons dashicons-visibility" style="margin-right: 5px;"></span>
                                    <?php esc_html_e( 'Tối ưu SEO On-page Tự động', 'ai-writer-drafts' ); ?>
                                </h3>
                                
                                <label style="display: block; margin-bottom: 8px;">
                                    <input type="checkbox" name="seo_meta_tags" value="1" checked />
                                    <?php esc_html_e( 'Tạo thẻ Meta Title & Meta Description chuẩn (Xuất hiện ở cuối bài)', 'ai-writer-drafts' ); ?>
                                </label>

                                <label style="display: block; margin-bottom: 8px;">
                                    <input type="checkbox" name="seo_image_alt" value="1" checked />
                                    <?php esc_html_e( 'Đề xuất vị trí chèn ảnh & tạo sẵn văn bản thay thế (Alt text)', 'ai-writer-drafts' ); ?>
                                </label>

                                <label style="display: block;">
                                    <input type="checkbox" name="seo_external_links" value="1" checked />
                                    <?php esc_html_e( 'Tự động chèn External Links (Trích dẫn nguồn uy tín để tăng E-E-A-T)', 'ai-writer-drafts' ); ?>
                                </label>
                            </div>

                            <!-- ADVANCED SETTINGS -->
                            <div style="margin-top: 15px; border: 1px solid #ddd; border-radius: 6px; overflow: hidden;">
                                <div id="aiwd-advanced-toggle" style="background: #f9f9f9; padding: 10px 15px; cursor: pointer; font-weight: 600; display: flex; justify-content: space-between; align-items: center;">
                                    <span><span class="dashicons dashicons-admin-generic" style="margin-right: 5px;"></span><?php esc_html_e( 'Cài đặt nâng cao (Cấu trúc, Phong cách, Intent)', 'ai-writer-drafts' ); ?></span>
                                    <span class="dashicons dashicons-arrow-down-alt2" id="aiwd-toggle-icon"></span>
                                </div>
                                
                                <div id="aiwd-advanced-fields" style="display: none; padding: 0 15px 15px;">
                                    <table class="form-table" role="presentation" style="margin-top: 0;">
                                        <tbody>
                                            <tr>
                                                <th scope="row"><label for="secondaryKeywords"><?php esc_html_e( 'Từ khóa phụ', 'ai-writer-drafts' ); ?></label></th>
                                                <td>
                                                    <input name="secondaryKeywords" id="secondaryKeywords" type="text" class="large-text" placeholder="Nhập các từ khóa liên quan, cách nhau bởi dấu phẩy" />
                                                </td>
                                            </tr>

                                            <tr>
                                                <th scope="row"><label for="domain"><?php esc_html_e( 'Lĩnh vực / Ngành', 'ai-writer-drafts' ); ?></label></th>
                                                <td>
                                                    <input name="domain" id="domain" type="text" class="regular-text" placeholder="VD: Marketing, Sức khỏe, Công nghệ..." />
                                                </td>
                                            </tr>
                                            
                                            <tr>
                                                <th scope="row"><label for="audience"><?php esc_html_e( 'Độc giả mục tiêu', 'ai-writer-drafts' ); ?></label></th>
                                                <td>
                                                    <input name="audience" id="audience" type="text" class="regular-text" placeholder="VD: Chủ doanh nghiệp, Người mới bắt đầu..." />
                                                </td>
                                            </tr>

                                            <tr>
                                                <th scope="row"><label><?php esc_html_e( 'Định dạng bài viết', 'ai-writer-drafts' ); ?></label></th>
                                                <td>
                                                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                                                        <select name="structure" id="structure" style="flex: 1; min-width: 140px;">
                                                            <option value="Bài viết chuẩn SEO">Chuẩn SEO</option>
                                                            <option value="Bài viết dạng danh sách (Listicle)">Dạng Listicle</option>
                                                            <option value="Bài viết hướng dẫn (How-to Guide)">Hướng dẫn (How-to)</option>
                                                            <option value="Bài viết đánh giá (Review Article)">Đánh giá (Review)</option>
                                                            <option value="Bài viết so sánh (Comparison Article)">So sánh</option>
                                                        </select>
                                                        
                                                        <select name="style" id="style" style="flex: 1; min-width: 120px;">
                                                            <option value="Chuyên nghiệp">Chuyên nghiệp</option>
                                                            <option value="Thân thiện">Thân thiện</option>
                                                            <option value="Hài hước">Hài hước</option>
                                                            <option value="Học thuật">Học thuật</option>
                                                            <option value="Thuyết phục">Thuyết phục</option>
                                                        </select>

                                                        <select name="intent" id="intent" style="flex: 1; min-width: 140px;">
                                                            <option value="Thông tin (Informational)">Thông tin (Informational)</option>
                                                            <option value="Điều tra thương mại (Commercial Investigation)">Điều tra (Commercial)</option>
                                                            <option value="Giao dịch (Transactional)">Giao dịch (Transactional)</option>
                                                            <option value="Điều hướng (Navigational)">Điều hướng (Navigational)</option>
                                                        </select>
                                                    </div>
                                                </td>
                                            </tr>
                                            
                                            <tr>
                                                <th scope="row"><label for="contentGap"><?php esc_html_e( 'Hướng dẫn nội dung', 'ai-writer-drafts' ); ?></label></th>
                                                <td>
                                                    <textarea name="contentGap" id="contentGap" rows="4" class="large-text" placeholder="Nhập các yêu cầu cụ thể mà bạn muốn AI viết chi tiết..."></textarea>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            
                            <div style="margin-top: 25px; display: flex; gap: 10px; align-items: center;">
                                <button type="submit" id="aiwd-submit-btn" class="button button-primary button-hero" style="display: inline-flex; align-items: center; justify-content: center; min-width: 180px;">
                                    <span class="dashicons dashicons-edit" style="margin-right: 5px;"></span>
                                    <?php esc_html_e( 'Tạo Bài Viết Ngay', 'ai-writer-drafts' ); ?>
                                </button>
                                <button type="button" id="aiwd-reset-btn" class="button button-secondary button-hero">
                                    <?php esc_html_e( 'Làm mới', 'ai-writer-drafts' ); ?>
                                </button>
                            </div>

                            <div id="aiwd-loading" style="display:none; margin-top: 15px; padding: 12px; background: #f0f6fc; border-left: 4px solid #2271b1; color: #1d2327;">
                                <span class="spinner is-active" style="float:none; margin:0 5px 0 0"></span>
                                <strong><?php esc_html_e( 'AI đang quét dữ liệu & sáng tạo bài viết...', 'ai-writer-drafts' ); ?></strong> 
                                <?php esc_html_e( 'Quá trình này có thể mất từ 30-60 giây.', 'ai-writer-drafts' ); ?>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="aiwd-right-column" style="flex: 1; min-width: 350px;">
                    <div id="aiwd-result-placeholder" style="background: #fff; border: 2px dashed #c3c4c7; padding: 60px 20px; text-align: center; color: #646970; border-radius: 8px; height: 100%; display: flex; flex-direction: column; justify-content: center; align-items: center; box-sizing: border-box;">
                        <span class="dashicons dashicons-format-aside" style="font-size: 64px; width: 64px; height: 64px; color: #dcdcde; margin-bottom: 15px;"></span>
                        <h3 style="margin: 0 0 10px 0; color: #3c434a;"><?php esc_html_e( 'Nội dung bài viết sẽ hiển thị ở đây', 'ai-writer-drafts' ); ?></h3>
                        <p style="margin: 0;"><?php esc_html_e( 'Bản nháp sau khi AI tạo xong sẽ tự động được lưu vào mục Bài viết (Posts) của WordPress.', 'ai-writer-drafts' ); ?></p>
                    </div>

                    <div id="aiwd-result-container" style="display:none; height: 100%;">
                        <div class="postbox" style="padding: 20px; border-radius: 8px; height: 100%; box-sizing: border-box; display: flex; flex-direction: column;">
                            <h2 class="hndle" style="margin-top: 0; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #f0f0f0; padding-bottom: 10px;">
                                <span><span class="dashicons dashicons-yes-alt" style="color: #00a32a;"></span> <?php esc_html_e( 'Kết quả tạo bài', 'ai-writer-drafts' ); ?></span>
                                <span id="aiwd-word-count" style="color:#646970; font-size:13px; background: #f0f0f1; padding: 4px 8px; border-radius: 4px;"></span>
                            </h2>
                            
                            <div id="aiwd-content" style="background:#fff; border:1px solid #dcdcde; padding:25px; border-radius:4px; margin: 15px 0; flex-grow: 1; max-height: 550px; overflow-y: auto; line-height: 1.6;"></div>
                            
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <div id="aiwd-copy-toast" style="color: #00a32a; font-weight: bold; opacity: 0; transition: opacity 0.3s;">
                                    <span class="dashicons dashicons-saved"></span> <?php esc_html_e( 'Đã sao chép nội dung!', 'ai-writer-drafts' ); ?>
                                </div>
                                <button id="aiwd-copy" class="button button-primary button-large">
                                    <span class="dashicons dashicons-clipboard" style="margin-top:3px"></span>
                                    <?php esc_html_e( 'Sao chép văn bản', 'ai-writer-drafts' ); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            var $form = $('#aiwd-form');
            var $submitBtn = $('#aiwd-submit-btn');
            var $resetBtn = $('#aiwd-reset-btn');
            var $loading = $('#aiwd-loading');
            var $messageContainer = $('#aiwd-message-container');
            var $resultContainer = $('#aiwd-result-container');
            var $resultPlaceholder = $('#aiwd-result-placeholder');
            var $content = $('#aiwd-content');
            var $wordCount = $('#aiwd-word-count');
            var $copyBtn = $('#aiwd-copy');
            var $copyToast = $('#aiwd-copy-toast');
            
            $('#enable_internal_links').on('change', function() {
                if ($(this).is(':checked')) {
                    $('#internal-link-options').slideDown(200);
                } else {
                    $('#internal-link-options').slideUp(200);
                }
            });

            $('#aiwd-advanced-toggle').on('click', function() {
                $('#aiwd-advanced-fields').slideToggle(300);
                var $icon = $('#aiwd-toggle-icon');
                if ($icon.hasClass('dashicons-arrow-down-alt2')) {
                    $icon.removeClass('dashicons-arrow-down-alt2').addClass('dashicons-arrow-up-alt2');
                } else {
                    $icon.removeClass('dashicons-arrow-up-alt2').addClass('dashicons-arrow-down-alt2');
                }
            });

            $resetBtn.on('click', function() {
                if (confirm('Bạn có chắc chắn muốn xóa toàn bộ thông tin đã nhập?')) {
                    $form[0].reset();
                    $messageContainer.empty();
                    $resultContainer.hide();
                    $resultPlaceholder.show();
                    $('#internal-link-options').show();
                    $('#wordCount').val('2000');
                }
            });
            
            $form.on('submit', function(e) {
                e.preventDefault();
                
                $messageContainer.empty();
                $resultContainer.hide();
                $resultPlaceholder.show();
                $submitBtn.prop('disabled', true);
                $resetBtn.prop('disabled', true);
                $form.find('input, select, textarea').prop('readonly', true).css('opacity', '0.7');
                $loading.slideDown(200);
                
                var formData = $form.serialize();
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: formData,
                    timeout: 300000, 
                    success: function(response) {
                        $loading.slideUp(200);
                        $submitBtn.prop('disabled', false);
                        $resetBtn.prop('disabled', false);
                        $form.find('input, select, textarea').prop('readonly', false).css('opacity', '1');
                        
                        if (response.success) {
                            $messageContainer.html('<div class="notice notice-success is-dismissible" style="margin-top: 15px;"><p>' + response.data.message + '</p></div>');
                            $content.html(response.data.content);
                            $resultPlaceholder.hide();
                            $resultContainer.fadeIn(400);
                            
                            var text = $content.text() || '';
                            var words = text.trim().split(/\s+/).filter(function(w) { return w.length > 0; });
                            $wordCount.html('Số từ: <strong>' + words.length + '</strong>');
                            
                            if ($(window).width() < 782) {
                                $('html, body').animate({ scrollTop: $resultContainer.offset().top - 50 }, 500);
                            }
                        } else {
                            $messageContainer.html('<div class="notice notice-error is-dismissible" style="margin-top: 15px;"><p>' + (response.data || 'Đã có lỗi xảy ra. Vui lòng thử lại.') + '</p></div>');
                        }
                    },
                    error: function(xhr, status, error) {
                        $loading.slideUp(200);
                        $submitBtn.prop('disabled', false);
                        $resetBtn.prop('disabled', false);
                        $form.find('input, select, textarea').prop('readonly', false).css('opacity', '1');
                        
                        var errorMsg = 'Lỗi kết nối: ' + error;
                        if (status === 'timeout') {
                            errorMsg = '⚠️ Quá thời gian chờ (Timeout). Vui lòng kiểm tra mục **Bài viết (Posts)**, bài viết có thể đã được tạo thành công.';
                        } else if (xhr.responseText) {
                            try {
                                var jsonResp = JSON.parse(xhr.responseText);
                                if (jsonResp && jsonResp.data) { errorMsg = jsonResp.data; }
                            } catch(e) {}
                        }
                        
                        $messageContainer.html('<div class="notice notice-error is-dismissible" style="margin-top: 15px;"><p>' + errorMsg + '</p></div>');
                    }
                });
            });
            
            $copyBtn.on('click', function(e) {
                e.preventDefault();
                var $temp = $("<textarea>");
                $("body").append($temp);
                $temp.val($content.text()).select();
                document.execCommand("copy");
                $temp.remove();
                
                $copyToast.css('opacity', '1');
                setTimeout(function() {
                    $copyToast.css('opacity', '0');
                }, 2500);
            });
        });
        </script>
        <?php
    }
    
    /**
     * Handle AJAX request for article generation
     */
    public static function handle_ajax_request() {
        check_ajax_referer( 'aiwd_generate_article', 'aiwd_nonce' );
        
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( __( 'Bạn không có quyền thực hiện hành động này.', 'ai-writer-drafts' ) );
        }
        
        $topic = isset( $_POST['topic'] ) ? sanitize_text_field( wp_unslash( $_POST['topic'] ) ) : '';
        $main_keyword = isset( $_POST['mainKeyword'] ) ? sanitize_text_field( wp_unslash( $_POST['mainKeyword'] ) ) : '';
        
        if ( empty( $topic ) || empty( $main_keyword ) ) {
            wp_send_json_error( __( 'Vui lòng điền đầy đủ Chủ đề và Từ khóa chính.', 'ai-writer-drafts' ) );
        }

        $internal_links_data = array();
        $enable_internal_links = isset( $_POST['enable_internal_links'] ) ? true : false;
        $max_internal_links = isset( $_POST['max_internal_links'] ) ? intval( $_POST['max_internal_links'] ) : 3;

        if ( $enable_internal_links ) {
            $recent_posts = get_posts( array(
                'post_type'      => array( 'post', 'page' ),
                'post_status'    => 'publish',
                'posts_per_page' => 40, 
                'orderby'        => 'date',
                'order'          => 'DESC',
            ) );

            foreach ( $recent_posts as $p ) {
                $internal_links_data[] = array(
                    'title' => get_the_title( $p->ID ),
                    'url'   => get_permalink( $p->ID ),
                );
            }
        }
        
        // Cập nhật mảng $params để đẩy dữ liệu mới sang File Prompt
        $params = array(
            'domain'               => isset( $_POST['domain'] ) ? sanitize_text_field( wp_unslash( $_POST['domain'] ) ) : '',
            'audience'             => isset( $_POST['audience'] ) ? sanitize_text_field( wp_unslash( $_POST['audience'] ) ) : '',
            'word_count'           => isset( $_POST['wordCount'] ) ? intval( $_POST['wordCount'] ) : 2000,
            'topic'                => $topic,
            'main_keyword'         => $main_keyword,
            'secondary_keywords'   => isset( $_POST['secondaryKeywords'] ) ? sanitize_text_field( wp_unslash( $_POST['secondaryKeywords'] ) ) : '',
            'content_gap'          => isset( $_POST['contentGap'] ) ? sanitize_textarea_field( wp_unslash( $_POST['contentGap'] ) ) : '',
            'structure'            => isset( $_POST['structure'] ) ? sanitize_text_field( wp_unslash( $_POST['structure'] ) ) : 'Bài viết chuẩn SEO',
            'style'                => isset( $_POST['style'] ) ? sanitize_text_field( wp_unslash( $_POST['style'] ) ) : 'Chuyên nghiệp',
            'intent'               => isset( $_POST['intent'] ) ? sanitize_text_field( wp_unslash( $_POST['intent'] ) ) : 'Thông tin (Informational)',
            'enable_internal_links'=> $enable_internal_links,
            'max_internal_links'   => $max_internal_links,
            'internal_links_data'  => $internal_links_data,
            // 3 tính năng mới
            'seo_meta_tags'        => isset( $_POST['seo_meta_tags'] ) ? true : false,
            'seo_image_alt'        => isset( $_POST['seo_image_alt'] ) ? true : false,
            'seo_external_links'   => isset( $_POST['seo_external_links'] ) ? true : false,
        );
        
        if ( function_exists( 'set_time_limit' ) ) {
            set_time_limit( 300 ); 
        }
        
        try {
            $result = AIWD_Article_Generator::generate_article( $params );
            
            if ( $result['success'] ) {
                $edit_link = get_edit_post_link( $result['post_id'], '' );
                $success_message = sprintf(
                    __( 'Đã tạo bản nháp thành công! %1$sChỉnh sửa bài viết%2$s', 'ai-writer-drafts' ),
                    '<a href="' . esc_url( $edit_link ) . '" class="button button-primary" style="margin-left:10px" target="_blank">',
                    '</a>'
                );
                
                wp_send_json_success( array(
                    'content' => $result['content'],
                    'message' => $success_message,
                ) );
            } else {
                wp_send_json_error( $result['error'] );
            }
        } catch ( Exception $e ) {
            wp_send_json_error( 'Exception: ' . $e->getMessage() );
        } catch ( Error $e ) {
            wp_send_json_error( 'Fatal Error: ' . $e->getMessage() );
        }
    }
}
