<?php
/**
 * Settings Page
 *
 * @package AI_Writer_Drafts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once plugin_dir_path( dirname( __FILE__ ) ) . 'class-article-generator.php';

class AIWD_Settings_Page {
    
    /**
     * Render settings page
     */
    public static function render() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Bạn không có quyền truy cập trang này.', 'ai-writer-drafts' ) );
        }
        
        // Get active tab - check POST first (when saving), then GET (when navigating)
        $active_tab = isset( $_POST['tab'] ) ? sanitize_text_field( wp_unslash( $_POST['tab'] ) ) : ( isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : 'general' );
        
        // Handle form submission
        $settings_saved = false;
        if ( isset( $_POST['aiwd_save_settings'] ) ) {
            check_admin_referer( 'aiwd_settings' );
            self::save_settings();
            $settings_saved = true;
        }
        
        // Handle test connection (Save & Test)
        if ( isset( $_POST['aiwd_test_connection'] ) ) {
            check_admin_referer( 'aiwd_settings' ); // Use main form nonce
            self::save_settings(); // Save first
            self::test_connection();
        }
        
        // Show success message
        if ( $settings_saved ) {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Đã lưu cài đặt!', 'ai-writer-drafts' ) . '</p></div>';
        }
        
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Cài Đặt AI Writer', 'ai-writer-drafts' ); ?></h1>
            
            <h2 class="nav-tab-wrapper">
                <a href="?page=ai-writer-settings&tab=general" class="nav-tab <?php echo $active_tab === 'general' ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e( 'Cài Đặt Chung', 'ai-writer-drafts' ); ?>
                </a>
                <a href="?page=ai-writer-settings&tab=openai" class="nav-tab <?php echo $active_tab === 'openai' ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e( 'OpenAI', 'ai-writer-drafts' ); ?>
                </a>
                <a href="?page=ai-writer-settings&tab=claude" class="nav-tab <?php echo $active_tab === 'claude' ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e( 'Claude', 'ai-writer-drafts' ); ?>
                </a>
                <a href="?page=ai-writer-settings&tab=gemini" class="nav-tab <?php echo $active_tab === 'gemini' ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e( 'Gemini', 'ai-writer-drafts' ); ?>
                </a>
                <a href="?page=ai-writer-settings&tab=compatible" class="nav-tab <?php echo $active_tab === 'compatible' ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e( 'Tương Thích OpenAI', 'ai-writer-drafts' ); ?>
                </a>
                <a href="?page=ai-writer-settings&tab=brand" class="nav-tab <?php echo $active_tab === 'brand' ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e( 'Thương Hiệu', 'ai-writer-drafts' ); ?>
                </a>
            </h2>
            
            <form method="post" action="<?php echo esc_url( add_query_arg( array( 'page' => 'ai-writer-settings', 'tab' => $active_tab ), admin_url( 'options-general.php' ) ) ); ?>">
                <?php wp_nonce_field( 'aiwd_settings' ); ?>
                <input type="hidden" name="aiwd_save_settings" value="1" />
                <input type="hidden" name="tab" value="<?php echo esc_attr( $active_tab ); ?>" />
                
                <?php
                switch ( $active_tab ) {
                    case 'general':
                        self::render_general_tab();
                        break;
                    case 'openai':
                        self::render_openai_tab();
                        break;
                    case 'claude':
                        self::render_claude_tab();
                        break;
                    case 'gemini':
                        self::render_gemini_tab();
                        break;
                    case 'compatible':
                        self::render_compatible_tab();
                        break;
                    case 'brand':
                        self::render_brand_tab();
                        break;
                }
                ?>
                
                <?php submit_button( __( 'Lưu Cài Đặt', 'ai-writer-drafts' ) ); ?>
            </form>
            <div class="aiwd-footer" style="margin-top: 40px; border-top: 1px solid #ddd; padding-top: 20px; color: #666;">
                <h3><?php esc_html_e( 'Về công cụ AI Writer', 'ai-writer-drafts' ); ?></h3>
                <p><?php esc_html_e( 'AI Writer là công cụ hỗ trợ viết bài tự động sử dụng các mô hình ngôn ngữ tiên tiến nhất hiện nay như GPT-5.1, GPT-5, GPT-4.1, Claude 4.5. Plugin giúp bạn tạo ra nội dung chất lượng cao, chuẩn SEO chỉ trong vài giây.', 'ai-writer-drafts' ); ?></p>
                <p>
                    <strong><?php esc_html_e( 'Tác giả:', 'ai-writer-drafts' ); ?></strong> Phạm Ngọc Tú<br>
                    <strong><?php esc_html_e( 'Điện thoại:', 'ai-writer-drafts' ); ?></strong> 0896009111<br>
                    <strong><?php esc_html_e( 'Website:', 'ai-writer-drafts' ); ?></strong> <a href="https://congcuseoai.com" target="_blank" style="text-decoration: none; color: #2271b1;">congcuseoai.com</a><br>
                    <strong><?php esc_html_e( 'Donate Cafe:', 'ai-writer-drafts' ); ?></strong> <span style="color: #d63638; font-weight: bold;">688859999</span> - Ngân hàng VIB
                </p>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render general settings tab
     */
    private static function render_general_tab() {
        $active_provider = get_option( 'aiwd_active_provider', 'openai' );
        ?>
        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row">
                        <label for="aiwd_active_provider"><?php esc_html_e( 'Nhà Cung Cấp AI Đang Dùng', 'ai-writer-drafts' ); ?></label>
                    </th>
                    <td>
                        <select name="aiwd_active_provider" id="aiwd_active_provider" class="regular-text">
                            <option value="openai" <?php selected( $active_provider, 'openai' ); ?>>OpenAI</option>
                            <option value="claude" <?php selected( $active_provider, 'claude' ); ?>>Claude</option>
                            <option value="gemini" <?php selected( $active_provider, 'gemini' ); ?>>Google Gemini</option>
                            <option value="openai_compatible" <?php selected( $active_provider, 'openai_compatible' ); ?>>OpenAI Compatible</option>
                        </select>
                        <p class="description"><?php esc_html_e( 'Chọn nhà cung cấp AI bạn muốn sử dụng để tạo nội dung', 'ai-writer-drafts' ); ?></p>
                    </td>
                </tr>
            </tbody>
        </table>

        <div class="notice notice-info inline" style="margin-top: 20px;">
            <h3><?php esc_html_e( 'Hướng dẫn sử dụng nhanh:', 'ai-writer-drafts' ); ?></h3>
            <ol>
                <li><?php esc_html_e( 'Chọn tab nhà cung cấp bạn muốn sử dụng (OpenAI, Claude, Gemini, v.v.) ở trên.', 'ai-writer-drafts' ); ?></li>
                <li><?php esc_html_e( 'Nhập API Key và cấu hình các thông số cần thiết (Model, Temperature).', 'ai-writer-drafts' ); ?></li>
                <li><?php esc_html_e( 'Quay lại tab "Cài Đặt Chung" này và chọn nhà cung cấp vừa cấu hình.', 'ai-writer-drafts' ); ?></li>
                <li><?php esc_html_e( 'Lưu cài đặt.', 'ai-writer-drafts' ); ?></li>
                <li><?php printf( esc_html__( 'Truy cập menu %s để bắt đầu tạo bài viết.', 'ai-writer-drafts' ), '<strong>' . esc_html__( 'Bài Viết --> AI Writer', 'ai-writer-drafts' ) . '</strong>' ); ?></li>
            </ol>
        </div>
        <?php
    }
    
    /**
     * Render OpenAI settings tab
     */
    private static function render_openai_tab() {
        $api_key = get_option( 'aiwd_openai_api_key', '' );
        $model   = get_option( 'aiwd_openai_model', 'gpt-4o-mini' );
        $temp    = get_option( 'aiwd_openai_temperature', '0.7' );
        ?>

        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row">
                        <label for="aiwd_openai_api_key"><?php esc_html_e( 'OpenAI API Key', 'ai-writer-drafts' ); ?> <span style="color:red">*</span></label>
                    </th>
                    <td>
                        <input type="password" name="aiwd_openai_api_key" id="aiwd_openai_api_key" value="<?php echo esc_attr( $api_key ); ?>" class="regular-text" />
                        <p class="description">
                            <?php
                            printf(
                                /* translators: %s: OpenAI platform URL */
                                esc_html__( 'Lấy API key tại %s', 'ai-writer-drafts' ),
                                '<a href="https://platform.openai.com/api-keys" target="_blank">OpenAI Platform</a>'
                            );
                            ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="aiwd_openai_model"><?php esc_html_e( 'Model', 'ai-writer-drafts' ); ?></label>
                    </th>
                    <td>
                        <select name="aiwd_openai_model" id="aiwd_openai_model" class="regular-text" onchange="if(this.value === 'custom') { document.getElementById('aiwd_openai_custom_model_container').style.display = 'block'; } else { document.getElementById('aiwd_openai_custom_model_container').style.display = 'none'; }">
                            <option value="gpt-4o" <?php selected( $model, 'gpt-4o' ); ?>>GPT-4o (Thông minh)</option>
                            <option value="gpt-4o-mini" <?php selected( $model, 'gpt-4o-mini' ); ?>>GPT-4.1 Mini (Hiệu quả nhất - Khuyên dùng)</option>
                            <option value="o1-preview" <?php selected( $model, 'o1-preview' ); ?>>o1-preview (Reasoning - Mạnh nhất)</option>
                            <option value="o1-mini" <?php selected( $model, 'o1-mini' ); ?>>o1-mini (Reasoning - Nhanh hơn)</option>
                            <option value="gpt-4-turbo" <?php selected( $model, 'gpt-4-turbo' ); ?>>GPT-4 Turbo</option>
                            <option value="gpt-3.5-turbo" <?php selected( $model, 'gpt-3.5-turbo' ); ?>>GPT-3.5 Turbo (Cũ)</option>
                            <option value="custom" <?php selected( ! in_array( $model, array( 'gpt-4o', 'gpt-4o-mini', 'o1-preview', 'o1-mini', 'gpt-4-turbo', 'gpt-3.5-turbo' ) ), true ); ?>>Model Khác (Nhập thủ công)</option>
                        </select>
                        <div id="aiwd_openai_custom_model_container" style="margin-top: 5px; display: <?php echo ! in_array( $model, array( 'gpt-4o', 'gpt-4o-mini', 'o1-preview', 'o1-mini', 'gpt-4-turbo', 'gpt-3.5-turbo' ) ) ? 'block' : 'none'; ?>;">
                            <input type="text" name="aiwd_openai_custom_model" value="<?php echo esc_attr( $model ); ?>" class="regular-text" placeholder="Nhập ID model (ví dụ: gpt-4-turbo-preview)" />
                            <p class="description"><?php esc_html_e( 'Nhập ID model từ tài liệu OpenAI.', 'ai-writer-drafts' ); ?></p>
                        </div>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="aiwd_openai_temperature"><?php esc_html_e( 'Temperature', 'ai-writer-drafts' ); ?></label>
                    </th>
                    <td>
                        <input type="number" step="0.1" min="0" max="2" name="aiwd_openai_temperature" id="aiwd_openai_temperature" value="<?php echo esc_attr( $temp ); ?>" class="small-text" />
                        <p class="description"><?php esc_html_e( 'Mức độ sáng tạo (0-2). Khuyến nghị: 0.7', 'ai-writer-drafts' ); ?></p>
                    </td>
                </tr>
            </tbody>
        </table>
        
        <div class="notice notice-info inline" style="margin: 20px 0;">
            <p><strong><?php esc_html_e( 'Hướng dẫn cấu hình OpenAI:', 'ai-writer-drafts' ); ?></strong></p>
            <ol>
                <li><?php printf( esc_html__( 'Truy cập %s để tạo API Key.', 'ai-writer-drafts' ), '<a href="https://platform.openai.com/api-keys" target="_blank">OpenAI Platform</a>' ); ?></li>
                <li><?php esc_html_e( 'Copy API Key và dán vào ô bên dưới.', 'ai-writer-drafts' ); ?></li>
                <li><?php esc_html_e( 'Hỗ trợ các model mới nhất: GPT-5.1, GPT-5, GPT-4.1...', 'ai-writer-drafts' ); ?></li>
                <li><?php esc_html_e( 'Chọn Model phù hợp (GPT-4.1 Mini là lựa chọn hiệu quả nhất hiện nay).', 'ai-writer-drafts' ); ?></li>
                <li><?php esc_html_e( 'Bấm "Lưu & Test Kết Nối" để kiểm tra.', 'ai-writer-drafts' ); ?></li>
            </ol>
        </div>
        <?php self::render_test_button( 'openai' ); ?>
        <?php
    }
    
    /**
     * Render Claude settings tab
     */
    private static function render_claude_tab() {
        $api_key = get_option( 'aiwd_claude_api_key', '' );
        $model   = get_option( 'aiwd_claude_model', 'claude-3-5-sonnet-20241022' );
        $temp    = get_option( 'aiwd_claude_temperature', '0.7' );
        ?>

        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row">
                        <label for="aiwd_claude_api_key"><?php esc_html_e( 'Claude API Key', 'ai-writer-drafts' ); ?> <span style="color:red">*</span></label>
                    </th>
                    <td>
                        <input type="password" name="aiwd_claude_api_key" id="aiwd_claude_api_key" value="<?php echo esc_attr( $api_key ); ?>" class="regular-text" />
                        <p class="description">
                            <?php
                            printf(
                                /* translators: %s: Anthropic console URL */
                                esc_html__( 'Lấy API key tại %s', 'ai-writer-drafts' ),
                                '<a href="https://console.anthropic.com/settings/keys" target="_blank">Anthropic Console</a>'
                            );
                            ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="aiwd_claude_model"><?php esc_html_e( 'Model', 'ai-writer-drafts' ); ?></label>
                    </th>
                    <td>
                        <select name="aiwd_claude_model" id="aiwd_claude_model" class="regular-text" onchange="if(this.value === 'custom') { document.getElementById('aiwd_claude_custom_model_container').style.display = 'block'; } else { document.getElementById('aiwd_claude_custom_model_container').style.display = 'none'; }">
                            <option value="claude-sonnet-4-5" <?php selected( $model, 'claude-sonnet-4-5' ); ?>>Claude 4.5 Sonnet (Mới nhất - Chất lượng tốt nhất)</option>
                            <option value="claude-3-5-sonnet-latest" <?php selected( $model, 'claude-3-5-sonnet-latest' ); ?>>Claude 3.5 Sonnet (Latest)</option>
                            <option value="claude-3-5-sonnet-20241022" <?php selected( $model, 'claude-3-5-sonnet-20241022' ); ?>>Claude 3.5 Sonnet (v2 - 20241022)</option>
                            <option value="claude-3-5-haiku-latest" <?php selected( $model, 'claude-3-5-haiku-latest' ); ?>>Claude 3.5 Haiku (Latest - Nhanh & Rẻ)</option>
                            <option value="claude-3-opus-latest" <?php selected( $model, 'claude-3-opus-latest' ); ?>>Claude 3 Opus (Latest - Mạnh nhất)</option>
                            <option value="custom" <?php selected( ! in_array( $model, array( 'claude-sonnet-4-5', 'claude-3-5-sonnet-latest', 'claude-3-5-sonnet-20241022', 'claude-3-5-haiku-latest', 'claude-3-opus-latest' ) ), true ); ?>>Model Khác (Nhập thủ công)</option>
                        </select>
                        <div id="aiwd_claude_custom_model_container" style="margin-top: 5px; display: <?php echo ! in_array( $model, array( 'claude-3-5-sonnet-latest', 'claude-3-5-sonnet-20241022', 'claude-3-5-haiku-latest', 'claude-3-opus-latest' ) ) ? 'block' : 'none'; ?>;">
                            <input type="text" name="aiwd_claude_custom_model" value="<?php echo esc_attr( $model ); ?>" class="regular-text" placeholder="Nhập ID model (ví dụ: claude-3-sonnet-20240229)" />
                            <p class="description"><?php esc_html_e( 'Nhập ID model từ tài liệu Anthropic.', 'ai-writer-drafts' ); ?></p>
                        </div>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="aiwd_claude_temperature"><?php esc_html_e( 'Temperature', 'ai-writer-drafts' ); ?></label>
                    </th>
                    <td>
                        <input type="number" step="0.1" min="0" max="1" name="aiwd_claude_temperature" id="aiwd_claude_temperature" value="<?php echo esc_attr( $temp ); ?>" class="small-text" />
                        <p class="description"><?php esc_html_e( 'Mức độ sáng tạo (0-1). Khuyến nghị: 0.7', 'ai-writer-drafts' ); ?></p>
                    </td>
                </tr>
            </tbody>
        </table>
        
        <div class="notice notice-info inline" style="margin: 20px 0;">
            <p><strong><?php esc_html_e( 'Hướng dẫn cấu hình Claude (Anthropic):', 'ai-writer-drafts' ); ?></strong></p>
            <ol>
                <li><?php printf( esc_html__( 'Truy cập %s để tạo API Key.', 'ai-writer-drafts' ), '<a href="https://console.anthropic.com/settings/keys" target="_blank">Anthropic Console</a>' ); ?></li>
                <li><?php esc_html_e( 'Copy API Key và dán vào ô bên dưới.', 'ai-writer-drafts' ); ?></li>
                <li><?php esc_html_e( 'Chọn Model (Claude 4.5 Sonnet là lựa chọn tốt nhất hiện nay).', 'ai-writer-drafts' ); ?></li>
                <li><?php esc_html_e( 'Bấm "Lưu & Test Kết Nối" để kiểm tra.', 'ai-writer-drafts' ); ?></li>
            </ol>
        </div>
        <?php self::render_test_button( 'claude' ); ?>
        <?php
    }
    
    /**
     * Render OpenAI Compatible settings tab
     */
    private static function render_compatible_tab() {
        $api_key    = get_option( 'aiwd_compatible_api_key', '' );
        $endpoint   = get_option( 'aiwd_compatible_endpoint', '' );
        $model      = get_option( 'aiwd_compatible_model', '' );
        $temp       = get_option( 'aiwd_compatible_temperature', '0.7' );
        ?>

        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row">
                        <label for="aiwd_compatible_endpoint"><?php esc_html_e( 'API Endpoint', 'ai-writer-drafts' ); ?> <span style="color:red">*</span></label>
                    </th>
                    <td>
                        <input type="url" name="aiwd_compatible_endpoint" id="aiwd_compatible_endpoint" value="<?php echo esc_attr( $endpoint ); ?>" class="regular-text" placeholder="https://ai.megallm.io/v1/chat/completions" />
                        <p class="description"><?php esc_html_e( 'URL endpoint của API (ví dụ: https://ai.megallm.io/v1/chat/completions)', 'ai-writer-drafts' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="aiwd_compatible_api_key"><?php esc_html_e( 'API Key', 'ai-writer-drafts' ); ?> <span style="color:red">*</span></label>
                    </th>
                    <td>
                        <input type="password" name="aiwd_compatible_api_key" id="aiwd_compatible_api_key" value="<?php echo esc_attr( $api_key ); ?>" class="regular-text" />
                        <p class="description"><?php esc_html_e( 'API key từ nhà cung cấp tương thích OpenAI', 'ai-writer-drafts' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="aiwd_compatible_model"><?php esc_html_e( 'Model Name', 'ai-writer-drafts' ); ?> <span style="color:red">*</span></label>
                    </th>
                    <td>
                        <input type="text" name="aiwd_compatible_model" id="aiwd_compatible_model" value="<?php echo esc_attr( $model ); ?>" class="regular-text" placeholder="llama-3.3-70b-versatile" />
                        <p class="description">
                            <?php esc_html_e( 'Nhập ID model từ nhà cung cấp dịch vụ (Ví dụ: gpt-3.5-turbo, llama-3-70b, ...)', 'ai-writer-drafts' ); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="aiwd_compatible_temperature"><?php esc_html_e( 'Temperature', 'ai-writer-drafts' ); ?></label>
                    </th>
                    <td>
                        <input type="number" step="0.1" min="0" max="2" name="aiwd_compatible_temperature" id="aiwd_compatible_temperature" value="<?php echo esc_attr( $temp ); ?>" class="small-text" />
                        <p class="description"><?php esc_html_e( 'Mức độ sáng tạo (0-2). Khuyến nghị: 0.7', 'ai-writer-drafts' ); ?></p>
                    </td>
                </tr>
            </tbody>
        </table>
        
        <div class="notice notice-info inline" style="margin: 20px 0;">
            <p><strong><?php esc_html_e( 'Hướng dẫn cấu hình OpenAI Compatible:', 'ai-writer-drafts' ); ?></strong></p>
            <ol>
                <li><?php esc_html_e( 'Chúng tôi đề xuất sử dụng các dịch vụ sau để có chi phí rẻ và chất lượng tốt:', 'ai-writer-drafts' ); ?>
                    <ul style="list-style-type: disc; margin-left: 20px; margin-top: 5px;">
                        <li><strong>MegaLLM</strong> (Miễn phí để test): <a href="https://megallm.io/ref/REF-13C1XVNR" target="_blank">Đăng ký tại đây</a></li>
                        <li><strong>LLM.ai.vn</strong> (API Shared giá rẻ, liên hệ mình để mua với chi phí hợp lý): <a href="https://llm.ai.vn/register?aff=odmh" target="_blank">Đăng ký tại đây</a></li>
                        <li><strong>OpenRouter</strong>: <a href="https://openrouter.ai" target="_blank">openrouter.ai</a></li>
                    </ul>
                </li>
                <li><?php esc_html_e( 'Nhập API Endpoint (Ví dụ MegaLLM: https://ai.megallm.io/v1/chat/completions).', 'ai-writer-drafts' ); ?></li>
                <li><?php esc_html_e( 'Nhập API Key từ nhà cung cấp dịch vụ.', 'ai-writer-drafts' ); ?></li>
                <li><?php esc_html_e( 'Nhập ID Model chính xác (Ví dụ: gpt-4o-mini, claude-3-5-sonnet...).', 'ai-writer-drafts' ); ?></li>
                <li><?php esc_html_e( 'Bấm "Lưu & Test Kết Nối" để kiểm tra.', 'ai-writer-drafts' ); ?></li>
            </ol>
        </div>
        <?php self::render_test_button( 'openai_compatible' ); ?>
        <?php
    }
    
    /**
     * Render Gemini settings tab
     */
    private static function render_gemini_tab() {
        $api_key = get_option( 'aiwd_gemini_api_key', '' );
        $model   = get_option( 'aiwd_gemini_model', 'gemini-2.5-flash' );
        $temp    = get_option( 'aiwd_gemini_temperature', '0.7' );
        ?>

        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row">
                        <label for="aiwd_gemini_api_key"><?php esc_html_e( 'Gemini API Key', 'ai-writer-drafts' ); ?> <span style="color:red">*</span></label>
                    </th>
                    <td>
                        <input type="password" name="aiwd_gemini_api_key" id="aiwd_gemini_api_key" value="<?php echo esc_attr( $api_key ); ?>" class="regular-text" />
                        <p class="description">
                            <?php
                            printf(
                                /* translators: %s: Google AI Studio URL */
                                esc_html__( 'Lấy API key tại %s', 'ai-writer-drafts' ),
                                '<a href="https://aistudio.google.com/apikey" target="_blank">Google AI Studio</a>'
                            );
                            ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="aiwd_gemini_model"><?php esc_html_e( 'Model', 'ai-writer-drafts' ); ?></label>
                    </th>
                    <td>
                        <select name="aiwd_gemini_model" id="aiwd_gemini_model" class="regular-text" onchange="if(this.value === 'custom') { document.getElementById('aiwd_gemini_custom_model_container').style.display = 'block'; } else { document.getElementById('aiwd_gemini_custom_model_container').style.display = 'none'; }">
                            <option value="gemini-3.0-flash" <?php selected( $model, 'gemini-3.0-flash' ); ?>>Gemini 3.0 Flash (Mới nhất - Nhanh & Thông minh)</option>
                            <option value="gemini-2.5-pro" <?php selected( $model, 'gemini-2.5-pro' ); ?>>Gemini 2.5 Pro (Mạnh nhất)</option>
                            <option value="gemini-2.5-flash" <?php selected( $model, 'gemini-2.5-flash' ); ?>>Gemini 2.5 Flash (Hiệu quả nhất - Khuyên dùng)</option>
                            <option value="gemini-1.5-pro" <?php selected( $model, 'gemini-1.5-pro' ); ?>>Gemini 1.5 Pro</option>
                            <option value="gemini-1.5-flash" <?php selected( $model, 'gemini-1.5-flash' ); ?>>Gemini 1.5 Flash</option>
                            <option value="custom" <?php selected( ! in_array( $model, array( 'gemini-3.0-flash', 'gemini-2.5-pro', 'gemini-2.5-flash', 'gemini-1.5-pro', 'gemini-1.5-flash' ) ), true ); ?>>Model Khác (Nhập thủ công)</option>
                        </select>
                        <div id="aiwd_gemini_custom_model_container" style="margin-top: 5px; display: <?php echo ! in_array( $model, array( 'gemini-3.0-flash', 'gemini-2.5-pro', 'gemini-2.5-flash', 'gemini-1.5-pro', 'gemini-1.5-flash' ) ) ? 'block' : 'none'; ?>;">
                            <input type="text" name="aiwd_gemini_custom_model" value="<?php echo esc_attr( $model ); ?>" class="regular-text" placeholder="Nhập ID model (ví dụ: gemini-2.0-flash-exp)" />
                            <p class="description"><?php esc_html_e( 'Nhập ID model từ tài liệu Google Gemini.', 'ai-writer-drafts' ); ?></p>
                        </div>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="aiwd_gemini_temperature"><?php esc_html_e( 'Temperature', 'ai-writer-drafts' ); ?></label>
                    </th>
                    <td>
                        <input type="number" step="0.1" min="0" max="2" name="aiwd_gemini_temperature" id="aiwd_gemini_temperature" value="<?php echo esc_attr( $temp ); ?>" class="small-text" />
                        <p class="description"><?php esc_html_e( 'Mức độ sáng tạo (0-2). Khuyến nghị: 0.7', 'ai-writer-drafts' ); ?></p>
                    </td>
                </tr>
            </tbody>
        </table>
        
        <div class="notice notice-info inline" style="margin: 20px 0;">
            <p><strong><?php esc_html_e( 'Hướng dẫn cấu hình Google Gemini:', 'ai-writer-drafts' ); ?></strong></p>
            <ol>
                <li><?php printf( esc_html__( 'Truy cập %s để tạo API Key.', 'ai-writer-drafts' ), '<a href="https://aistudio.google.com/apikey" target="_blank">Google AI Studio</a>' ); ?></li>
                <li><?php esc_html_e( 'Copy API Key và dán vào ô bên dưới.', 'ai-writer-drafts' ); ?></li>
                <li><?php esc_html_e( 'Hỗ trợ các model mới nhất: Gemini 3.0, Gemini 2.5...', 'ai-writer-drafts' ); ?></li>
                <li><?php esc_html_e( 'Chọn Model phù hợp (Gemini 2.5 Flash là lựa chọn hiệu quả nhất).', 'ai-writer-drafts' ); ?></li>
                <li><?php esc_html_e( 'Bấm "Lưu & Test Kết Nối" để kiểm tra.', 'ai-writer-drafts' ); ?></li>
            </ol>
        </div>
        <?php self::render_test_button( 'gemini' ); ?>
        <?php
    }
    
    /**
     * Render Brand settings tab
     */
    private static function render_brand_tab() {
        $brand_name = get_option( 'aiwd_brand_name', 'Công Cụ SEO AI' );
        $brand_desc = get_option( 'aiwd_brand_description', 'Tối ưu hóa mọi khía cạnh SEO của bạn với sức mạnh của Trí tuệ nhân tạo. Nhanh chóng, chính xác và hiệu quả.' );
        $brand_website = get_option( 'aiwd_brand_website', 'congcuseoai.com' );
        $brand_contact_name = get_option( 'aiwd_brand_contact_name', 'Phạm Ngọc Tú' );
        $brand_contact_phone = get_option( 'aiwd_brand_contact_phone', '0896009111' );
        ?>

        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row">
                        <label for="aiwd_brand_name"><?php esc_html_e( 'Tên Thương Hiệu', 'ai-writer-drafts' ); ?> <span style="color:red">*</span></label>
                    </th>
                    <td>
                        <input type="text" name="aiwd_brand_name" id="aiwd_brand_name" value="<?php echo esc_attr( $brand_name ); ?>" class="regular-text" />
                        <p class="description"><?php esc_html_e( 'Tên công ty hoặc thương hiệu của bạn', 'ai-writer-drafts' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="aiwd_brand_description"><?php esc_html_e( 'Mô Tả Thương Hiệu', 'ai-writer-drafts' ); ?></label>
                    </th>
                    <td>
                        <textarea name="aiwd_brand_description" id="aiwd_brand_description" rows="3" class="large-text"><?php echo esc_textarea( $brand_desc ); ?></textarea>
                        <p class="description"><?php esc_html_e( 'Giới thiệu ngắn gọn về thương hiệu/công ty của bạn', 'ai-writer-drafts' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="aiwd_brand_website"><?php esc_html_e( 'Website', 'ai-writer-drafts' ); ?></label>
                    </th>
                    <td>
                        <input type="url" name="aiwd_brand_website" id="aiwd_brand_website" value="<?php echo esc_attr( $brand_website ); ?>" class="regular-text" placeholder="congcuseoai.com" />
                        <p class="description"><?php esc_html_e( 'Website của thương hiệu (Ghi đầy đủ http:// hoặc https://)', 'ai-writer-drafts' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="aiwd_brand_contact_name"><?php esc_html_e( 'Tên Liên Hệ', 'ai-writer-drafts' ); ?></label>
                    </th>
                    <td>
                        <input type="text" name="aiwd_brand_contact_name" id="aiwd_brand_contact_name" value="<?php echo esc_attr( $brand_contact_name ); ?>" class="regular-text" />
                        <p class="description"><?php esc_html_e( 'Tên người liên hệ hoặc đại diện thương hiệu', 'ai-writer-drafts' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="aiwd_brand_contact_phone"><?php esc_html_e( 'Số Điện Thoại', 'ai-writer-drafts' ); ?></label>
                    </th>
                    <td>
                        <input type="text" name="aiwd_brand_contact_phone" id="aiwd_brand_contact_phone" value="<?php echo esc_attr( $brand_contact_phone ); ?>" class="regular-text" />
                        <p class="description"><?php esc_html_e( 'Số điện thoại liên hệ', 'ai-writer-drafts' ); ?></p>
                    </td>
                </tr>
            </tbody>
        </table>
        
        <div class="notice notice-info inline" style="margin: 20px 0;">
            <p><strong><?php esc_html_e( 'Hướng dẫn cấu hình Thương Hiệu:', 'ai-writer-drafts' ); ?></strong></p>
            <ol>
                <li><?php esc_html_e( 'Nhập thông tin thương hiệu của bạn vào các trường bên trên.', 'ai-writer-drafts' ); ?></li>
                <li><?php esc_html_e( 'Thông tin này sẽ được AI sử dụng khi tạo nội dung bài viết.', 'ai-writer-drafts' ); ?></li>
                <li><?php esc_html_e( 'AI có thể nhắc đến thương hiệu của bạn trong phần kết luận hoặc call-to-action.', 'ai-writer-drafts' ); ?></li>
                <li><?php esc_html_e( 'Bấm "Lưu Cài Đặt" để lưu thông tin.', 'ai-writer-drafts' ); ?></li>
            </ol>
        </div>
        <?php
    }
    
    /**
     * Render test connection button
     *
     * @param string $provider Provider name.
     */
    private static function render_test_button( $provider ) {
        ?>
        <hr>
        <h3><?php esc_html_e( 'Kiểm Tra Kết Nối', 'ai-writer-drafts' ); ?></h3>
        <div style="margin-top: 10px;">
            <input type="hidden" name="provider_test_target" value="<?php echo esc_attr( $provider ); ?>" />
            <button type="submit" name="aiwd_test_connection" value="1" class="button"><?php esc_html_e( 'Lưu & Test Kết Nối', 'ai-writer-drafts' ); ?></button>
            <p class="description" style="display:inline-block;margin-left:10px;vertical-align:middle;">
                <?php esc_html_e( 'Lưu ý: Cài đặt sẽ được lưu trước khi kiểm tra kết nối.', 'ai-writer-drafts' ); ?>
            </p>
        </div>
        <?php
    }
    
    /**
     * Save settings
     */
    private static function save_settings() {
        $tab = isset( $_POST['tab'] ) ? sanitize_text_field( wp_unslash( $_POST['tab'] ) ) : 'general';
        
        if ( $tab === 'general' ) {
            if ( isset( $_POST['aiwd_active_provider'] ) ) {
                update_option( 'aiwd_active_provider', sanitize_text_field( wp_unslash( $_POST['aiwd_active_provider'] ) ) );
            }
        } elseif ( $tab === 'openai' ) {
            if ( isset( $_POST['aiwd_openai_api_key'] ) ) {
                update_option( 'aiwd_openai_api_key', sanitize_text_field( wp_unslash( $_POST['aiwd_openai_api_key'] ) ) );
            }
            if ( isset( $_POST['aiwd_openai_model'] ) ) {
                $model = sanitize_text_field( wp_unslash( $_POST['aiwd_openai_model'] ) );
                if ( $model === 'custom' && isset( $_POST['aiwd_openai_custom_model'] ) ) {
                    $model = sanitize_text_field( wp_unslash( $_POST['aiwd_openai_custom_model'] ) );
                }
                update_option( 'aiwd_openai_model', $model );
            }
            if ( isset( $_POST['aiwd_openai_temperature'] ) ) {
                update_option( 'aiwd_openai_temperature', sanitize_text_field( wp_unslash( $_POST['aiwd_openai_temperature'] ) ) );
            }
        } elseif ( $tab === 'claude' ) {
            if ( isset( $_POST['aiwd_claude_api_key'] ) ) {
                update_option( 'aiwd_claude_api_key', sanitize_text_field( wp_unslash( $_POST['aiwd_claude_api_key'] ) ) );
            }
            if ( isset( $_POST['aiwd_claude_model'] ) ) {
                $model = sanitize_text_field( wp_unslash( $_POST['aiwd_claude_model'] ) );
                if ( $model === 'custom' && isset( $_POST['aiwd_claude_custom_model'] ) ) {
                    $model = sanitize_text_field( wp_unslash( $_POST['aiwd_claude_custom_model'] ) );
                }
                update_option( 'aiwd_claude_model', $model );
            }
            if ( isset( $_POST['aiwd_claude_temperature'] ) ) {
                update_option( 'aiwd_claude_temperature', sanitize_text_field( wp_unslash( $_POST['aiwd_claude_temperature'] ) ) );
            }
        } elseif ( $tab === 'compatible' ) {
            if ( isset( $_POST['aiwd_compatible_api_key'] ) ) {
                update_option( 'aiwd_compatible_api_key', sanitize_text_field( wp_unslash( $_POST['aiwd_compatible_api_key'] ) ) );
            }
            if ( isset( $_POST['aiwd_compatible_endpoint'] ) ) {
                update_option( 'aiwd_compatible_endpoint', esc_url_raw( wp_unslash( $_POST['aiwd_compatible_endpoint'] ) ) );
            }
            if ( isset( $_POST['aiwd_compatible_model'] ) ) {
                update_option( 'aiwd_compatible_model', sanitize_text_field( wp_unslash( $_POST['aiwd_compatible_model'] ) ) );
            }
            if ( isset( $_POST['aiwd_compatible_temperature'] ) ) {
                update_option( 'aiwd_compatible_temperature', sanitize_text_field( wp_unslash( $_POST['aiwd_compatible_temperature'] ) ) );
            }
        } elseif ( $tab === 'gemini' ) {
            if ( isset( $_POST['aiwd_gemini_api_key'] ) ) {
                update_option( 'aiwd_gemini_api_key', sanitize_text_field( wp_unslash( $_POST['aiwd_gemini_api_key'] ) ) );
            }
            if ( isset( $_POST['aiwd_gemini_model'] ) ) {
                $model = sanitize_text_field( wp_unslash( $_POST['aiwd_gemini_model'] ) );
                if ( $model === 'custom' && isset( $_POST['aiwd_gemini_custom_model'] ) ) {
                    $model = sanitize_text_field( wp_unslash( $_POST['aiwd_gemini_custom_model'] ) );
                }
                update_option( 'aiwd_gemini_model', $model );
            }
            if ( isset( $_POST['aiwd_gemini_temperature'] ) ) {
                update_option( 'aiwd_gemini_temperature', sanitize_text_field( wp_unslash( $_POST['aiwd_gemini_temperature'] ) ) );
            }
        } elseif ( $tab === 'brand' ) {
            if ( isset( $_POST['aiwd_brand_name'] ) ) {
                update_option( 'aiwd_brand_name', sanitize_text_field( wp_unslash( $_POST['aiwd_brand_name'] ) ) );
            }
            if ( isset( $_POST['aiwd_brand_description'] ) ) {
                update_option( 'aiwd_brand_description', sanitize_textarea_field( wp_unslash( $_POST['aiwd_brand_description'] ) ) );
            }
            if ( isset( $_POST['aiwd_brand_website'] ) ) {
                update_option( 'aiwd_brand_website', sanitize_text_field( wp_unslash( $_POST['aiwd_brand_website'] ) ) );
            }
            if ( isset( $_POST['aiwd_brand_contact_name'] ) ) {
                update_option( 'aiwd_brand_contact_name', sanitize_text_field( wp_unslash( $_POST['aiwd_brand_contact_name'] ) ) );
            }
            if ( isset( $_POST['aiwd_brand_contact_phone'] ) ) {
                update_option( 'aiwd_brand_contact_phone', sanitize_text_field( wp_unslash( $_POST['aiwd_brand_contact_phone'] ) ) );
            }
        }
    }
    
    /**
     * Test connection
     */
    private static function test_connection() {
        if ( ! isset( $_POST['provider_test_target'] ) ) {
            return;
        }
        
        $provider = sanitize_text_field( wp_unslash( $_POST['provider_test_target'] ) );
        $result   = AIWD_Article_Generator::test_provider( $provider );
        
        if ( $result['success'] ) {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $result['message'] ) . '</p></div>';
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>' . esc_html( $result['message'] ) . '</p></div>';
        }
    }
}
