<?php
/**
 * Article Generator Class
 * (Đã tích hợp bóc tách Meta Tags tự động cho Rank Math SEO an toàn 100%)
 *
 * @package AI_Writer_Drafts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once plugin_dir_path( __FILE__ ) . 'class-prompt-builder.php';
require_once plugin_dir_path( __FILE__ ) . 'class-openai-provider.php';
require_once plugin_dir_path( __FILE__ ) . 'class-claude-provider.php';
require_once plugin_dir_path( __FILE__ ) . 'class-openai-compatible-provider.php';

class AIWD_Article_Generator {
    
    /**
     * Generate article and create draft post
     *
     * @param array $params Article parameters.
     * @return array {
     *     @type bool   $success  Whether generation was successful.
     *     @type int    $post_id  Created post ID if successful.
     *     @type string $content  Generated content.
     *     @type string $error    Error message if failed.
     * }
     */
    public static function generate_article( $params ) {
        // Increase execution time limit for long AI responses
        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 600 ); // 10 minutes
        }
        
        // Ensure database connection before starting
        self::ensure_db_connection();
        
        // Get active provider
        $active_provider = get_option( 'aiwd_active_provider', 'openai' );
        
        // Get provider instance
        $provider = self::get_provider_instance( $active_provider );
        
        if ( is_wp_error( $provider ) ) {
            return array(
                'success' => false,
                'error'   => $provider->get_error_message(),
            );
        }
        
        // Build prompt
        $prompt = AIWD_Prompt_Builder::build_article_prompt( $params );
        
        // Generate content
        $result = $provider->generate_content( $prompt );
        
        if ( ! $result['success'] ) {
            return array(
                'success' => false,
                'error'   => $result['error'],
            );
        }
        
        $content = $result['content'];
        
        // Clean up content (remove markdown code blocks if present)
        $content = self::clean_content( $content );
        
        // ====================================================================
        // THUẬT TOÁN BÓC TÁCH META TAGS RANK MATH (An toàn 100% với Tiếng Việt)
        // ====================================================================
        $meta_title = '';
        $meta_desc  = '';
        
        // Dùng hàm an toàn (mb_strrpos) để tìm cụm Meta Title cuối bài
        $pos = mb_strrpos( $content, 'Meta Title:', 0, 'UTF-8' );
        
        if ( $pos !== false ) {
            // Tìm thẻ <div mở gần nhất trước cụm này
            $div_start = mb_strrpos( mb_substr( $content, 0, $pos, 'UTF-8' ), '<div', 0, 'UTF-8' );
            
            if ( $div_start !== false ) {
                // Cắt phần block Meta ra để lấy dữ liệu
                $meta_block = mb_substr( $content, $div_start, null, 'UTF-8' );
                
                // Lấy Title bằng Regex nhẹ trên một cụm nhỏ
                if ( preg_match( '/Meta Title:.*?<\/strong>\s*(.*?)(?:<br|<\/div)/isu', $meta_block, $m_title ) ) {
                    $meta_title = trim( wp_strip_all_tags( $m_title[1] ) );
                }
                
                // Lấy Description
                if ( preg_match( '/Meta Description:.*?<\/strong>\s*(.*?)(?:<\/div>|$)/isu', $meta_block, $m_desc ) ) {
                    $meta_desc = trim( wp_strip_all_tags( $m_desc[1] ) );
                }
                
                // XÓA phần Meta ra khỏi bài viết gốc để giao diện sạch sẽ
                $content = trim( mb_substr( $content, 0, $div_start, 'UTF-8' ) );
            }
        }
        // ====================================================================
        
        // Validate content length (max 5MB)
        $content_length = strlen( $content );
        $max_length = 5000000; // 5MB limit
        
        if ( $content_length > $max_length ) {
            return array(
                'success' => false,
                'content' => $content,
                'error'   => sprintf(
                    /* translators: %s: content length */
                    __( 'Nội dung quá dài (%s ký tự). Vui lòng thử lại với yêu cầu ngắn hơn.', 'ai-writer-drafts' ),
                    number_format( $content_length )
                ),
            );
        }
        
        // Reconnect database before saving (connection may have timed out during AI generation)
        self::ensure_db_connection();
        
        // Create draft post with retry logic
        $post_id = self::create_draft_post( $params['topic'], $content, $params );
        
        if ( is_wp_error( $post_id ) ) {
            return array(
                'success' => false,
                'content' => $content,
                'error'   => $post_id->get_error_message(),
            );
        }

        // ====================================================================
        // BƠM DỮ LIỆU VÀO RANK MATH TỰ ĐỘNG
        // ====================================================================
        if ( ! empty( $meta_title ) ) {
            update_post_meta( $post_id, 'rank_math_title', sanitize_text_field( $meta_title ) );
        }
        
        if ( ! empty( $meta_desc ) ) {
            update_post_meta( $post_id, 'rank_math_description', sanitize_textarea_field( $meta_desc ) );
        }

        if ( ! empty( $params['main_keyword'] ) ) {
            update_post_meta( $post_id, 'rank_math_focus_keyword', sanitize_text_field( $params['main_keyword'] ) );
        }
        // ====================================================================
        
        return array(
            'success' => true,
            'post_id' => $post_id,
            'content' => $content,
        );
    }
    
    /**
     * Get provider instance
     *
     * @param string $provider_name Provider name.
     * @return AIWD_AI_Provider_Base|WP_Error
     */
    private static function get_provider_instance( $provider_name ) {
        switch ( $provider_name ) {
            case 'openai':
                $api_key = get_option( 'aiwd_openai_api_key', '' );
                $model   = get_option( 'aiwd_openai_model', 'gpt-4o-mini' );
                $temp    = get_option( 'aiwd_openai_temperature', 0.7 );
                
                if ( empty( $api_key ) ) {
                    return new WP_Error( 'no_api_key', __( 'OpenAI API key chưa được cấu hình', 'ai-writer-drafts' ) );
                }
                
                return new AIWD_OpenAI_Provider( array(
                    'api_key'     => $api_key,
                    'model'       => $model,
                    'temperature' => floatval( $temp ),
                ) );
                
            case 'claude':
                $api_key = get_option( 'aiwd_claude_api_key', '' );
                $model   = get_option( 'aiwd_claude_model', 'claude-3-5-sonnet-20241022' );
                $temp    = get_option( 'aiwd_claude_temperature', 0.7 );
                
                if ( empty( $api_key ) ) {
                    return new WP_Error( 'no_api_key', __( 'Claude API key chưa được cấu hình', 'ai-writer-drafts' ) );
                }
                
                return new AIWD_Claude_Provider( array(
                    'api_key'     => $api_key,
                    'model'       => $model,
                    'temperature' => floatval( $temp ),
                ) );
                
            case 'openai_compatible':
                $api_key  = get_option( 'aiwd_compatible_api_key', '' );
                $endpoint = get_option( 'aiwd_compatible_endpoint', '' );
                $model    = get_option( 'aiwd_compatible_model', 'gpt-3.5-turbo' );
                $temp     = get_option( 'aiwd_compatible_temperature', 0.7 );
                
                if ( empty( $api_key ) || empty( $endpoint ) ) {
                    return new WP_Error( 'no_config', __( 'API tương thích OpenAI chưa được cấu hình đầy đủ', 'ai-writer-drafts' ) );
                }
                
                return new AIWD_OpenAI_Compatible_Provider( array(
                    'api_key'     => $api_key,
                    'endpoint'    => $endpoint,
                    'model'       => $model,
                    'temperature' => floatval( $temp ),
                ) );
                
            case 'gemini':
                $api_key = get_option( 'aiwd_gemini_api_key', '' );
                $model   = get_option( 'aiwd_gemini_model', 'gemini-2.5-flash' );
                $temp    = get_option( 'aiwd_gemini_temperature', 0.7 );
                
                if ( empty( $api_key ) ) {
                    return new WP_Error( 'no_api_key', __( 'Gemini API key chưa được cấu hình', 'ai-writer-drafts' ) );
                }
                
                return new AIWD_Gemini_Provider( array(
                    'api_key'     => $api_key,
                    'model'       => $model,
                    'temperature' => floatval( $temp ),
                ) );
                
            default:
                return new WP_Error( 'invalid_provider', __( 'Nhà cung cấp AI không hợp lệ', 'ai-writer-drafts' ) );
        }
    }
    
    /**
     * Ensure database connection is alive
     */
    private static function ensure_db_connection() {
        global $wpdb;
        
        // Check if connection is alive and reconnect if needed
        if ( ! $wpdb->check_connection( false ) ) {
            $wpdb->db_connect();
        }
    }
    
    /**
     * Insert post with retry logic for connection errors
     *
     * @param array $post_data Post data array.
     * @param int   $max_retries Maximum retry attempts.
     * @return int|WP_Error Post ID or error.
     */
    private static function insert_post_with_retry( $post_data, $max_retries = 3 ) {
        global $wpdb;
        
        for ( $i = 0; $i < $max_retries; $i++ ) {
            // Ensure connection before each attempt
            self::ensure_db_connection();
            
            // Attempt to insert post
            $post_id = wp_insert_post( $post_data, true );
            
            // If successful, return immediately
            if ( ! is_wp_error( $post_id ) && $post_id > 0 ) {
                return $post_id;
            }
            
            // Check if error is connection-related
            $is_connection_error = false;
            
            if ( is_wp_error( $post_id ) ) {
                $error_message = strtolower( $post_id->get_error_message() );
                $is_connection_error = stripos( $error_message, 'lost connection' ) !== false ||
                                      stripos( $error_message, 'gone away' ) !== false ||
                                      stripos( $error_message, 'connection' ) !== false;
            }
            
            if ( ! empty( $wpdb->last_error ) ) {
                $db_error = strtolower( $wpdb->last_error );
                $is_connection_error = $is_connection_error ||
                                      stripos( $db_error, 'lost connection' ) !== false ||
                                      stripos( $db_error, 'gone away' ) !== false ||
                                      stripos( $db_error, 'connection' ) !== false;
            }
            
            // If not a connection error, don't retry
            if ( ! $is_connection_error ) {
                return $post_id;
            }
            
            // Wait before retry (exponential backoff)
            if ( $i < $max_retries - 1 ) {
                sleep( pow( 2, $i ) ); // 1s, 2s, 4s
            }
        }
        
        // All retries failed
        return $post_id;
    }
    
    /**
     * Clean generated content
     *
     * @param string $content Raw content from AI.
     * @return string Cleaned content.
     */
    private static function clean_content( $content ) {
        // Remove markdown code blocks (```html ... ```)
        $content = preg_replace( '/```html\s*/i', '', $content );
        $content = preg_replace( '/```\s*$/i', '', $content );
        $content = preg_replace( '/```/i', '', $content );
        
        return trim( $content );
    }
    
    /**
     * Create WordPress draft post
     *
     * @param string $title   Post title.
     * @param string $content Post content.
     * @param array  $meta    Additional meta data.
     * @return int|WP_Error Post ID or error.
     */
    private static function create_draft_post( $title, $content, $meta = array() ) {
        // Validate inputs
        if ( empty( $title ) ) {
            return new WP_Error( 'empty_title', __( 'Tiêu đề bài viết không được để trống', 'ai-writer-drafts' ) );
        }
        
        if ( empty( $content ) ) {
            return new WP_Error( 'empty_content', __( 'Nội dung bài viết không được để trống', 'ai-writer-drafts' ) );
        }
        
        // Check user capability
        if ( ! current_user_can( 'edit_posts' ) ) {
            return new WP_Error( 'insufficient_permissions', __( 'Bạn không có quyền tạo bài viết', 'ai-writer-drafts' ) );
        }
        
        // Ensure database connection before inserting
        self::ensure_db_connection();
        
        $post_data = array(
            'post_title'   => wp_strip_all_tags( $title ),
            'post_content' => $content,
            'post_status'  => 'draft',
            'post_type'    => 'post',
            'post_author'  => get_current_user_id(),
        );
        
        // Use retry logic for inserting post
        $post_id = self::insert_post_with_retry( $post_data, 3 );
        
        if ( is_wp_error( $post_id ) ) {
            global $wpdb;
            $db_error = $wpdb->last_error ? ' | Database Error: ' . $wpdb->last_error : '';
            $full_error = $post_id->get_error_message() . $db_error;
            
            // Add helpful troubleshooting tip for connection errors
            if ( stripos( $full_error, 'lost connection' ) !== false || 
                 stripos( $full_error, 'gone away' ) !== false ) {
                $full_error .= __( ' | Gợi ý: Nội dung có thể quá dài hoặc kết nối database timeout. Hãy thử với yêu cầu ngắn hơn.', 'ai-writer-drafts' );
            }
            
            return new WP_Error(
                $post_id->get_error_code(),
                sprintf(
                    /* translators: %s: detailed error message */
                    __( 'Không thể tạo bài viết. Chi tiết: %s', 'ai-writer-drafts' ),
                    $full_error
                )
            );
        }
        
        if ( ! $post_id || $post_id === 0 ) {
            global $wpdb;
            $db_error = $wpdb->last_error;
            $error_message = __( 'Không thể tạo bài viết', 'ai-writer-drafts' );
            
            if ( ! empty( $db_error ) ) {
                $error_message .= sprintf(
                    /* translators: %s: database error message */
                    __( '. Lỗi database: %s', 'ai-writer-drafts' ),
                    $db_error
                );
            } else {
                $error_message .= __( '. Vui lòng kiểm tra quyền truy cập cơ sở dữ liệu và bảng wp_posts.', 'ai-writer-drafts' );
            }
            
            return new WP_Error( 'post_creation_failed', $error_message );
        }
        
        // Save meta data
        if ( ! empty( $meta['main_keyword'] ) ) {
            update_post_meta( $post_id, '_aiwd_main_keyword', sanitize_text_field( $meta['main_keyword'] ) );
        }
        
        if ( ! empty( $meta['secondary_keywords'] ) ) {
            update_post_meta( $post_id, '_aiwd_secondary_keywords', sanitize_text_field( $meta['secondary_keywords'] ) );
        }
        
        if ( ! empty( $meta['word_count'] ) ) {
            update_post_meta( $post_id, '_aiwd_target_word_count', intval( $meta['word_count'] ) );
        }
        
        update_post_meta( $post_id, '_aiwd_generated', true );
        update_post_meta( $post_id, '_aiwd_generated_date', current_time( 'mysql' ) );
        
        return $post_id;
    }
    
    /**
     * Test provider connection
     *
     * @param string $provider_name Provider name.
     * @return array
     */
    public static function test_provider( $provider_name ) {
        $provider = self::get_provider_instance( $provider_name );
        
        if ( is_wp_error( $provider ) ) {
            return array(
                'success' => false,
                'message' => $provider->get_error_message(),
            );
        }
        
        return $provider->test_connection();
    }
}
