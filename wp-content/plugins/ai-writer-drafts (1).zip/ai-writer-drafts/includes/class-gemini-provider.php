<?php
/**
 * Google Gemini Provider Implementation
 *
 * @package AI_Writer_Drafts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once plugin_dir_path( __FILE__ ) . 'class-ai-provider-base.php';

class AIWD_Gemini_Provider extends AIWD_AI_Provider_Base {
    
    /**
     * Provider name
     *
     * @var string
     */
    protected $provider_name = 'Gemini';
    
    /**
     * API endpoint base
     *
     * @var string
     */
    protected $api_endpoint_base = 'https://generativelanguage.googleapis.com/v1beta/models/';
    
    /**
     * Constructor
     *
     * @param array $config Configuration array.
     */
    public function __construct( $config = array() ) {
        parent::__construct( $config );
        
        // Default model
        if ( empty( $this->model ) ) {
            $this->model = 'gemini-2.5-flash';
        }
    }
    
    /**
     * Generate article content
     *
     * @param string $prompt The prompt to generate content from.
     * @return array
     */
    public function generate_content( $prompt ) {
        if ( ! $this->validate_api_key() ) {
            return array(
                'success' => false,
                'error'   => __( 'API key không hợp lệ', 'ai-writer-drafts' ),
            );
        }
        
        // Build API endpoint with API key
        $url = $this->api_endpoint_base . $this->model . ':generateContent?key=' . $this->api_key;
        
        // Parse combined prompt to extract system instruction and user content
        $system_instruction = '';
        $user_content = $prompt;
        
        if ( strpos( $prompt, 'SYSTEM:' ) !== false && strpos( $prompt, 'USER:' ) !== false ) {
            $parts = explode( 'USER:', $prompt, 2 );
            if ( count( $parts ) === 2 ) {
                $system_instruction = trim( str_replace( 'SYSTEM:', '', $parts[0] ) );
                $user_content = trim( $parts[1] );
            }
        }
        
        // Build request body following Gemini API format
        $body = array(
            'contents' => array(
                array(
                    'parts' => array(
                        array(
                            'text' => $user_content,
                        ),
                    ),
                ),
            ),
            'generationConfig' => array(
                'temperature'     => $this->temperature,
            ),
        );
        
        // Add system instruction if present
        if ( ! empty( $system_instruction ) ) {
            $body['systemInstruction'] = array(
                'parts' => array(
                    array(
                        'text' => $system_instruction,
                    ),
                ),
            );
        }
        
        $headers = array(
            'Content-Type' => 'application/json',
        );
        
        $response = $this->make_request( $url, $body, $headers, 180 );
        
        if ( is_wp_error( $response ) ) {
            return array(
                'success' => false,
                'error'   => 'Gemini API Error: ' . $this->parse_error( $response ),
            );
        }
        
        $code = wp_remote_retrieve_response_code( $response );
        
        if ( $code !== 200 ) {
            $error_msg = $this->parse_error( $response );
            
            // Provide more helpful error messages based on HTTP code
            if ( $code === 400 ) {
                $error_msg = 'Yêu cầu không hợp lệ. Kiểm tra model name hoặc request format.';
            } elseif ( $code === 401 || $code === 403 ) {
                $error_msg = 'API key không đúng hoặc không có quyền truy cập.';
            } elseif ( $code === 404 ) {
                $error_msg = 'Model "' . $this->model . '" không tồn tại. Vui lòng kiểm tra tên model.';
            } elseif ( $code === 429 ) {
                $error_msg = 'Vượt quá giới hạn rate limit. Vui lòng thử lại sau.';
            } elseif ( $code === 500 || $code === 503 ) {
                $error_msg = 'Gemini server đang gặp sự cố. Vui lòng thử lại sau.';
            }
            
            return array(
                'success' => false,
                'error'   => 'Gemini API Error (HTTP ' . $code . '): ' . $error_msg,
            );
        }
        
        $response_body = wp_remote_retrieve_body( $response );
        $data = json_decode( $response_body, true );
        
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return array(
                'success' => false,
                'error'   => 'Không thể parse JSON response từ Gemini API',
            );
        }
        
        // Check for API error in response
        if ( isset( $data['error'] ) ) {
            $error_message = isset( $data['error']['message'] ) ? $data['error']['message'] : 'Unknown error';
            return array(
                'success' => false,
                'error'   => 'Gemini API Error: ' . $error_message,
            );
        }
        
        // Gemini API returns content in candidates[0].content.parts[0].text
        if ( ! isset( $data['candidates'][0]['content']['parts'][0]['text'] ) ) {
            // Check if content was blocked
            if ( isset( $data['candidates'][0]['finishReason'] ) ) {
                $finish_reason = $data['candidates'][0]['finishReason'];
                if ( $finish_reason === 'SAFETY' ) {
                    return array(
                        'success' => false,
                        'error'   => 'Nội dung bị chặn bởi bộ lọc an toàn của Gemini. Hãy thử với prompt khác.',
                    );
                } elseif ( $finish_reason === 'RECITATION' ) {
                    return array(
                        'success' => false,
                        'error'   => 'Nội dung bị chặn do vi phạm chính sách trích dẫn.',
                    );
                }
            }
            
            return array(
                'success' => false,
                'error'   => __( 'Không nhận được nội dung từ Gemini API', 'ai-writer-drafts' ),
            );
        }
        
        return array(
            'success' => true,
            'content' => $data['candidates'][0]['content']['parts'][0]['text'],
        );
    }
    
    /**
     * Test API connection
     *
     * @return array
     */
    public function test_connection() {
        if ( ! $this->validate_api_key() ) {
            return array(
                'success' => false,
                'message' => __( 'API key không hợp lệ', 'ai-writer-drafts' ),
            );
        }
        
        // Build API endpoint with API key
        $url = $this->api_endpoint_base . $this->model . ':generateContent?key=' . $this->api_key;
        
        $body = array(
            'contents' => array(
                array(
                    'parts' => array(
                        array(
                            'text' => 'Hello',
                        ),
                    ),
                ),
            ),
        );
        
        $headers = array(
            'Content-Type' => 'application/json',
        );
        
        $response = $this->make_request( $url, $body, $headers, 30 );
        
        if ( is_wp_error( $response ) ) {
            return array(
                'success' => false,
                'message' => $this->parse_error( $response ),
            );
        }
        
        $code = wp_remote_retrieve_response_code( $response );
        if ( $code !== 200 ) {
            return array(
                'success' => false,
                'message' => $this->parse_error( $response ),
            );
        }
        
        return array(
            'success' => true,
            'message' => __( 'Kết nối thành công với Google Gemini!', 'ai-writer-drafts' ),
        );
    }
}
