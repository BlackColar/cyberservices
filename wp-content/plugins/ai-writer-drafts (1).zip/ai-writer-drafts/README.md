# AI Writer Drafts - Plugin WordPress

**Version:** 2.3  
**Author:** Phạm Ngọc Tú  
**Website:** [congcuseoai.com](https://congcuseoai.com/)

## 📖 Giới Thiệu

AI Writer Drafts là plugin WordPress mạnh mẽ giúp bạn tạo nội dung bài viết chất lượng cao tự động bằng AI. Plugin hỗ trợ nhiều nhà cung cấp AI hàng đầu:

- **OpenAI** (GPT-4o, GPT-4o-mini, o1-preview...)
- **Claude** (Claude 3.5 Sonnet, Claude 4.5...)
- **Google Gemini** (Gemini 2.5 Flash, Gemini 3.0 Flash...)
- **OpenAI Compatible** (Groq, Together AI, MegaLLM...)

## ✨ Tính Năng Chính

### 🎯 Tạo Nội Dung AI

- Tạo bài viết tự động từ chủ đề và từ khóa
- Hỗ trợ nhiều cấu trúc bài viết (SEO, Listicle, How-to, Review, Comparison)
- Tùy chỉnh phong cách viết (Chuyên nghiệp, Thân thiện, Hài hước...)
- Điều chỉnh độ dài bài viết (1000-3000 từ)

### 🤖 Đa Dạng AI Models

- **OpenAI**: GPT-4o, GPT-4o-mini, o1-preview, GPT-4 Turbo
- **Claude**: Claude 4.5 Sonnet, Claude 3.5 Sonnet, Claude 3.5 Haiku
- **Gemini**: Gemini 3.0 Flash, Gemini 2.5 Pro/Flash, Gemini 1.5 Pro/Flash
- **Compatible**: Hỗ trợ bất kỳ API tương thích OpenAI nào

### 📝 Quản Lý Nội Dung

- Tự động lưu thành bản nháp WordPress
- Lưu metadata: từ khóa chính, từ khóa phụ, thời gian tạo
  - Hoặc upload file ZIP qua WordPress Admin

2. **Kích hoạt plugin:**
   - Vào **Plugins** → Tìm **AI Writer Drafts**
   - Click **Activate**

3. **Cấu hình:**
   - Vào **Settings** → **Cấu hình AI Writer**
   - Chọn nhà cung cấp AI và nhập API key

## ⚙️ Cấu Hình Chi Tiết

### 1️⃣ OpenAI (Khuyên Dùng)

#### Lấy API Key

1. Truy cập [OpenAI Platform](https://platform.openai.com/api-keys)
2. Đăng nhập/Đăng ký tài khoản
3. Click **Create new secret key**
4. Copy API key

#### Cấu Hình

1. **Settings** → **Cấu hình AI Writer** → **OpenAI**
2. Dán API Key vào trường **OpenAI API Key**
3. Chọn Model:
   - **GPT-4o-mini** (Khuyên dùng) - Hiệu quả, rẻ
   - **GPT-4o** - Thông minh hơn, đắt hơn
   - **o1-preview** - Reasoning mạnh nhất
4. Temperature: 0.7 (mặc định)
5. Click **Lưu & Test Kết Nối**

**💰 Chi Phí:**

- GPT-4o-mini: ~$0.15/1M tokens input, ~$0.60/1M tokens output
- GPT-4o: ~$2.50/1M tokens input, ~$10.00/1M tokens output

---

### 2️⃣ Claude (Anthropic)

#### Lấy API Key

1. Truy cập [Anthropic Console](https://console.anthropic.com/settings/keys)
2. Đăng ký tài khoản
3. Click **Create Key**
4. Copy API key

#### Cấu Hình

1. **Settings** → **Cấu hình AI Writer** → **Claude**
2. Dán API Key vào trường **Claude API Key**
3. Chọn Model:
   - **Claude 4.5 Sonnet** (Mới nhất, chất lượng tốt nhất)
   - **Claude 3.5 Sonnet** - Cân bằng giá/chất lượng
   - **Claude 3.5 Haiku** - Nhanh & rẻ
4. Temperature: 0.7 (mặc định)
5. Click **Lưu & Test Kết Nối**

**💰 Chi Phí:**

- Claude 3.5 Haiku: ~$0.80/1M tokens input, ~$4.00/1M tokens output
- Claude 3.5 Sonnet: ~$3.00/1M tokens input, ~$15.00/1M tokens output

---

### 3️⃣ Google Gemini (Miễn Phí!)

#### Lấy API Key

1. Truy cập [Google AI Studio](https://aistudio.google.com/apikey)
2. Đăng nhập bằng Google Account
3. Click **Get API Key** → **Create API Key**
4. Copy API key

#### Cấu Hình

1. **Settings** → **Cấu hình AI Writer** → **Gemini**
2. Dán API Key vào trường **Gemini API Key**
3. Chọn Model:
   - **Gemini 2.5 Flash** (Khuyên dùng) - Nhanh, miễn phí
   - **Gemini 3.0 Flash** - Mới nhất
   - **Gemini 2.5 Pro** - Chất lượng cao nhất
4. Temperature: 0.7 (mặc định)
5. Click **Lưu & Test Kết Nối**

**💰 Chi Phí:**

- **Miễn phí** với giới hạn:
  - 15 requests/minute
  - 1M tokens/minute
  - 1,500 requests/day

---

### 4️⃣ Tương Thích OpenAI (API Shared)

#### Nhà Cung Cấp Khuyên Dùng

**MegaLLM** (Giá rẻ nhất)

- Website: [megallm.io](https://megallm.io/ref/REF-13C1XVNR)
- Endpoint: `https://ai.megallm.io/v1/chat/completions`
- Models: GPT-4, GPT-4o, Claude 3.5, Gemini Pro...

**Open Router**

- Website: [openrouter.ai](https://openrouter.ai)
- Endpoint: `https://openrouter.ai/api/v1/chat/completions`

**llm.ai**

- Website: [llm.ai.vn](https://llm.ai.vn/register?aff=odmh)
- API Shared giá rẻ

#### Cấu Hình

1. **Settings** → **Cấu hình AI Writer** → **Tương Thích OpenAI**
2. Nhập **API Endpoint** (VD: `https://ai.megallm.io/v1/chat/completions`)
3. Dán **API Key** từ nhà cung cấp
4. Nhập **Model Name** chính xác (VD: `gpt-4o-mini`, `llama-3.3-70b-versatile`)
5. Click **Lưu & Test Kết Nối**

**💡 Ưu điểm:** Giá rẻ hơn nhiều so với API chính thức

---

## 📝 Hướng Dẫn Sử Dụng

### Bước 1: Chọn Provider

1. Vào **Settings** → **Cấu hình AI Writer** → **Cài Đặt Chung**
2. Chọn nhà cung cấp AI muốn sử dụng
3. Click **Lưu Cài Đặt**

### Bước 2: Tạo Bài Viết

1. Vào **Posts** → **AI Writer**
2. Điền thông tin:

#### Thông Tin Cơ Bản

- **Chủ đề bài viết** *(Bắt buộc)*: VD "10 cách tối ưu SEO cho website WordPress"
- **Từ khóa chính** *(Bắt buộc)*: VD "tối ưu SEO"
- **Từ khóa phụ**: VD "SEO on-page, meta tags, sitemap"

#### Tùy Chọn Nâng Cao

- **Lĩnh vực**: Marketing, Sức khỏe, Công nghệ...
- **Đối tượng mục tiêu**: Chủ doanh nghiệp nhỏ, Người mới bắt đầu...
- **Số từ**: 1000, 1500, 2000, 2500, 3000 từ
- **Cấu trúc**: Bài viết chuẩn SEO, Listicle, How-to, Review, Comparison
- **Phong cách**: Chuyên nghiệp, Thân thiện, Hài hước, Học thuật, Thuyết phục
- **Search Intent**: Informational, Commercial, Transactional, Navigational

#### Hướng Dẫn Nội Dung

- Nhập các yêu cầu cụ thể về nội dung
- VD: "Tập trung vào on-page SEO, đề cập đến meta tags, sitemap, internal linking..."

### Bước 3: Tạo Bài

1. Click **Viết Bài Ngay**
2. Chờ 30-60 giây (tùy độ dài bài viết)
3. Xem preview bài viết ở cột bên phải

### Bước 4: Chỉnh Sửa & Xuất Bản

1. Click **Sửa bài ngay** để mở bản nháp trong WordPress Editor
2. Chỉnh sửa nội dung nếu cần
3. Thêm featured image, categories, tags
4. Click **Publish** để xuất bản

## 🎯 Tips Viết Bài Hiệu Quả

### ✅ Nên

- Viết chủ đề cụ thể, rõ ràng
- Sử dụng từ khóa chính ngắn gọn (2-4 từ)
- Điền đầy đủ thông tin để AI hiểu ngữ cảnh
- Bắt đầu với bài ngắn (1000-1500 từ) để test
- Thử nhiều provider khác nhau để so sánh chất lượng

### ❌ Không Nên

- Viết chủ đề quá chung chung ("Viết về marketing")
- Dùng từ khóa quá dài hoặc nhiều từ khóa
- Bỏ trống toàn bộ thông tin tùy chọn
- Yêu cầu bài quá dài (>3000 từ) ngay từ đầu

### 💡 Khuyến Nghị Model

**Cho blog thông thường:**

- Gemini 2.5 Flash (miễn phí, chất lượng tốt)
- GPT-4o-mini (rẻ, hiệu quả)
- Claude 3.5 Haiku (nhanh, cân bằng)

**Cho nội dung premium:**

- GPT-4o (chất lượng cao)
- Claude 4.5 Sonnet (mới nhất)
- Gemini 2.5 Pro (miễn phí, chất lượng tốt)

**Cho technical writing:**

- o1-preview (reasoning mạnh)
- Claude 3.5 Sonnet (hiểu context tốt)

## ❓ FAQ - Câu Hỏi Thường Gặp

### Q: Plugin có miễn phí không?

**A:** Plugin miễn phí 100%. Bạn chỉ cần trả phí cho API của nhà cung cấp AI (OpenAI, Claude). Gemini thì miễn phí với giới hạn hợp lý.

### Q: Tôi nên chọn provider nào?

**A:**

- **Miễn phí**: Gemini (15 requests/phút, 1500/ngày)
- **Giá rẻ**: GPT-4o-mini hoặc MegaLLM
- **Chất lượng cao**: GPT-4o, Claude 4.5 Sonnet

### Q: Bài viết có chuẩn SEO không?

**A:** Có! Plugin tối ưu cho SEO với:

- Cấu trúc heading (H1, H2, H3) chuẩn
- Phân bố từ khóa tự nhiên
- Nội dung dài, chi tiết
- Call-to-action phù hợp

### Q: Tôi có thể chỉnh sửa bài viết sau khi tạo?

**A:** Có! Bài viết được lưu dạng draft, bạn có thể:

- Chỉnh sửa nội dung
- Thêm hình ảnh
- Sửa format
- Thêm links

### Q: API key có an toàn không?

**A:** Có! API key được lưu trong database WordPress với WordPress security standards.

### Q: Bài viết bị lỗi "Timeout"?

**A:**

- Giảm số từ xuống 1000-1500
- Đơn giản hóa yêu cầu
- Thử provider khác
- Kiểm tra internet connection

### Q: Gemini báo "Content blocked by safety filter"?

**A:**

- Thay đổi chủ đề trung lập hơn
- Tránh từ khóa nhạy cảm
- Viết lại prompt chuyên nghiệp hơn

### Q: Chi phí sử dụng khoảng bao nhiêu?

**A:**

- **Gemini**: Miễn phí (đủ cho 50-100 bài/ngày)
- **GPT-4o-mini**: ~$0.10-0.20/bài (1500-2000 từ)
- **GPT-4o**: ~$0.50-1.00/bài
- **Claude 3.5**: ~$0.30-0.60/bài

## 🛠️ Troubleshooting

### Lỗi: "API key không hợp lệ"

**Giải pháp:**

1. Kiểm tra API key có đúng không
2. Kiểm tra đã copy đầy đủ (không thiếu ký tự)
3. Tạo API key mới

### Lỗi: "Model không tồn tại"

**Giải pháp:**

1. Kiểm tra tên model chính xác
2. Thử model mặc định (gemini-2.5-flash, gpt-4o-mini)
3. Xem docs của provider để biết tên model

### Lỗi: "Rate limit exceeded"

**Giải pháp:**

1. Đợi 1-2 phút
2. Nâng cấp plan (nếu dùng API chính thức)
3. Đổi sang provider khác tạm thời

### Lỗi: "Không thể tạo bài viết"

**Giải pháp:**

1. Kiểm tra user có quyền `edit_posts`
2. Kiểm tra database connection
3. Xem WordPress debug log

## 📞 Hỗ Trợ

**Tác giả:** Phạm Ngọc Tú  
**Điện thoại:** 0896009111  
**Website:** [congcuseoai.com](https://congcuseoai.com/)  
**Donate:** 688859999 - Ngân hàng VIB ☕

---

## 📄 License

GPL v2 or later

---

## 📋 Changelog

### Version 2.3 (24/11/2024)

**🎨 Tính Năng Mới:**

- ✅ **Phong cách viết động**: Sử dụng phong cách viết từ dữ liệu nhập vào của người dùng
- ✅ **Cải thiện prompt builder**: Prompt tự động điều chỉnh theo phong cách được chọn

### Version 2.2 (24/11/2024)

**🚀 Cải Tiến Lớn:**

- ✅ **Loại bỏ giới hạn max_tokens**: AI có thể tạo nội dung dài không giới hạn
- ✅ **Fix lỗi MySQL timeout**: Tự động reconnect database khi tạo bài dài
- ✅ **Retry logic**: Tự động thử lại 3 lần khi có lỗi kết nối database
- ✅ **Tăng timeout**: Từ 5 phút lên 10 phút cho bài viết dài
- ✅ **Giới hạn content**: Tối đa 5MB để tránh lỗi server
- ✅ **Error handling**: Thông báo lỗi chi tiết hơn với gợi ý khắc phục

**🐛 Bug Fixes:**

- Fixed "Lost connection to MySQL server during query" error
- Fixed "Unsupported parameter: 'max_tokens'" error với OpenAI models
- Improved database connection stability
- Better error messages for connection issues

**⚡ Performance:**

- Exponential backoff retry (1s, 2s, 4s) cho database operations
- Automatic database reconnection trước/sau AI generation
- Content length validation để tránh overload

### Version 2.1.5 (24/11/2024)

- Cải thiện prompt builder
- Thêm brand settings
- Fix lỗi duplicate content

### Version 2.1.4 (24/11/2024)

- Loại bỏ H1 heading trong content
- Optimize prompt structure

### Version 2.1.3 (23/11/2024)

- Initial release
- Hỗ trợ OpenAI, Claude, Gemini
- Tạo bài viết tự động với AI

---

## 📄 License

GPL v2 or later

---

## 🎉 Cảm Ơn

Cảm ơn bạn đã sử dụng AI Writer Drafts! Nếu plugin hữu ích, hãy chia sẻ cho bạn bè và đồng nghiệp nhé! 🚀
