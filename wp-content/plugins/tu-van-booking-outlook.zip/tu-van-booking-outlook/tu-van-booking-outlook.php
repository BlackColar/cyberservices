<?php
/**
 * Plugin Name: Đặt Lịch Tư Vấn Ultimate Pro (Microsoft 365 & Teams Full Automation)
 * Description: Hệ thống đặt lịch cao cấp: Chặn trùng lịch Outlook thời gian thực (getSchedule), tạo Teams Meeting tự động, nhắc lịch hẹn qua Cron, hỗ trợ khách tự hủy lịch và trang cấu hình API an toàn.
 * Version: 3.1.0
 * Author: Custom Dev (Secured & Optimized)
 */

if (!defined('ABSPATH')) exit;

// -------------------------------------------------------------
// 1. MENU QUẢN LÝ VÀ TRANG CÀI ĐẶT (SETTINGS PAGE)
// -------------------------------------------------------------
add_action('admin_menu', function() {
    add_submenu_page(
        'edit.php?post_type=booking_consult',
        'Cài Đặt Microsoft Graph API',
        'Cài Đặt Cấu Hình',
        'manage_options',
        'ms-booking-settings',
        'render_ms_booking_settings_page'
    );
});

add_action('admin_init', function() {
    register_setting('ms_booking_settings_group', 'ms_tenant_id', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('ms_booking_settings_group', 'ms_client_id', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('ms_booking_settings_group', 'ms_client_secret', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('ms_booking_settings_group', 'ms_user_email', ['sanitize_callback' => 'sanitize_email']);
    register_setting('ms_booking_settings_group', 'ms_meeting_duration', ['default' => 45, 'sanitize_callback' => 'absint']);
    register_setting('ms_booking_settings_group', 'ms_buffer_time', ['default' => 15, 'sanitize_callback' => 'absint']);
    register_setting('ms_booking_settings_group', 'ms_lead_time', ['default' => 2, 'sanitize_callback' => 'absint']);
    register_setting('ms_booking_settings_group', 'ms_work_slots', ['default' => '08:30, 09:30, 10:30, 11:30, 13:30, 14:30, 15:30, 16:30', 'sanitize_callback' => 'sanitize_text_field']);
    register_setting('ms_booking_settings_group', 'ms_thankyou_url', ['sanitize_callback' => 'esc_url_raw']);
});

function render_ms_booking_settings_page() { ?>
    <div class="wrap">
        <h2>Cấu Hình Đặt Lịch Microsoft 365 & Teams</h2>
        <form method="post" action="options.php">
            <?php settings_fields('ms_booking_settings_group'); ?>
            <table class="form-table">
                <tr>
                    <th>Directory (tenant) ID</th>
                    <td><input type="text" name="ms_tenant_id" value="<?php echo esc_attr(get_option('ms_tenant_id')); ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th>Application (client) ID</th>
                    <td><input type="text" name="ms_client_id" value="<?php echo esc_attr(get_option('ms_client_id')); ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th>Client Secret Value</th>
                    <td>
                        <input type="password" name="ms_client_secret" value="<?php echo esc_attr(get_option('ms_client_secret')); ?>" class="regular-text" required autocomplete="new-password">
                        <p class="description">Secret từ Azure App Registration (Application Permissions: Calendars.ReadWrite, OnlineMeetings.ReadWrite).</p>
                    </td>
                </tr>
                <tr>
                    <th>Email Hộp Thư Outlook (User Principal Name)</th>
                    <td><input type="email" name="ms_user_email" value="<?php echo esc_attr(get_option('ms_user_email')); ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th>Các khung giờ làm việc cố định</th>
                    <td>
                        <input type="text" name="ms_work_slots" value="<?php echo esc_attr(get_option('ms_work_slots', '08:30, 09:30, 10:30, 11:30, 13:30, 14:30, 15:30, 16:30')); ?>" class="large-text">
                        <p class="description">Phân cách các khung giờ bắt đầu bằng dấu phẩy (Ví dụ: 08:30, 09:30, 10:30, 14:00, 15:00)</p>
                    </td>
                </tr>
                <tr>
                    <th>Thời lượng 1 buổi họp (Phút)</th>
                    <td><input type="number" name="ms_meeting_duration" value="<?php echo esc_attr(get_option('ms_meeting_duration', 45)); ?>" class="small-text" min="15" step="5"></td>
                </tr>
                <tr>
                    <th>Thời gian đệm nghỉ giữa các ca - Buffer (Phút)</th>
                    <td><input type="number" name="ms_buffer_time" value="<?php echo esc_attr(get_option('ms_buffer_time', 15)); ?>" class="small-text" min="0" step="5"></td>
                </tr>
                <tr>
                    <th>Chặn đặt trước sát giờ - Lead Time (Tiếng)</th>
                    <td><input type="number" name="ms_lead_time" value="<?php echo esc_attr(get_option('ms_lead_time', 2)); ?>" class="small-text" min="0"></td>
                </tr>
                <tr>
                    <th>URL Trang Cảm Ơn</th>
                    <td><input type="url" name="ms_thankyou_url" value="<?php echo esc_attr(get_option('ms_thankyou_url')); ?>" class="regular-text" placeholder="https://domain.com/dat-lich-thanh-cong/"></td>
                </tr>
            </table>
            <?php submit_button('Lưu Cấu Hình'); ?>
        </form>
    </div>
<?php }

// -------------------------------------------------------------
// 2. KHỞI TẠO POST TYPE VÀ CÁC CỘT DỮ LIỆU
// -------------------------------------------------------------
add_action('init', function() {
    register_post_type('booking_consult', [
        'labels' => [
            'name'          => 'Lịch Hẹn Tư Vấn',
            'singular_name' => 'Lịch Hẹn',
            'menu_name'     => 'Lịch Hẹn Teams/Outlook',
        ],
        'public'       => false,
        'show_ui'      => true,
        'show_in_menu' => true,
        'menu_icon'    => 'dashicons-calendar-alt',
        'supports'     => ['title'],
    ]);
});

add_filter('manage_booking_consult_posts_columns', function($cols) {
    return [
        'cb'           => $cols['cb'],
        'title'        => 'Khách Hàng',
        'client_phone' => 'SĐT',
        'client_email' => 'Email',
        'booking_time' => 'Thời Gian',
        'status'       => 'Trạng Thái',
        'teams_url'    => 'Link Microsoft Teams',
    ];
});

add_action('manage_booking_consult_posts_custom_column', function($col, $post_id) {
    if ($col === 'client_phone') echo esc_html(get_post_meta($post_id, '_client_phone', true));
    if ($col === 'client_email') echo esc_html(get_post_meta($post_id, '_client_email', true));
    if ($col === 'booking_time') {
        $date = get_post_meta($post_id, '_booking_date', true);
        $time = get_post_meta($post_id, '_booking_time', true);
        echo esc_html("{$time} - {$date}");
    }
    if ($col === 'status') {
        $status = get_post_meta($post_id, '_booking_status', true) ?: 'confirmed';
        if ($status === 'cancelled') {
            echo '<span style="color:#d9534f; font-weight:bold;">Đã Hủy</span>';
        } else {
            echo '<span style="color:#28a745; font-weight:bold;">Đã Xác Nhận</span>';
        }
    }
    if ($col === 'teams_url') {
        $link = get_post_meta($post_id, '_teams_url', true);
        if ($link) {
            echo '<a href="' . esc_url($link) . '" target="_blank" style="color: #0078d4; font-weight: bold;">Vào họp Teams</a>';
        } else {
            echo '<span style="color: #999;">—</span>';
        }
    }
}, 10, 2);

// -------------------------------------------------------------
// 3. MICROSOFT GRAPH API ENGINE
// -------------------------------------------------------------
function ms_get_access_token() {
    $token = get_transient('ms_graph_access_token_v3');
    if ($token) return $token;

    $tenant_id = get_option('ms_tenant_id');
    $client_id = get_option('ms_client_id');
    $secret    = get_option('ms_client_secret');

    if (!$tenant_id || !$client_id || !$secret) return false;

    $url = "https://login.microsoftonline.com/{$tenant_id}/oauth2/v2.0/token";
    $response = wp_remote_post($url, [
        'body' => [
            'client_id'     => $client_id,
            'client_secret' => $secret,
            'scope'         => 'https://graph.microsoft.com/.default',
            'grant_type'    => 'client_credentials',
        ],
        'timeout' => 15,
    ]);

    if (is_wp_error($response)) return false;

    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (!empty($data['access_token'])) {
        $expires = isset($data['expires_in']) ? (int) $data['expires_in'] : 3600;
        set_transient('ms_graph_access_token_v3', $data['access_token'], max(60, $expires - 300));
        return $data['access_token'];
    }

    return false;
}

// -------------------------------------------------------------
// 4. CORE: KIỂM TRA LỊCH TRỐNG (REUSABLE CHECK ENGINE)
// -------------------------------------------------------------
function ms_get_available_slots_for_date($date) {
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        return [];
    }

    $user_email = get_option('ms_user_email');
    $duration   = (int) get_option('ms_meeting_duration', 45);
    $buffer     = (int) get_option('ms_buffer_time', 15);
    $lead_hours = (int) get_option('ms_lead_time', 2);

    $work_slots_str = get_option('ms_work_slots', '08:30, 09:30, 10:30, 11:30, 13:30, 14:30, 15:30, 16:30');
    $work_slots = array_filter(array_map('trim', explode(',', $work_slots_str)));

    $token = ms_get_access_token();
    $busy_times = [];

    if ($token && $user_email) {
        $url = 'https://graph.microsoft.com/v1.0/users/' . rawurlencode($user_email) . '/calendar/getSchedule';
        $body = [
            'schedules'                => [$user_email],
            'startTime'                => ['dateTime' => "{$date}T00:00:00", 'timeZone' => 'SE Asia Standard Time'],
            'endTime'                  => ['dateTime' => "{$date}T23:59:59", 'timeZone' => 'SE Asia Standard Time'],
            'availabilityViewInterval' => 15,
        ];

        $res = wp_remote_post($url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
            ],
            'body'    => json_encode($body),
            'timeout' => 15,
        ]);

        if (!is_wp_error($res)) {
            $data = json_decode(wp_remote_retrieve_body($res), true);
            if (!empty($data['value'][0]['scheduleItems'])) {
                foreach ($data['value'][0]['scheduleItems'] as $item) {
                    if (isset($item['status']) && $item['status'] !== 'free') {
                        $tz = new DateTimeZone('Asia/Ho_Chi_Minh');
                        $start_obj = new DateTime($item['start']['dateTime'], $tz);
                        $end_obj   = new DateTime($item['end']['dateTime'], $tz);
                        $busy_times[] = [
                            'start' => $start_obj->getTimestamp(),
                            'end'   => $end_obj->getTimestamp(),
                        ];
                    }
                }
            }
        }
    }

    $tz = new DateTimeZone('Asia/Ho_Chi_Minh');
    $now_ts = (new DateTime('now', $tz))->getTimestamp();
    $min_bookable_time = $now_ts + ($lead_hours * 3600);
    $available_slots = [];

    foreach ($work_slots as $slot) {
        if (!preg_match('/^\d{2}:\d{2}$/', $slot)) continue;

        $slot_start_dt = new DateTime("{$date} {$slot}:00", $tz);
        $slot_start = $slot_start_dt->getTimestamp();
        $slot_end   = $slot_start + ($duration * 60);

        // Chặn đặt sát giờ (Lead Time)
        if ($slot_start < $min_bookable_time) {
            continue;
        }

        // Kiểm tra xung đột với lịch Outlook đã có
        $is_busy = false;
        foreach ($busy_times as $busy) {
            $busy_start_buffered = $busy['start'] - ($buffer * 60);
            $busy_end_buffered   = $busy['end'] + ($buffer * 60);

            if ($slot_start < $busy_end_buffered && $slot_end > $busy_start_buffered) {
                $is_busy = true;
                break;
            }
        }

        if (!$is_busy) {
            $available_slots[] = $slot;
        }
    }

    return $available_slots;
}

// -------------------------------------------------------------
// 5. AJAX HANDLER: TẢI KHUNG GIỜ CÒN TRỐNG (CÓ NONCE & RATE LIMIT)
// -------------------------------------------------------------
add_action('wp_ajax_get_available_slots', 'handle_get_available_slots');
add_action('wp_ajax_nopriv_get_available_slots', 'handle_get_available_slots');

function handle_get_available_slots() {
    check_ajax_referer('ultimate_booking_nonce', 'security');

    $date = sanitize_text_field($_POST['date'] ?? '');
    if (!$date || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        wp_send_json_error('Ngày được chọn không đúng định dạng.');
    }

    // Rate limiting theo IP tránh spam API Graph
    $ip = sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
    $transient_key = 'ms_slot_limit_' . md5($ip);
    $requests = (int) get_transient($transient_key);
    if ($requests > 30) {
        wp_send_json_error('Bạn đã thao tác quá nhiều lần. Vui lòng chờ 1 phút.');
    }
    set_transient($transient_key, $requests + 1, 60);

    $slots = ms_get_available_slots_for_date($date);
    wp_send_json_success($slots);
}

// -------------------------------------------------------------
// 6. XỬ LÝ ĐẶT LỊCH (SUBMIT FORM - CÓ RACE CONDITION CHECK)
// -------------------------------------------------------------
add_action('admin_post_nopriv_submit_ultimate_booking', 'process_ultimate_booking');
add_action('admin_post_submit_ultimate_booking', 'process_ultimate_booking');

function process_ultimate_booking() {
    if (!isset($_POST['bk_nonce']) || !wp_verify_nonce($_POST['bk_nonce'], 'ultimate_booking_nonce')) {
        wp_die('Lỗi bảo mật! Phiên làm việc đã hết hạn. Vui lòng thử lại.');
    }

    $name  = sanitize_text_field($_POST['client_name'] ?? '');
    $email = sanitize_email($_POST['client_email'] ?? '');
    $phone = sanitize_text_field($_POST['client_phone'] ?? '');
    $date  = sanitize_text_field($_POST['booking_date'] ?? '');
    $time  = sanitize_text_field($_POST['booking_time'] ?? '');

    if (!$name || !is_email($email) || !$phone || !$date || !$time) {
        wp_die('Vui lòng điền đầy đủ và chính xác tất cả thông tin.');
    }

    // BẢO VỆ RACE CONDITION: Kiểm tra lại slot trống ngay trước khi ghi nhận
    $available_slots = ms_get_available_slots_for_date($date);
    if (!in_array($time, $available_slots, true)) {
        wp_die("
            <div style='font-family: Arial, sans-serif; padding:40px; text-align:center; max-width:500px; margin:auto;'>
                <h3 style='color:#d9534f;'>Khung giờ vừa có người đặt</h3>
                <p>Khung giờ <strong>" . esc_html($time) . "</strong> ngày <strong>" . esc_html($date) . "</strong> vừa được khách hàng khác đặt hoặc không còn khả dụng.</p>
                <p><a href='javascript:history.back()' style='color:#0078d4; font-weight:bold;'>← Quay lại để chọn giờ khác</a></p>
            </div>
        ");
    }

    $duration       = (int) get_option('ms_meeting_duration', 45);
    $user_email     = get_option('ms_user_email');
    $cancel_token   = wp_generate_password(32, false);
    
    $tz = new DateTimeZone('Asia/Ho_Chi_Minh');
    $start_dt_obj   = new DateTime("{$date} {$time}:00", $tz);
    $end_dt_obj     = (clone $start_dt_obj)->modify("+{$duration} minutes");

    $start_dt_iso   = $start_dt_obj->format('Y-m-d\TH:i:s');
    $end_dt_iso     = $end_dt_obj->format('Y-m-d\TH:i:s');
    $formatted_date = $start_dt_obj->format('d/m/Y');

    $cancel_url     = add_query_arg(['action_booking' => 'cancel', 'token' => $cancel_token], home_url('/'));

    // 1. Tạo Meeting trên Graph API (Online Teams Meeting)
    $token = ms_get_access_token();
    $event_id  = '';
    $teams_url = '';

    if ($token && $user_email) {
        $safe_name  = esc_html($name);
        $safe_phone = esc_html($phone);
        $safe_time  = esc_html($time);

        $meeting_body = "
        <div style='font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Arial, sans-serif; max-width:600px; margin:auto; background:#fff; border:1px solid #edebe9; border-radius:8px; overflow:hidden;'>
            <div style='background:#0078d4; padding:20px; color:#fff;'>
                <h2 style='margin:0; font-size:20px;'>Xác Nhận Lịch Hẹn Tư Vấn Trực Tuyến</h2>
            </div>
            <div style='padding:20px;'>
                <p>Xin chào <strong>{$safe_name}</strong>,</p>
                <p>Buổi tư vấn của bạn đã được thiết lập thành công trên hệ thống:</p>
                <ul>
                    <li><strong>Thời gian:</strong> {$safe_time} - Ngày {$formatted_date}</li>
                    <li><strong>Hình thức:</strong> Trực tuyến qua Microsoft Teams</li>
                    <li><strong>Số điện thoại liên hệ:</strong> {$safe_phone}</li>
                </ul>
                <div style='margin-top:20px; padding:12px; background:#fff4ce; border-radius:4px; font-size:13px;'>
                    Nếu bạn có việc đột xuất cần đổi lịch hoặc hủy hẹn? <a href='" . esc_url($cancel_url) . "' style='color:#a80000; font-weight:bold;'>Bấm vào đây để hủy lịch hẹn</a>.
                </div>
            </div>
        </div>";

        $url = 'https://graph.microsoft.com/v1.0/users/' . rawurlencode($user_email) . '/events';
        $res = wp_remote_post($url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
            ],
            'body'    => json_encode([
                'subject' => "Tư vấn: {$name} ({$phone})",
                'body'    => ['contentType' => 'HTML', 'content' => $meeting_body],
                'start'   => ['dateTime' => $start_dt_iso, 'timeZone' => 'SE Asia Standard Time'],
                'end'     => ['dateTime' => $end_dt_iso, 'timeZone' => 'SE Asia Standard Time'],
                'attendees' => [
                    ['emailAddress' => ['address' => $email, 'name' => $name], 'type' => 'required']
                ],
                'isOnlineMeeting' => true,
                'onlineMeetingProvider' => 'teamsForBusiness',
            ]),
            'timeout' => 20,
        ]);

        if (!is_wp_error($res)) {
            $data = json_decode(wp_remote_retrieve_body($res), true);
            $event_id  = $data['id'] ?? '';
            $teams_url = $data['onlineMeeting']['joinUrl'] ?? '';
        }
    }

    // 2. Lưu vào Cơ sở dữ liệu CPT
    $post_id = wp_insert_post([
        'post_title'  => sanitize_text_field("{$name} - {$phone}"),
        'post_type'   => 'booking_consult',
        'post_status' => 'publish',
    ]);

    if ($post_id) {
        update_post_meta($post_id, '_client_name', $name);
        update_post_meta($post_id, '_client_email', $email);
        update_post_meta($post_id, '_client_phone', $phone);
        update_post_meta($post_id, '_booking_date', $date);
        update_post_meta($post_id, '_booking_time', $time);
        update_post_meta($post_id, '_teams_url', esc_url_raw($teams_url));
        update_post_meta($post_id, '_ms_event_id', sanitize_text_field($event_id));
        update_post_meta($post_id, '_cancel_token', $cancel_token);
        update_post_meta($post_id, '_booking_status', 'confirmed');

        // 3. Tự động hẹn giờ nhắc lịch (Cron Job trước 1 tiếng, chuẩn hóa UTC timestamp)
        $reminder_time = $start_dt_obj->getTimestamp() - 3600;
        if ($reminder_time > time()) {
            wp_schedule_single_event($reminder_time, 'ms_booking_send_reminder', [$post_id]);
        }

        // 4. Chuyển hướng trang cảm ơn (hoặc thông báo an toàn)
        $thankyou_url = get_option('ms_thankyou_url');
        if ($thankyou_url) {
            $redirect = add_query_arg([
                'booking_id' => $post_id,
                'name'       => urlencode($name),
                'date'       => $date,
                'time'       => $time,
            ], $thankyou_url);
            wp_safe_redirect($redirect);
            exit;
        }

        wp_die("
            <div style='font-family: Arial, sans-serif; padding:30px; text-align:center; max-width:550px; margin:40px auto; border:1px solid #dcdcdc; border-radius:8px;'>
                <h2 style='color:#28a745; margin-top:0;'>🎉 Đặt Lịch Thành Công!</h2>
                <p>Khách hàng: <strong>" . esc_html($name) . "</strong> | SĐT: <strong>" . esc_html($phone) . "</strong></p>
                <p>Thời gian: <strong>" . esc_html($time) . " - " . esc_html($formatted_date) . "</strong></p>" .
                ($teams_url ? "<p style='margin-top:15px;'><a href='" . esc_url($teams_url) . "' target='_blank' style='background:#0078d4; color:#fff; padding:10px 18px; text-decoration:none; border-radius:4px; font-weight:bold; display:inline-block;'>👉 Link Họp Teams</a></p>" : "") . "
                <p style='margin-top:25px;'><a href='" . esc_url(home_url()) . "' style='color:#0078d4;'>Về trang chủ</a></p>
            </div>
        ");
    }
}

// -------------------------------------------------------------
// 7. XỬ LÝ GỬI EMAIL NHẮC LỊCH QUA WP-CRON
// -------------------------------------------------------------
add_action('ms_booking_send_reminder', function($post_id) {
    $status = get_post_meta($post_id, '_booking_status', true);
    if ($status === 'cancelled') return;

    $email     = get_post_meta($post_id, '_client_email', true);
    $name      = get_post_meta($post_id, '_client_name', true);
    $time      = get_post_meta($post_id, '_booking_time', true);
    $date      = get_post_meta($post_id, '_booking_date', true);
    $teams_url = get_post_meta($post_id, '_teams_url', true);

    if (!$email) return;

    $subject = "[Nhắc nhở] Buổi tư vấn trực tuyến sẽ bắt đầu sau 1 giờ";
    $safe_name = esc_html($name);
    $safe_time = esc_html($time);
    $safe_date = esc_html($date);

    $message = "
        <div style='font-family: Arial, sans-serif; padding: 20px; line-height:1.6;'>
            <h3>Chào {$safe_name},</h3>
            <p>Buổi tư vấn trực tuyến của bạn sẽ bắt đầu vào lúc <strong>{$safe_time}</strong> hôm nay ({$safe_date}).</p>
            " . ($teams_url ? "<p style='margin-top:20px;'><a href='" . esc_url($teams_url) . "' style='display:inline-block; padding:12px 20px; background:#0078d4; color:#fff; text-decoration:none; border-radius:4px; font-weight:bold;'>👉 Bấm Vào Đây Để Tham Gia Họp Teams</a></p>" : "") . "
            <p style='color:#666; font-size:13px; margin-top:25px;'>Nếu cần hỗ trợ kỹ thuật trước cuộc họp, vui lòng phản hồi lại email này.</p>
        </div>
    ";
    wp_mail($email, $subject, $message, ['Content-Type: text/html; charset=UTF-8']);
});

// -------------------------------------------------------------
// 8. XỬ LÝ KHÁCH HỦY LỊCH HẸN (CANCEL / RESCHEDULE)
// -------------------------------------------------------------
add_action('template_redirect', function() {
    if (isset($_GET['action_booking']) && $_GET['action_booking'] === 'cancel' && !empty($_GET['token'])) {
        $token = sanitize_text_field($_GET['token']);
        $posts = get_posts([
            'post_type'   => 'booking_consult',
            'meta_key'    => '_cancel_token',
            'meta_value'  => $token,
            'post_status' => 'publish',
            'numberposts' => 1,
        ]);

        if (empty($posts)) {
            wp_die('Yêu cầu không hợp lệ hoặc liên kết hủy hẹn đã hết hạn.');
        }

        $post_id  = $posts[0]->ID;
        $status   = get_post_meta($post_id, '_booking_status', true);

        if ($status === 'cancelled') {
            wp_die("
                <div style='font-family: Arial, sans-serif; padding:40px; text-align:center; max-width:500px; margin:auto;'>
                    <h3 style='color:#666;'>Lịch hẹn này đã được hủy trước đó.</h3>
                    <p><a href='" . esc_url(home_url()) . "' style='color:#0078d4;'>Về trang chủ</a></p>
                </div>
            ");
        }

        $event_id = get_post_meta($post_id, '_ms_event_id', true);

        // 1. Gọi Graph API để xóa cuộc họp trên Outlook/Teams
        $access_token = ms_get_access_token();
        $user_email   = get_option('ms_user_email');
        if ($access_token && $user_email && $event_id) {
            $url = 'https://graph.microsoft.com/v1.0/users/' . rawurlencode($user_email) . '/events/' . $event_id;
            wp_remote_request($url, [
                'method'  => 'DELETE',
                'headers' => ['Authorization' => 'Bearer ' . $access_token],
                'timeout' => 15,
            ]);
        }

        // 2. Cập nhật trạng thái
        update_post_meta($post_id, '_booking_status', 'cancelled');

        // 3. Xóa sự kiện cron nhắc lịch hẹn nếu có
        $next_cron = wp_next_scheduled('ms_booking_send_reminder', [$post_id]);
        if ($next_cron) {
            wp_unschedule_event($next_cron, 'ms_booking_send_reminder', [$post_id]);
        }

        wp_die("
            <div style='font-family: Arial, sans-serif; padding:40px; text-align:center; max-width:500px; margin:40px auto; border:1px solid #eee; border-radius:8px;'>
                <h2 style='color:#d9534f; margin-top:0;'>Đã Hủy Lịch Hẹn Thành Công</h2>
                <p>Lịch hẹn của bạn đã được giải phóng khỏi hệ thống và Calendar của tư vấn viên.</p>
                <p style='margin-top:20px;'><a href='" . esc_url(home_url()) . "' style='background:#0078d4; color:#fff; padding:10px 18px; text-decoration:none; border-radius:4px; font-weight:bold; display:inline-block;'>Về trang chủ để đặt lịch mới</a></p>
            </div>
        ");
    }
});

// -------------------------------------------------------------
// 9. SHORTCODE POPUP VÀ FORM ĐẶT LỊCH REAL-TIME
// -------------------------------------------------------------
add_shortcode('dat_lich_popup', function($atts) {
    $args = shortcode_atts(['nut_bam' => 'Đặt lịch tư vấn trực tuyến'], $atts);
    $nonce = wp_create_nonce('ultimate_booking_nonce');
    ob_start(); ?>

    <button type="button" class="btn-open-booking-modal" onclick="toggleBookingModal(true)">
        <span class="dashicons dashicons-calendar-alt" style="margin-right: 6px;"></span>
        <?php echo esc_html($args['nut_bam']); ?>
    </button>

    <div id="bookingModalOverlay" class="bk-modal-overlay" onclick="handleOverlayClick(event)">
        <div class="bk-modal-box">
            <button type="button" class="bk-close-btn" onclick="toggleBookingModal(false)">&times;</button>
            <h3 class="bk-title">Đặt Lịch Tư Vấn Trực Tuyến</h3>
            <p class="bk-desc">Chọn ngày để kiểm tra các khung giờ trống theo thời gian thực.</p>
            
            <form method="POST" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" id="ultimateBookingForm">
                <input type="hidden" name="action" value="submit_ultimate_booking">
                <input type="hidden" name="bk_nonce" value="<?php echo esc_attr($nonce); ?>">

                <div class="bk-group">
                    <label>Họ và tên *</label>
                    <input type="text" name="client_name" placeholder="Ví dụ: Nguyễn Văn A" required>
                </div>
                <div class="bk-group">
                    <label>Email *</label>
                    <input type="email" name="client_email" placeholder="example@domain.com" required>
                </div>
                <div class="bk-group">
                    <label>Số điện thoại *</label>
                    <input type="tel" name="client_phone" placeholder="0988xxxxxx" required>
                </div>
                <div class="bk-row">
                    <div class="bk-group">
                        <label>Ngày hẹn *</label>
                        <input type="date" name="booking_date" id="bookingDateInput" min="<?php echo date('Y-m-d'); ?>" required onchange="fetchAvailableSlots(this.value)">
                    </div>
                    <div class="bk-group">
                        <label>Khung giờ *</label>
                        <select name="booking_time" id="bookingTimeSelect" required disabled>
                            <option value="">-- Chọn ngày trước --</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="bk-submit-btn" id="btnSubmitBooking">Xác Nhận & Thiết Lập Lịch Teams</button>
            </form>
        </div>
    </div>

    <style>
        .btn-open-booking-modal {
            background-color: #0078d4; color: #fff; font-size: 15px; font-weight: 600;
            padding: 12px 22px; border: none; border-radius: 6px; cursor: pointer; display: inline-flex; align-items: center;
        }
        .btn-open-booking-modal:hover { background-color: #106ebe; }
        .bk-modal-overlay {
            display: none; position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
            background: rgba(0,0,0,0.6); z-index: 999999; align-items: center; justify-content: center;
            backdrop-filter: blur(2px); padding: 15px; box-sizing: border-box;
        }
        .bk-modal-overlay.active { display: flex; }
        .bk-modal-box {
            background: #fff; width: 100%; max-width: 450px; border-radius: 8px;
            padding: 25px; position: relative; box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }
        .bk-close-btn { position: absolute; top: 10px; right: 15px; border: none; background: transparent; font-size: 26px; cursor: pointer; color: #888; }
        .bk-title { margin: 0 0 5px 0; font-size: 19px; color: #222; }
        .bk-desc { margin: 0 0 18px 0; font-size: 13px; color: #666; }
        .bk-group { margin-bottom: 12px; text-align: left; }
        .bk-group label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 4px; }
        .bk-group input, .bk-group select {
            width: 100%; padding: 8px 10px; font-size: 14px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box;
        }
        .bk-row { display: flex; gap: 10px; }
        .bk-row .bk-group { flex: 1; }
        .bk-submit-btn {
            width: 100%; background: #0078d4; color: #fff; padding: 11px; font-size: 15px;
            font-weight: bold; border: none; border-radius: 4px; cursor: pointer; margin-top: 10px;
        }
        .bk-submit-btn:hover { background: #106ebe; }
    </style>

    <script>
        function toggleBookingModal(show) {
            const el = document.getElementById('bookingModalOverlay');
            if (!el) return;
            if (show) {
                el.classList.add('active');
                document.body.style.overflow = 'hidden';
            } else {
                el.classList.remove('active');
                document.body.style.overflow = '';
            }
        }
        function handleOverlayClick(e) {
            if (e.target.id === 'bookingModalOverlay') toggleBookingModal(false);
        }
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') toggleBookingModal(false);
        });

        function fetchAvailableSlots(dateVal) {
            const timeSelect = document.getElementById('bookingTimeSelect');
            if (!dateVal) {
                timeSelect.innerHTML = '<option value="">-- Chọn ngày trước --</option>';
                timeSelect.disabled = true;
                return;
            }

            timeSelect.innerHTML = '<option value="">Đang kiểm tra lịch trống...</option>';
            timeSelect.disabled = true;

            const formData = new FormData();
            formData.append('action', 'get_available_slots');
            formData.append('date', dateVal);
            formData.append('security', '<?php echo esc_js($nonce); ?>');

            fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(response => {
                if (response.success && response.data.length > 0) {
                    let html = '<option value="">-- Chọn khung giờ --</option>';
                    response.data.forEach(slot => {
                        html += `<option value="${slot}">${slot}</option>`;
                    });
                    timeSelect.innerHTML = html;
                    timeSelect.disabled = false;
                } else {
                    const msg = (response.data && typeof response.data === 'string') ? response.data : 'Hết lịch trống trong ngày';
                    timeSelect.innerHTML = `<option value="">${msg}</option>`;
                    timeSelect.disabled = true;
                }
            })
            .catch(() => {
                timeSelect.innerHTML = '<option value="">Lỗi kết nối kiểm tra lịch</option>';
                timeSelect.disabled = true;
            });
        }
    </script>
    <?php
    return ob_get_clean();
});