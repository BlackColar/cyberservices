<?php
/**
 * Plugin Name: AI Sales Assistant Chatbox
 * Description: Chatbot AI chuyên nghiệp giao diện Modern Light Theme, trợ lý tư vấn của Cyber Services (Đã tối ưu CRM & Bảo mật).
 * Version: 5.0.0 (Enterprise CRM Version)
 * Author: Cyber Services
 */

if (!defined('ABSPATH')) exit;

class AISalesChatbox {
    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_init', [$this, 'maybe_create_tables']);
        add_action('admin_init', [$this, 'sync_site_views_setting']);
        register_activation_hook(__FILE__, [$this, 'setup_database']);
        register_deactivation_hook(__FILE__, [$this, 'cleanup_on_deactivation']);
        add_action('admin_init', [$this, 'handle_delete_lead']);

        add_action('wp_footer', [$this, 'render_chatbox_ui']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_scripts']);
        
        // Tự động xóa cache kiến thức khi đăng bài mới
        add_action('save_post', [$this, 'clear_post_cache'], 10, 3);

        // Hooks cho xuất file Excel và cập nhật trạng thái CRM
        add_action('admin_post_export_ai_leads', [$this, 'export_leads_csv']);
        add_action('admin_post_ai_chat_create_tables', [$this, 'handle_create_tables']);
        add_action('wp_ajax_update_lead_status', [$this, 'handle_update_status']);
        
        // Hook AJAX xóa hàng loạt Leads
        add_action('wp_ajax_bulk_delete_ai_leads', [$this, 'handle_bulk_delete']);
        // Hook xóa dữ liệu thống kê lượt xem
        add_action('admin_post_clear_ai_stats', [$this, 'handle_clear_stats']);
        // Hook cài đặt Telegram Webhook
        add_action('admin_post_ai_chat_setup_webhook', [$this, 'handle_setup_webhook']);

        add_action('wp_ajax_ai_chat_save_lead', [$this, 'handle_save_lead']);
        add_action('wp_ajax_nopriv_ai_chat_save_lead', [$this, 'handle_save_lead']);
        add_action('wp_ajax_ai_chat_send_message', [$this, 'handle_chat_message']);
        add_action('wp_ajax_nopriv_ai_chat_send_message', [$this, 'handle_chat_message']);
        add_action('wp_ajax_ai_chat_load_history', [$this, 'load_chat_history']);
        add_action('wp_ajax_nopriv_ai_chat_load_history', [$this, 'load_chat_history']);
        
        // Hook theo dõi hành trình duyệt trang (Telegram Tracking)
        add_action('wp_ajax_ai_chat_track_page', [$this, 'handle_track_page']);
        add_action('wp_ajax_nopriv_ai_chat_track_page', [$this, 'handle_track_page']);
        // Hook theo dõi lượt xem toàn site (mọi khách truy cập)
        add_action('wp_ajax_ai_chat_track_site_view', [$this, 'handle_track_site_view']);
        add_action('wp_ajax_nopriv_ai_chat_track_site_view', [$this, 'handle_track_site_view']);
        add_action('ai_chat_onsite_check', [$this, 'onsite_check_callback'], 10, 1);
        
        // Hook đăng ký cổng nhận tin nhắn Telegram Webhook
        add_action('rest_api_init', [$this, 'register_telegram_webhook']);
    }

    /* TẠO CỔNG WEBHOOK NHẬN TIN NHẮN TỪ TELEGRAM */
    public function register_telegram_webhook() {
        register_rest_route('ai-chatbox/v1', '/telegram-webhook', [
            'methods'  => 'POST',
            'callback' => [$this, 'handle_telegram_webhook'],
            'permission_callback' => [$this, 'verify_telegram_webhook_permission']
        ]);
    }

    public function verify_telegram_webhook_permission(WP_REST_Request $request) {
        $token = get_option('ai_chat_telegram_token');
        if (empty($token)) return false;
        
        $secret_header = $request->get_header('x-telegram-bot-api-secret-token');
        $expected_secret = substr(hash('sha256', $token), 0, 32);
        
        // Ưu tiên chuẩn bảo mật Secret Header (được Telegram gửi khi setWebhook có secret_token)
        if ($secret_header && hash_equals($expected_secret, $secret_header)) {
            return true;
        }

        // Fallback AN TOÀN: cho phép khi không có secret header NHƯNG request phải là
        // tin nhắn Reply có kèm ID hợp lệ trong nội dung được reply (chỉ dành cho admin reply).
        $body = $request->get_json_params();
        if (isset($body['message']['reply_to_message']['text'], $body['message']['text'])) {
            $reply_to_text = (string)$body['message']['reply_to_message']['text'];
            if (preg_match('/ID\s*[:：]\s*[<code>]*\s*([a-zA-Z0-9_-]+)/i', $reply_to_text, $matches)) {
                $session_id = sanitize_text_field($matches[1]);
                $lead_exists = (int)$GLOBALS['wpdb']->get_var($GLOBALS['wpdb']->prepare(
                    "SELECT COUNT(*) FROM {$GLOBALS['wpdb']->prefix}ai_chat_leads WHERE session_id = %s",
                    $session_id
                ));
                if ($lead_exists > 0) {
                    return true;
                }
            }
        }
        return false;
    }

    public function handle_telegram_webhook(WP_REST_Request $request) {
        global $wpdb;
        $body = $request->get_json_params();

        if (isset($body['message']['reply_to_message']['text'], $body['message']['text'])) {
            $reply_to_text = (string)$body['message']['reply_to_message']['text'];
            $admin_reply   = sanitize_textarea_field($body['message']['text']);

            if (preg_match('/ID\s*[:：]\s*[<code>]*\s*([a-zA-Z0-9_-]+)/i', $reply_to_text, $matches)) {
                $session_id  = sanitize_text_field($matches[1]);
                $table_chats = $wpdb->prefix . 'ai_chat_history';

                // Chỉ insert khi session_id tồn tại trong DB (chống spam reply với ID giả)
                $lead_exists = $wpdb->get_var($wpdb->prepare(
                    "SELECT id FROM {$wpdb->prefix}ai_chat_leads WHERE session_id = %s LIMIT 1",
                    $session_id
                ));
                if (empty($lead_exists)) {
                    return new WP_REST_Response(['status' => 'invalid_session'], 200);
                }

                $wpdb->insert($table_chats, [
                    'session_id' => $session_id,
                    'sender'     => 'bot',
                    'message'    => "🤵 **(CSKH)**: " . $admin_reply
                ], ['%s', '%s', '%s']);
            }
        }
        return new WP_REST_Response(['status' => 'success'], 200);
    }

    /* XÓA CACHE BÀI VIẾT KHI ĐĂNG BÀI MỚI */
    public function clear_post_cache($post_id, $post, $update) {
        if ($post->post_status === 'publish') {
            delete_transient('ai_chat_posts_cache');
        }
    }

    /* XÓA CACHE KHI TẮT PLUGIN */
    public function cleanup_on_deactivation() {
        delete_transient('ai_chat_posts_cache');
        delete_option('ai_chat_db_version'); // Reset schema version để activation chạy setup lại
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_ai_lead_%' OR option_name LIKE '_transient_ai_rate_limit_%' OR option_name LIKE '_transient_ai_chat_target_flag_%' OR option_name LIKE '_transient_ai_chat_onsite_%'");

        // Xóa các sự kiện WP-Cron onsite còn treo
        wp_clear_scheduled_hook('ai_chat_onsite_check');
    }

    public function enqueue_frontend_scripts() {
        // Luôn tải script để track hành trình (kể cả trang giỏ hàng/thanh toán là trang mục tiêu quan trọng)
        wp_enqueue_style('ai-chatbox-style', plugin_dir_url(__FILE__) . 'assets/css/chatbox.css', [], filemtime(plugin_dir_path(__FILE__) . 'assets/css/chatbox.css'));
        wp_enqueue_script('ai-chatbox-script', plugin_dir_url(__FILE__) . 'assets/js/chatbox.js', [], filemtime(plugin_dir_path(__FILE__) . 'assets/js/chatbox.js'), true);

        wp_localize_script('ai-chatbox-script', 'aiChatboxData', [
            'ajax_url'          => admin_url('admin-ajax.php'),
            'nonce'             => wp_create_nonce('ai_chat_nonce_action'),
            'site_views_enabled'=> get_option('ai_chat_site_views_enabled', '1')
        ]);
    }

    /* 1. DATABASE SETUP (Thêm INDEX để tối ưu tốc độ) */
    public function setup_database() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $table_leads = $wpdb->prefix . 'ai_chat_leads';
        $table_chats = $wpdb->prefix . 'ai_chat_history';
        $table_views = $wpdb->prefix . 'ai_chat_page_views';

        $sql_leads = "CREATE TABLE IF NOT EXISTS $table_leads (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            session_id varchar(100) NOT NULL,
            user_name varchar(100) NOT NULL,
            user_phone varchar(50) NOT NULL,
            user_email varchar(100) DEFAULT '',
            page_url text,
            status varchar(50) DEFAULT 'new' NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id),
            KEY session_id (session_id),
            KEY status (status),
            KEY created_at (created_at)
        ) $charset_collate;";

        $sql_chats = "CREATE TABLE IF NOT EXISTS $table_chats (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            session_id varchar(100) NOT NULL,
            sender varchar(10) NOT NULL,
            message text NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id),
            KEY session_id (session_id)
        ) $charset_collate;";

        $sql_views = "CREATE TABLE IF NOT EXISTS $table_views (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            session_id varchar(100) NOT NULL,
            url text NOT NULL,
            title varchar(255) DEFAULT '',
            entered_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            left_at datetime DEFAULT NULL,
            updated_at datetime DEFAULT NULL,
            msg_id varchar(50) DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY session_id (session_id),
            KEY entered_at (entered_at)
        ) $charset_collate;";

        // Bảng theo dõi lượt xem toàn site (mọi khách truy cập, kể cả không chat)
        $table_site_views = $wpdb->prefix . 'ai_chat_site_views';
        $sql_site_views = "CREATE TABLE IF NOT EXISTS $table_site_views (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            session_id varchar(100) NOT NULL,
            url text NOT NULL,
            path varchar(500) NOT NULL,
            title varchar(255) DEFAULT '',
            viewed_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id),
            KEY session_id (session_id),
            KEY path (path),
            KEY viewed_at (viewed_at)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_leads);
        dbDelta($sql_chats);
        dbDelta($sql_views);
        dbDelta($sql_site_views);

        // Fallback: đảm bảo bảng page_views luôn được tạo (dbDelta có thể fail ngầm)
        $table_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_views));
        if (!$table_exists) {
            $wpdb->query("CREATE TABLE IF NOT EXISTS $table_views (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                session_id varchar(100) NOT NULL,
                url text NOT NULL,
                title varchar(255) DEFAULT '',
                entered_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
                left_at datetime DEFAULT NULL,
                updated_at datetime DEFAULT NULL,
                msg_id varchar(50) DEFAULT NULL,
                PRIMARY KEY  (id),
                KEY session_id (session_id),
                KEY entered_at (entered_at)
            ) $charset_collate;");
        }

        // Fallback: đảm bảo bảng site_views luôn được tạo
        $site_views_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_site_views));
        if (!$site_views_exists) {
            $wpdb->query("CREATE TABLE IF NOT EXISTS $table_site_views (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                session_id varchar(100) NOT NULL,
                url text NOT NULL,
                path varchar(500) NOT NULL,
                title varchar(255) DEFAULT '',
                viewed_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
                PRIMARY KEY  (id),
                KEY session_id (session_id),
                KEY path (path),
                KEY viewed_at (viewed_at)
            ) $charset_collate;");
        }
    }

    // Tự động tạo bảng nếu thiếu mỗi khi vào WP Admin (không cần deactivate/activate)
    public function maybe_create_tables() {
        global $wpdb;
        $table_views = $wpdb->prefix . 'ai_chat_page_views';
        $table_exists = $wpdb->get_var($wpdb->prepare(
            "SHOW TABLES LIKE %s",
            $table_views
        ));
        if (!$table_exists) {
            $this->setup_database();
        }

        // Version schema để các lần nâng cấp sau có thể chạy migration
        $current = get_option('ai_chat_db_version', '0');
        if (version_compare($current, '1.2', '<')) {
            $this->setup_database();
            update_option('ai_chat_db_version', '1.2');
        }
    }

    // Nút "Tạo lại bảng dữ liệu" trong settings — chạy setup trực tiếp
    public function handle_create_tables() {
        if (!current_user_can('manage_options')) {
            wp_die('Bạn không có quyền thực hiện thao tác này.');
        }
        check_admin_referer('ai_chat_create_tables_nonce');
        $this->setup_database();
        update_option('ai_chat_db_version', '1.2');
        wp_safe_redirect(admin_url('admin.php?page=ai-chatbox&db_created=1'));
        exit;
    }

    /* 2. XỬ LÝ XÓA LEAD ĐƠN LẺ */
    public function handle_delete_lead() {
        if (isset($_GET['action'], $_GET['lead_id']) && $_GET['action'] === 'delete_lead') {
            $lead_id = (int)$_GET['lead_id'];
            check_admin_referer('delete_lead_' . $lead_id);
            
            if (!current_user_can('manage_options')) {
                wp_die('Bạn không có quyền thực hiện hành động này.');
            }

            global $wpdb;
            $table_leads = $wpdb->prefix . 'ai_chat_leads';
            $table_chats = $wpdb->prefix . 'ai_chat_history';

            $session_id = $wpdb->get_var($wpdb->prepare("SELECT session_id FROM $table_leads WHERE id = %d", $lead_id));
            if ($session_id) {
                $wpdb->delete($table_chats, ['session_id' => $session_id], ['%s']);
                $wpdb->delete($table_leads, ['id' => $lead_id], ['%d']);
            }

            wp_safe_redirect(admin_url('admin.php?page=ai-chatbox-leads&deleted=1'));
            exit;
        }
    }

    /* 2.1 XỬ LÝ XÓA HÀNG LOẠT LEADS */
    public function handle_bulk_delete() {
        check_ajax_referer('ai_admin_leads_nonce', 'security');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Unauthorized']);
        
        global $wpdb;
        $ids = isset($_POST['lead_ids']) ? array_map('intval', (array)$_POST['lead_ids']) : [];
        if (empty($ids)) wp_send_json_error(['message' => 'No IDs provided']);

        $table_leads = $wpdb->prefix . 'ai_chat_leads';
        $table_chats = $wpdb->prefix . 'ai_chat_history';

        foreach ($ids as $lead_id) {
            $session_id = $wpdb->get_var($wpdb->prepare("SELECT session_id FROM $table_leads WHERE id = %d", $lead_id));
            if ($session_id) {
                $wpdb->delete($table_chats, ['session_id' => $session_id], ['%s']);
                $wpdb->delete($table_leads, ['id' => $lead_id], ['%d']);
            }
        }
        wp_send_json_success();
    }

    /* 2.2 XUẤT EXCEL (CSV) - Hỗ trợ xuất danh sách lead và xuất thống kê lượt xem */
    public function export_leads_csv() {
        if (!current_user_can('manage_options')) {
            wp_die('Bạn không có quyền.');
        }
        check_admin_referer('export_ai_leads_action', 'export_nonce');

        // Nếu có tham số stats_export → xuất thống kê lượt xem
        if (isset($_GET['stats_export']) && $_GET['stats_export'] === '1') {
            $this->export_stats_csv();
            return;
        }

        global $wpdb;
        $table_leads = $wpdb->prefix . 'ai_chat_leads';
        $leads = $wpdb->get_results("SELECT created_at, user_name, user_phone, user_email, page_url, status FROM $table_leads ORDER BY id DESC", ARRAY_A);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=Danh_Sach_Khach_Hang_' . date('Ymd_Hi') . '.csv');
        $output = fopen('php://output', 'w');
        
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); 
        fputcsv($output, ['Thời gian', 'Họ Tên', 'Số điện thoại', 'Email', 'Trang đăng ký', 'Trạng thái']);
        
        $status_map = [
            'new'        => 'Mới tiếp nhận',
            'contacting' => 'Đang liên hệ',
            'closed'     => 'Đã chốt hợp đồng',
            'cancelled'  => 'Hủy/Không nghe máy'
        ];

        foreach ($leads as $lead) {
            $lead['status'] = $status_map[$lead['status']] ?? 'Mới tiếp nhận';
            fputcsv($output, $lead);
        }
        fclose($output);
        exit;
    }

    /* Xuất thống kê lượt xem ra CSV */
    private function export_stats_csv() {
        global $wpdb;
        $table_site_views = $wpdb->prefix . 'ai_chat_site_views';

        $stats_from = isset($_GET['stats_from']) ? sanitize_text_field($_GET['stats_from']) : date('Y-m-d', strtotime('-6 days'));
        $stats_to   = isset($_GET['stats_to']) ? sanitize_text_field($_GET['stats_to']) : date('Y-m-d');
        $stats_from = date('Y-m-d', strtotime($stats_from));
        $stats_to   = date('Y-m-d', strtotime($stats_to));

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=Thong_Ke_View_' . $stats_from . '_' . $stats_to . '.csv');
        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

        // Sheet 1: Thống kê theo ngày
        fputcsv($output, ['THỐNG KÊ LƯỢT XEM THEO NGÀY']);
        fputcsv($output, ['Khoảng thời gian:', $stats_from, '→', $stats_to]);
        fputcsv($output, []); // dòng trống
        fputcsv($output, ['Ngày', 'Lượt xem']);
        $day_rows = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(viewed_at) AS d, COUNT(*) AS total FROM $table_site_views
             WHERE DATE(viewed_at) BETWEEN %s AND %s
             GROUP BY DATE(viewed_at) ORDER BY d ASC",
            $stats_from, $stats_to
        ));
        foreach ((array)$day_rows as $r) {
            fputcsv($output, [$r->d, (int)$r->total]);
        }

        fputcsv($output, []); // dòng trống
        fputcsv($output, []); // dòng trống

        // Sheet 2: Top trang
        fputcsv($output, ['TOP TRANG ĐƯỢC XEM NHIỀU NHẤT']);
        fputcsv($output, ['#', 'Đường dẫn', 'Tiêu đề', 'Lượt xem']);
        $page_rows = $wpdb->get_results($wpdb->prepare(
            "SELECT path, title, COUNT(*) AS total FROM $table_site_views
             WHERE DATE(viewed_at) BETWEEN %s AND %s
             GROUP BY path ORDER BY total DESC LIMIT 50",
            $stats_from, $stats_to
        ));
        $rank = 1;
        foreach ((array)$page_rows as $r) {
            fputcsv($output, [$rank++, $r->path, $r->title, (int)$r->total]);
        }

        fclose($output);
        exit;
    }

    /* XÓA DỮ LIỆU THỐNG KÊ LƯỢT XEM */
    public function handle_clear_stats() {
        if (!current_user_can('manage_options')) {
            wp_die('Bạn không có quyền thực hiện thao tác này.');
        }
        check_admin_referer('clear_ai_stats_nonce');

        global $wpdb;
        $table_site_views = $wpdb->prefix . 'ai_chat_site_views';
        $table_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_site_views));
        if ($table_exists) {
            $wpdb->query("TRUNCATE TABLE $table_site_views");
        }

        wp_safe_redirect(admin_url('admin.php?page=ai-chatbox-leads&stats_cleared=1'));
        exit;
    }

    /* CÀI ĐẶT TELEGRAM WEBHOOK (tự động đăng ký secret token với Telegram API) */
    public function handle_setup_webhook() {
        if (!current_user_can('manage_options')) {
            wp_die('Bạn không có quyền thực hiện thao tác này.');
        }
        check_admin_referer('ai_chat_setup_webhook_nonce');

        $token = get_option('ai_chat_telegram_token');
        if (empty($token)) {
            wp_safe_redirect(admin_url('admin.php?page=ai-chat-settings&webhook_error=1'));
            exit;
        }

        $secret_token = substr(hash('sha256', $token), 0, 32);
        $webhook_url  = rest_url('ai-chatbox/v1/telegram-webhook');

        $response = wp_remote_post("https://api.telegram.org/bot{$token}/setWebhook", [
            'body' => [
                'url'          => $webhook_url,
                'secret_token' => $secret_token,
                'allowed_updates' => '["message"]'
            ],
            'sslverify' => true
        ]);

        $success = false;
        if (!is_wp_error($response)) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            $success = isset($body['ok']) && $body['ok'];
        }

        wp_safe_redirect(admin_url('admin.php?page=ai-chat-settings&webhook_setup=' . ($success ? '1' : '0')));
        exit;
    }

    /* 2.3 AJAX CẬP NHẬT TRẠNG THÁI CRM */
    public function handle_update_status() {
        check_ajax_referer('ai_admin_leads_nonce', 'security');
        if (!current_user_can('manage_options')) wp_send_json_error();
        
        global $wpdb;
        $lead_id = intval($_POST['lead_id'] ?? 0);
        $status  = sanitize_key($_POST['status'] ?? 'new');
        
        $allowed_statuses = ['new', 'contacting', 'closed', 'cancelled'];
        if (!in_array($status, $allowed_statuses, true)) {
            wp_send_json_error(['message' => 'Invalid status']);
        }

        $wpdb->update($wpdb->prefix . 'ai_chat_leads', ['status' => $status], ['id' => $lead_id], ['%s'], ['%d']);
        wp_send_json_success();
    }

    /* 3. ADMIN SETTINGS & CRM */
    public function add_admin_menu() {
        add_menu_page('Cyber AI Chatbox', 'Cyber AI Chatbox', 'manage_options', 'ai-chatbox', [$this, 'admin_settings_page'], 'dashicons-format-chat');
        add_submenu_page('ai-chatbox', 'Danh Sách Khách Hàng', 'Khách Hàng (Leads)', 'manage_options', 'ai-chatbox-leads', [$this, 'admin_leads_page']);
    }

    /* Đảm bảo option tracking toàn site luôn có giá trị (checkbox khi bỏ tick không gửi field) */
    public function sync_site_views_setting() {
        // Chỉ chạy khi đang lưu form settings
        if (isset($_POST['option_page']) && $_POST['option_page'] === 'ai_chat_settings_group') {
            if (!isset($_POST['ai_chat_site_views_enabled'])) {
                $_POST['ai_chat_site_views_enabled'] = '0';
            }
        }
    }

    public function register_settings() {
        register_setting('ai_chat_settings_group', 'ai_chat_provider', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('ai_chat_settings_group', 'ai_chat_api_key', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('ai_chat_settings_group', 'ai_chat_kira_base_url', ['sanitize_callback' => 'esc_url_raw']);
        register_setting('ai_chat_settings_group', 'ai_chat_model', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('ai_chat_settings_group', 'ai_chat_system_prompt', ['sanitize_callback' => 'sanitize_textarea_field']);
        register_setting('ai_chat_settings_group', 'ai_chat_custom_knowledge', ['sanitize_callback' => 'sanitize_textarea_field']);
        register_setting('ai_chat_settings_group', 'ai_chat_telegram_token', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('ai_chat_settings_group', 'ai_chat_telegram_chat_id', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('ai_chat_settings_group', 'ai_chat_max_tokens', ['sanitize_callback' => function($val) { return max(100, min(4000, intval($val))); }]);
        register_setting('ai_chat_settings_group', 'ai_chat_tracking_enabled', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('ai_chat_settings_group', 'ai_chat_target_keywords', ['sanitize_callback' => 'sanitize_textarea_field']);
        register_setting('ai_chat_settings_group', 'ai_chat_onsite_timeout', ['sanitize_callback' => function($val) { return max(30, min(600, intval($val))); }]);
        register_setting('ai_chat_settings_group', 'ai_chat_site_views_enabled', ['sanitize_callback' => 'sanitize_text_field']);
    }

    public function admin_settings_page() {
        $provider = get_option('ai_chat_provider', 'kira');
        $model = get_option('ai_chat_model', 'kira-3.5-flash');
        $default_prompt = "Bạn LÀ Mai Hoa, nữ trợ lý tư vấn trực tuyến của Cyber Services.
QUY TẮC BẮT BUỘC:
1. Tuyệt đối KHÔNG bao giờ nhắc đến tên Kira, OpenAI, ChatGPT, 3.5 Flash hay phiên bản AI của bạn.
2. Tuyệt đối KHÔNG cung cấp bất kỳ đường link website nào khác ngoại trừ các link thuộc tên miền cyberservices.vn.
3. Khi tự giới thiệu, luôn nói: 'Dạ, em là Mai Hoa trợ lý tư vấn trực tuyến của Cyber Services.'
4. Trả lời CỰC KỲ NGẮN GỌN (từ 2 đến 3 câu), đúng trọng tâm câu hỏi của khách hàng.
5. Giữ thái độ chuyên nghiệp, thân thiện và lịch sự.";
        ?>
        <div class="wrap">
            <?php if (isset($_GET['db_created'])) : ?>
                <div class="notice notice-success is-dismissible"><p>✅ Bảng dữ liệu đã được tạo/cập nhật thành công!</p></div>
            <?php endif; ?>
            <?php if (isset($_GET['webhook_setup']) && $_GET['webhook_setup'] === '1') : ?>
                <div class="notice notice-success is-dismissible"><p>✅ Webhook Telegram đã được cài đặt thành công! Giờ bạn có thể trả lời khách hàng bằng cách bấm Reply vào tin nhắn trên Telegram.</p></div>
            <?php elseif (isset($_GET['webhook_setup']) && $_GET['webhook_setup'] === '0') : ?>
                <div class="notice notice-error is-dismissible"><p>❌ Cài đặt webhook thất bại. Vui lòng kiểm tra lại Token Telegram và đảm bảo website có thể truy cập từ internet (HTTPS).</p></div>
            <?php elseif (isset($_GET['webhook_error'])) : ?>
                <div class="notice notice-error is-dismissible"><p>❌ Vui lòng nhập Telegram Bot Token trước khi cài đặt webhook.</p></div>
            <?php endif; ?>
            <h2>Cấu hình Cyber Services AI Chatbox</h2>
            <form method="post" action="options.php">
                <?php settings_fields('ai_chat_settings_group'); ?>
                <table class="form-table">
                    <tr>
                        <th>Nhà cung cấp AI</th>
                        <td>
                            <select name="ai_chat_provider" id="ai_chat_provider">
                                <option value="kira" <?php selected($provider, 'kira'); ?>>Kira AI (kiraai.vn)</option>
                                <option value="openai" <?php selected($provider, 'openai'); ?>>OpenAI</option>
                            </select>
                        </td>
                    </tr>
                    <tr id="kira_base_url_row">
                        <th>Kira Base URL</th>
                        <td><input type="text" name="ai_chat_kira_base_url" value="<?php echo esc_attr(get_option('ai_chat_kira_base_url', 'https://kiraai.vn')); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th>API Key</th>
                        <td><input type="password" name="ai_chat_api_key" value="<?php echo esc_attr(get_option('ai_chat_api_key')); ?>" class="regular-text" required /></td>
                    </tr>
                    <tr>
                        <th>Model AI</th>
                        <td>
                            <select name="ai_chat_model">
                                <option value="kira-3.5-flash" <?php selected($model, 'kira-3.5-flash'); ?>>kira-3.5-flash (Khuyên dùng, phản hồi cực nhanh)</option>
                                <option value="kira-mini-1.0" <?php selected($model, 'kira-mini-1.0'); ?>>kira-mini-1.0 (Miễn phí)</option>
                                <option value="kira-3.5-pro" <?php selected($model, 'kira-3.5-pro'); ?>>kira-3.5-pro (Nâng cao)</option>
                                <option value="gpt-4o-mini" <?php selected($model, 'gpt-4o-mini'); ?>>gpt-4o-mini (OpenAI)</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Định hướng AI (System Prompt)</th>
                        <td><textarea name="ai_chat_system_prompt" rows="7" class="large-text"><?php echo esc_textarea(get_option('ai_chat_system_prompt', $default_prompt)); ?></textarea></td>
                    </tr>
                    <tr>
                        <th>Dữ liệu bổ sung / Dịch vụ</th>
                        <td><textarea name="ai_chat_custom_knowledge" rows="5" class="large-text"><?php echo esc_textarea(get_option('ai_chat_custom_knowledge')); ?></textarea></td>
                    </tr>
                    <tr>
                        <th>Telegram Bot Token</th>
                        <td><input type="text" name="ai_chat_telegram_token" value="<?php echo esc_attr(get_option('ai_chat_telegram_token')); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th>Telegram Chat ID</th>
                        <td>
                            <input type="text" name="ai_chat_telegram_chat_id" value="<?php echo esc_attr(get_option('ai_chat_telegram_chat_id')); ?>" class="regular-text" />
                            <p class="description">ID của tài khoản/channel Telegram nhận thông báo khách hàng. Lấy bằng cách nhắn tin cho @userinfobot.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>🔗 Webhook Telegram</th>
                        <td>
                            <?php $setup_webhook_url = wp_nonce_url(admin_url('admin-post.php?action=ai_chat_setup_webhook'), 'ai_chat_setup_webhook_nonce'); ?>
                            <a href="<?php echo esc_url($setup_webhook_url); ?>" class="button button-primary" onclick="return confirm('Cài đặt webhook Telegram ngay bây giờ?');">⚙️ Cài đặt Webhook Telegram</a>
                            <p class="description">
                                Bấm nút này để đăng ký URL nhận tin nhắn (webhook) với Telegram. <strong>BẮT BUỘC</strong> phải bấm sau khi nhập đúng Token và Chat ID, rồi lưu cấu hình.
                                Sau đó, khi khách nhắn, bạn bấm <strong>Reply/Trả lời</strong> trực tiếp trên Telegram để phản hồi trong bảng chat.
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th>Độ dài câu trả lời tối đa (max_tokens)</th>
                        <td>
                            <input type="number" name="ai_chat_max_tokens" min="100" max="4000" step="50" value="<?php echo esc_attr(get_option('ai_chat_max_tokens', 500)); ?>" class="small-text" />
                            <p class="description">Giá trị mặc định: 500. Tăng lên (ví dụ 1000-1500) nếu câu trả lời AI bị cắt ngắn.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>📡 Theo dõi hành trình Telegram</th>
                        <td>
                            <label>
                                <input type="checkbox" name="ai_chat_tracking_enabled" value="1" <?php checked(get_option('ai_chat_tracking_enabled', '1'), '1'); ?> />
                                Bật tính năng gom thông báo hành trình, cảnh báo trang mục tiêu & cảnh báo onsite
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th>🎯 Trang mục tiêu (cảnh báo ưu tiên)</th>
                        <td>
                            <input type="text" name="ai_chat_target_keywords" value="<?php echo esc_attr(get_option('ai_chat_target_keywords', 'bang-gia, pricing, thanh-toan, checkout, gio-hang, cart, landing')); ?>" class="regular-text" style="width:100%;" />
                            <p class="description">Danh sách từ khóa (phân cách bằng dấu phẩy). Khi khách truy cập URL chứa từ khóa này → gửi cảnh báo ưu tiên (mỗi trang 1 lần).</p>
                        </td>
                    </tr>
                    <tr>
                        <th>⏱️ Cảnh báo dừng lâu (Onsite)</th>
                        <td>
                            <input type="number" name="ai_chat_onsite_timeout" min="30" max="600" step="10" value="<?php echo esc_attr(get_option('ai_chat_onsite_timeout', 150)); ?>" class="small-text" />
                            <p class="description">Gửi cảnh báo khi khách dừng ở một trang quá số giây này (mặc định 150s = 2.5 phút). Mỗi trang chỉ báo 1 lần.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>📊 Thống kê lượt xem toàn site</th>
                        <td>
                            <label>
                                <input type="checkbox" name="ai_chat_site_views_enabled" value="1" <?php checked(get_option('ai_chat_site_views_enabled', '1'), '1'); ?> />
                                Bật ghi nhận lượt xem của MỌI khách truy cập website (kể cả khách không chat) để hiển thị bảng thống kê trong trang Khách Hàng (Leads).
                            </label>
                        </td>
                    </tr>
                </table>
                <p>
                    <a href="<?php echo wp_nonce_url(admin_url('admin-post.php?action=ai_chat_create_tables'), 'ai_chat_create_tables_nonce'); ?>" class="button button-secondary" onclick="return confirm('Tạo/Cập nhật bảng dữ liệu? Dữ liệu cũ sẽ được giữ nguyên.');">🛠️ Tạo lại bảng dữ liệu</a>
                    <span style="margin-left:10px;color:#666;font-size:12px;">(Chạy khi không thấy bảng mới hoặc cập nhật schema)</span>
                </p>
                <?php submit_button(); ?>
            </form>
        </div>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const providerSelect = document.getElementById('ai_chat_provider');
                const baseUrlRow = document.getElementById('kira_base_url_row');
                function toggleRows() {
                    baseUrlRow.style.display = (providerSelect.value === 'kira') ? '' : 'none';
                }
                providerSelect.addEventListener('change', toggleRows);
                toggleRows();
            });
        </script>
        <?php
    }

    /* GIAO DIỆN CRM ADMIN - THÊM PHÂN TRANG VÀ TÌM KIẾM */
    public function admin_leads_page() {
        global $wpdb;
        $table_leads = $wpdb->prefix . 'ai_chat_leads';
        $table_chats = $wpdb->prefix . 'ai_chat_history';

        if (isset($_GET['deleted'])) {
            echo '<div class="notice notice-success is-dismissible"><p>✅ Đã xóa khách hàng và lịch sử chat thành công!</p></div>';
        }
        if (isset($_GET['stats_cleared'])) {
            echo '<div class="notice notice-success is-dismissible"><p>🗑️ Đã xóa toàn bộ dữ liệu thống kê lượt xem!</p></div>';
        }

        // CHẾ ĐỘ XEM CHI TIẾT 1 KHÁCH HÀNG
        if (isset($_GET['view_session'])) {
            $session_id = sanitize_text_field($_GET['view_session']);
            $lead = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_leads WHERE session_id = %s", $session_id));
            $messages = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_chats WHERE session_id = %s ORDER BY id ASC", $session_id));
            ?>
            <div class="wrap">
                <a href="<?php echo esc_url(admin_url('admin.php?page=ai-chatbox-leads')); ?>" class="button" style="margin-bottom: 15px;">⬅ Quay lại danh sách khách hàng</a>
                
                <div style="display:flex; gap:20px; flex-wrap:wrap;">
                    <div style="flex:1; min-width:300px; max-width:360px; background:#ffffff; padding:20px; border-radius:12px; box-shadow:0 2px 10px rgba(0,0,0,0.05); border:1px solid #e2e8f0; height:fit-content;">
                        <h3 style="margin-top:0; border-bottom:1px solid #f1f5f9; padding-bottom:12px; color:#0f172a;">👤 Thông Tin Khách Hàng</h3>
                        <p style="margin:10px 0;"><strong>Họ và tên:</strong> <?php echo esc_html($lead->user_name ?? 'Khách vãng lai'); ?></p>
                        <p style="margin:10px 0;"><strong>Số điện thoại:</strong> <a href="tel:<?php echo esc_attr($lead->user_phone ?? ''); ?>" style="color:#f95700; font-weight:bold;"><?php echo esc_html($lead->user_phone ?? '-'); ?></a></p>
                        <p style="margin:10px 0;"><strong>Email:</strong> <?php echo esc_html($lead->user_email ?: 'Chưa cung cấp'); ?></p>
                        <p style="margin:10px 0;"><strong>Thời gian:</strong> <?php echo esc_html($lead->created_at ?? '-'); ?></p>
                        <p style="margin:10px 0;"><strong>Trang đăng ký:</strong> <br/><a href="<?php echo esc_url($lead->page_url ?? ''); ?>" target="_blank" rel="noopener noreferrer" style="color:#2563eb; font-size:12px; word-break:break-all;"><?php echo esc_html($lead->page_url ?? '-'); ?></a></p>
                    </div>

                    <div style="flex:2; min-width:360px; background:#181b22; padding:20px; border-radius:12px; box-shadow:0 2px 10px rgba(0,0,0,0.05); border:1px solid #282f3d; max-height:75vh; overflow-y:auto;">
                        <h3 style="margin-top:0; border-bottom:1px solid #282f3d; padding-bottom:12px; color:#ffffff;">💬 Chi Tiết Hội Thoại</h3>
                        <?php if ($messages): foreach ($messages as $msg): ?>
                            <div style="display:flex; justify-content:<?php echo $msg->sender === 'user' ? 'flex-end' : 'flex-start'; ?>; margin-bottom:14px;">
                                <div style="max-width:80%; padding:12px 16px; border-radius:14px; font-size:13.5px; line-height:1.5; background:<?php echo $msg->sender === 'user' ? '#f95700' : '#222733'; ?>; color:#ffffff; border:<?php echo $msg->sender === 'user' ? 'none' : '1px solid #2e3547'; ?>;">
                                    <div style="font-size:10.5px; margin-bottom:4px; opacity:0.8; font-weight:600;">
                                        <?php echo $msg->sender === 'user' ? 'Khách hàng (' . esc_html($lead->user_name ?? 'Khách') . ')' : 'Mai Hoa / CSKH'; ?> • <?php echo esc_html($msg->created_at); ?>
                                    </div>
                                    <div><?php echo nl2br(esc_html($msg->message)); ?></div>
                                </div>
                            </div>
                        <?php endforeach; else: ?>
                            <p style="color:#8b949e; text-align:center; padding:30px 0;">Chưa có thêm tin nhắn nào.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php
            return;
        }

        // LỌC VÀ TÌM KIẾM
        $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
        $filter_status = isset($_GET['filter_status']) ? sanitize_text_field($_GET['filter_status']) : '';
        
        $where = "1=1";
        $args = [];

        if (!empty($search)) {
            $where .= " AND (user_name LIKE %s OR user_phone LIKE %s)";
            $args[] = '%' . $wpdb->esc_like($search) . '%';
            $args[] = '%' . $wpdb->esc_like($search) . '%';
        }
        if (!empty($filter_status)) {
            $where .= " AND status = %s";
            $args[] = $filter_status;
        }

        // PHÂN TRANG
        $per_page = 20;
        $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $offset = ($paged - 1) * $per_page;

        $count_args = $args; // Lưu biến tạm cho câu truy vấn Count
        
        $query = "SELECT * FROM $table_leads WHERE $where ORDER BY id DESC LIMIT %d OFFSET %d";
        $args[] = $per_page;
        $args[] = $offset;

        $leads = empty($args) ? $wpdb->get_results($query) : $wpdb->get_results($wpdb->prepare($query, $args));

        $total_query = "SELECT COUNT(id) FROM $table_leads WHERE $where";
        $total_items = empty($count_args) ? $wpdb->get_var($total_query) : $wpdb->get_var($wpdb->prepare($total_query, $count_args));
        $total_pages = ceil($total_items / $per_page);

        $export_url = wp_nonce_url(admin_url('admin-post.php?action=export_ai_leads'), 'export_ai_leads_action', 'export_nonce');
        $admin_nonce = wp_create_nonce('ai_admin_leads_nonce');

        // ===== THỐNG KÊ LƯỢT XEM THEO NGÀY & TRANG =====
        $table_site_views = $wpdb->prefix . 'ai_chat_site_views';
        $table_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_site_views));

        // Bộ lọc ngày
        $stats_from = isset($_GET['stats_from']) ? sanitize_text_field($_GET['stats_from']) : date('Y-m-d', strtotime('-6 days'));
        $stats_to   = isset($_GET['stats_to']) ? sanitize_text_field($_GET['stats_to']) : date('Y-m-d');
        $stats_from = date('Y-m-d', strtotime($stats_from));
        $stats_to   = date('Y-m-d', strtotime($stats_to));

        $stats_by_day = [];
        $stats_by_page = [];
        $stats_total_views = 0;
        $stats_unique_sessions = 0;
        if ($table_exists) {
            $day_rows = $wpdb->get_results($wpdb->prepare(
                "SELECT DATE(viewed_at) AS d, COUNT(*) AS total FROM $table_site_views
                 WHERE DATE(viewed_at) BETWEEN %s AND %s
                 GROUP BY DATE(viewed_at) ORDER BY d ASC",
                $stats_from, $stats_to
            ));
            foreach ((array)$day_rows as $r) {
                $stats_by_day[$r->d] = (int)$r->total;
            }

            $page_rows = $wpdb->get_results($wpdb->prepare(
                "SELECT path, title, COUNT(*) AS total FROM $table_site_views
                 WHERE DATE(viewed_at) BETWEEN %s AND %s
                 GROUP BY path ORDER BY total DESC LIMIT 20",
                $stats_from, $stats_to
            ));
            foreach ((array)$page_rows as $r) {
                $stats_by_page[] = ['path' => $r->path, 'title' => $r->title, 'total' => (int)$r->total];
            }

            $stats_total_views = (int)$wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $table_site_views WHERE DATE(viewed_at) BETWEEN %s AND %s",
                $stats_from, $stats_to
            ));
            $stats_unique_sessions = (int)$wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(DISTINCT session_id) FROM $table_site_views WHERE DATE(viewed_at) BETWEEN %s AND %s",
                $stats_from, $stats_to
            ));
        }

        // Dữ liệu cho biểu đồ Chart.js (theo ngày)
        $chart_labels = [];
        $chart_values = [];
        if (!empty($stats_by_day)) {
            $d = new DateTime($stats_from);
            $end = new DateTime($stats_to);
            for ($i = 0; $i <= $end->diff($d)->days; $i++) {
                $key = $d->format('Y-m-d');
                $chart_labels[] = date('d/m', strtotime($key));
                $chart_values[] = isset($stats_by_day[$key]) ? $stats_by_day[$key] : 0;
                $d->modify('+1 day');
            }
        }

        // URL xuất thống kê CSV
        $stats_export_url = wp_nonce_url(
            admin_url('admin-post.php?action=export_ai_leads&stats_export=1&stats_from=' . $stats_from . '&stats_to=' . $stats_to),
            'export_ai_leads_action', 'export_nonce'
        );

        // URL xóa dữ liệu thống kê (kèm nonce)
        $clear_stats_url = wp_nonce_url(
            admin_url('admin-post.php?action=clear_ai_stats'),
            'clear_ai_stats_nonce'
        );
        ?>
        <div class="wrap">
            <!-- ===== THỐNG KÊ LƯỢT XEM THEO NGÀY & TRANG ===== -->
            <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:12px; padding:18px 20px; margin-bottom:20px; box-shadow:0 2px 10px rgba(0,0,0,0.04);">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:14px;">
                    <h3 style="margin:0; color:#0f172a;">📊 Thống kê lượt xem theo ngày & trang</h3>
                    <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
                        <form method="get" style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                            <input type="hidden" name="page" value="ai-chatbox-leads">
                            <label style="font-size:12px; color:#475569;">Từ:</label>
                            <input type="date" name="stats_from" value="<?php echo esc_attr($stats_from); ?>" style="height:30px;">
                            <label style="font-size:12px; color:#475569;">Đến:</label>
                            <input type="date" name="stats_to" value="<?php echo esc_attr($stats_to); ?>" style="height:30px;">
                            <button type="submit" class="button" style="height:30px;">Lọc</button>
                            <?php if (isset($_GET['stats_from']) || isset($_GET['stats_to'])): ?>
                                <a href="?page=ai-chatbox-leads" class="button" style="height:30px;">Xóa lọc</a>
                            <?php endif; ?>
                        </form>
                        <a href="<?php echo esc_url($stats_export_url); ?>" class="button" style="background:#2563eb; border-color:#2563eb; color:#fff;">📤 Xuất thống kê CSV</a>
                        <a href="<?php echo esc_url($clear_stats_url); ?>" class="button" style="background:#ef4444; border-color:#dc2626; color:#fff;" onclick="return confirm('Bạn có chắc chắn muốn XÓA TOÀN BỘ dữ liệu thống kê lượt xem? Hành động này không thể hoàn tác!');">🗑️ Xóa dữ liệu thống kê</a>
                    </div>
                </div>

                <div style="display:flex; gap:30px; flex-wrap:wrap; margin-bottom:16px;">
                    <div style="flex:1; min-width:200px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:14px 16px; text-align:center;">
                        <div style="font-size:26px; font-weight:800; color:#0f172a;"><?php echo number_format($stats_total_views); ?></div>
                        <div style="font-size:12px; color:#64748b; margin-top:2px;">Tổng lượt xem</div>
                    </div>
                    <div style="flex:1; min-width:200px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:14px 16px; text-align:center;">
                        <div style="font-size:26px; font-weight:800; color:#0f172a;"><?php echo number_format($stats_unique_sessions); ?></div>
                        <div style="font-size:12px; color:#64748b; margin-top:2px;">Khách truy cập (session)</div>
                    </div>
                    <div style="flex:1; min-width:200px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:14px 16px; text-align:center;">
                        <div style="font-size:26px; font-weight:800; color:#0f172a;"><?php echo number_format(count($stats_by_page)); ?></div>
                        <div style="font-size:12px; color:#64748b; margin-top:2px;">Trang được truy cập</div>
                    </div>
                </div>

                <?php if ($table_exists && $stats_total_views > 0): ?>
                    <!-- Biểu đồ lượt xem theo ngày (Chart.js) -->
                    <div style="margin-bottom:20px;">
                        <h4 style="margin:0 0 8px 0; color:#0f172a; font-size:14px;">📈 Biểu đồ lượt xem theo ngày</h4>
                        <div style="position:relative; height:260px;">
                            <canvas id="ai-stats-chart"></canvas>
                        </div>
                    </div>

                    <div style="display:flex; gap:24px; flex-wrap:wrap;">
                        <!-- Thống kê theo ngày -->
                        <div style="flex:1; min-width:300px;">
                            <h4 style="margin:0 0 8px 0; color:#0f172a; font-size:14px;">Lượt xem theo ngày</h4>
                            <table class="widefat striped" style="border:1px solid #e2e8f0;">
                                <thead>
                                    <tr>
                                        <th style="width:60%;">Ngày</th>
                                        <th>Lượt xem</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $d = new DateTime($stats_from);
                                    $end = new DateTime($stats_to);
                                    for ($i = 0; $i <= $end->diff($d)->days; $i++) {
                                        $key = $d->format('Y-m-d');
                                        $cnt = isset($stats_by_day[$key]) ? $stats_by_day[$key] : 0;
                                        echo '<tr>';
                                        echo '<td>' . esc_html(date('d/m/Y', strtotime($key))) . '</td>';
                                        echo '<td><strong>' . esc_html(number_format($cnt)) . '</strong></td>';
                                        echo '</tr>';
                                        $d->modify('+1 day');
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Top trang -->
                        <div style="flex:1; min-width:320px;">
                            <h4 style="margin:0 0 8px 0; color:#0f172a; font-size:14px;">Top trang được xem nhiều nhất</h4>
                            <table class="widefat striped" style="border:1px solid #e2e8f0;">
                                <thead>
                                    <tr>
                                        <th style="width:8%;">#</th>
                                        <th>Trang (đường dẫn)</th>
                                        <th style="width:15%;">Lượt xem</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $rank = 1; foreach ($stats_by_page as $p): ?>
                                        <tr>
                                            <td><?php echo $rank++; ?></td>
                                            <td>
                                                <a href="<?php echo esc_url($p['path']); ?>" target="_blank" rel="noopener noreferrer" style="color:#2563eb; font-size:12px; word-break:break-all;">
                                                    <?php echo esc_html($p['path']); ?>
                                                </a>
                                                <?php if (!empty($p['title'])): ?>
                                                    <br/><span style="color:#94a3b8; font-size:11px;"><?php echo esc_html($p['title']); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td><strong><?php echo number_format($p['total']); ?></strong></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php elseif ($table_exists): ?>
                    <p style="color:#64748b; font-size:13px; margin:10px 0 0 0;">Chưa có dữ liệu lượt xem trong khoảng thời gian này. Tracking toàn site đang hoạt động và sẽ ghi nhận lượt xem từ mọi khách truy cập website.</p>
                <?php else: ?>
                    <p style="color:#64748b; font-size:13px; margin:10px 0 0 0;">Bảng dữ liệu thống kê chưa được tạo. Vui lòng truy cập trang <a href="<?php echo esc_url(admin_url('admin.php?page=ai-chatbox')); ?>">Cấu hình</a> để tạo bảng dữ liệu, hoặc kích hoạt lại plugin.</p>
                <?php endif; ?>
            </div>
            <!-- KẾT THÚC THỐNG KÊ -->

            <?php if ($table_exists && $stats_total_views > 0): ?>
            <!-- Chart.js cho biểu đồ lượt xem -->
            <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
            <script>
            jQuery(document).ready(function($) {
                if (typeof Chart === 'undefined') return;
                var ctx = document.getElementById('ai-stats-chart');
                if (!ctx) return;
                var labels = <?php echo wp_json_encode($chart_labels); ?>;
                var values = <?php echo wp_json_encode($chart_values); ?>;
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Lượt xem',
                            data: values,
                            backgroundColor: 'rgba(249, 87, 0, 0.75)',
                            borderColor: '#f95700',
                            borderWidth: 2,
                            borderRadius: 6,
                            maxBarThickness: 48
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: false },
                            tooltip: {
                                callbacks: {
                                    label: function(ctx) { return 'Lượt xem: ' + ctx.parsed.y; }
                                }
                            }
                        },
                        scales: {
                            y: { beginAtZero: true, ticks: { precision: 0 }, grid: { color: '#f1f5f9' } },
                            x: { grid: { display: false } }
                        }
                    }
                });
            });
            </script>
            <?php endif; ?>

            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 10px;">
                <h2>Danh Sách Khách Hàng Tiềm Năng (Leads)</h2>
                <div>
                    <button type="button" id="bulk-delete-btn" class="button" style="background:#ef4444; color:#fff; border-color:#dc2626; margin-right:10px; display:none;">🗑️ Xóa các mục đã chọn</button>
                    <a href="<?php echo esc_url($export_url); ?>" class="button button-primary" style="background:#10b981; border-color:#10b981;">📥 Xuất file Excel (CSV)</a>
                </div>
            </div>

            <!-- Khung tìm kiếm và bộ lọc -->
            <form method="get" style="margin-bottom: 15px; display:flex; gap: 10px; align-items:center;">
                <input type="hidden" name="page" value="ai-chatbox-leads">
                <select name="filter_status">
                    <option value="">-- Tất cả trạng thái --</option>
                    <option value="new" <?php selected($filter_status, 'new'); ?>>🟡 Mới tiếp nhận</option>
                    <option value="contacting" <?php selected($filter_status, 'contacting'); ?>>🔵 Đang liên hệ</option>
                    <option value="closed" <?php selected($filter_status, 'closed'); ?>>🟢 Đã chốt hợp đồng</option>
                    <option value="cancelled" <?php selected($filter_status, 'cancelled'); ?>>🔴 Hủy/Không nghe máy</option>
                </select>
                <input type="text" name="s" value="<?php echo esc_attr($search); ?>" placeholder="Tìm tên hoặc SĐT..." style="width: 250px;">
                <button type="submit" class="button">Lọc & Tìm kiếm</button>
                <?php if(!empty($search) || !empty($filter_status)): ?>
                    <a href="?page=ai-chatbox-leads" class="button">Xóa lọc</a>
                <?php endif; ?>
            </form>
            
            <table class="widefat fixed striped">
                <thead>
                    <tr>
                        <th width="4%"><input type="checkbox" id="select-all-leads"></th>
                        <th width="12%">Thời gian</th>
                        <th width="14%">Họ và tên</th>
                        <th width="12%">Số điện thoại</th>
                        <th width="14%">Email</th>
                        <th width="18%">Trang đăng ký</th>
                        <th width="16%">Trạng thái (CRM)</th>
                        <th width="24%">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($leads): foreach ($leads as $lead): 
                        $msg_count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_chats WHERE session_id = %s", $lead->session_id));
                        $delete_url = wp_nonce_url(admin_url('admin.php?page=ai-chatbox-leads&action=delete_lead&lead_id=' . $lead->id), 'delete_lead_' . $lead->id);
                        $status = isset($lead->status) ? $lead->status : 'new';
                    ?>
                        <tr>
                            <td><input type="checkbox" class="lead-checkbox" value="<?php echo esc_attr($lead->id); ?>"></td>
                            <td><?php echo esc_html($lead->created_at); ?></td>
                            <td><strong style="color:#0f172a; font-size:14px;"><?php echo esc_html($lead->user_name); ?></strong></td>
                            <td>
                                <a href="tel:<?php echo esc_attr($lead->user_phone); ?>" style="font-weight:700; color:#f95700;">
                                    <?php echo esc_html($lead->user_phone); ?>
                                </a>
                            </td>
                            <td>
                                <a href="mailto:<?php echo esc_attr($lead->user_email); ?>" style="color:#2563eb; font-size:13px; word-break:break-all;"><?php echo esc_html($lead->user_email ?: 'Chưa cung cấp'); ?></a>
                            </td>
                            <td><a href="<?php echo esc_url($lead->page_url); ?>" target="_blank" rel="noopener noreferrer" style="color:#64748b; font-size:12px;"><?php echo esc_html($lead->page_url); ?></a></td>
                            <td>
                                <select class="ai-crm-status" data-id="<?php echo esc_attr($lead->id); ?>" style="width:100%; font-size:13px; font-weight:600; border-radius:6px; <?php echo $status=='new'?'color:#d97706;':($status=='contacting'?'color:#2563eb;':($status=='closed'?'color:#16a34a;':'color:#dc2626;')); ?>">
                                    <option value="new" <?php selected($status, 'new'); ?>>🟡 Mới tiếp nhận</option>
                                    <option value="contacting" <?php selected($status, 'contacting'); ?>>🔵 Đang liên hệ</option>
                                    <option value="closed" <?php selected($status, 'closed'); ?>>🟢 Đã chốt hợp đồng</option>
                                    <option value="cancelled" <?php selected($status, 'cancelled'); ?>>🔴 Hủy / KNM</option>
                                </select>
                            </td>
                            <td>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=ai-chatbox-leads&view_session=' . urlencode($lead->session_id))); ?>" class="button" style="color:#f95700; border-color:#f95700; margin-right:4px;">
                                    💬 Xem chat (<?php echo (int)$msg_count; ?>)
                                </a>
                                <a href="<?php echo esc_url($delete_url); ?>" class="button button-link-delete" onclick="return confirm('Bạn có chắc chắn muốn xóa?');" style="color:#ef4444; vertical-align:middle;">
                                    🗑️ Xóa
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; else: ?>
                        <tr><td colspan="8" style="text-align:center; padding:20px;">Không tìm thấy khách hàng nào.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <!-- Hiển thị phân trang -->
            <?php
            $page_links = paginate_links([
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('&laquo; Trước'),
                'next_text' => __('Sau &raquo;'),
                'total' => $total_pages,
                'current' => $paged
            ]);
            if ($page_links) {
                echo '<div class="tablenav"><div class="tablenav-pages" style="margin: 1em 0;">' . $page_links . '</div></div>';
            }
            ?>

            <script>
            jQuery(document).ready(function($) {
                const adminNonce = '<?php echo esc_js($admin_nonce); ?>';

                $('.ai-crm-status').on('change', function() {
                    let select = $(this);
                    let val = select.val();
                    select.css('color', val==='new'?'#d97706':(val==='contacting'?'#2563eb':(val==='closed'?'#16a34a':'#dc2626')));
                    $.post(ajaxurl, {
                        action: 'update_lead_status',
                        security: adminNonce,
                        lead_id: select.data('id'),
                        status: val
                    });
                });

                $('#select-all-leads').on('change', function() {
                    $('.lead-checkbox').prop('checked', this.checked);
                    toggleBulkDeleteBtn();
                });

                $('.lead-checkbox').on('change', function() {
                    toggleBulkDeleteBtn();
                });

                function toggleBulkDeleteBtn() {
                    if ($('.lead-checkbox:checked').length > 0) {
                        $('#bulk-delete-btn').show();
                    } else {
                        $('#bulk-delete-btn').hide();
                    }
                }

                $('#bulk-delete-btn').on('click', function() {
                    let selectedIds = [];
                    $('.lead-checkbox:checked').each(function() {
                        selectedIds.push($(this).val());
                    });

                    if (selectedIds.length === 0) return;

                    if (confirm('Bạn có chắc chắn muốn xóa ' + selectedIds.length + ' khách hàng đã chọn cùng toàn bộ lịch sử chat?')) {
                        $.post(ajaxurl, {
                            action: 'bulk_delete_ai_leads',
                            security: adminNonce,
                            lead_ids: selectedIds
                        }, function(res) {
                            if (res.success) {
                                location.reload();
                            } else {
                                alert('Có lỗi xảy ra, vui lòng thử lại.');
                            }
                        });
                    }
                });
            });
            </script>
        </div>
        <?php
    }

    /* 4. FRONTEND UI MODERN LIGHT THEME */
    public function render_chatbox_ui() {
        if (function_exists('is_cart') && (is_cart() || is_checkout())) return;
        ?>
        <div id="ai-chat-root">
            <button id="ai-chat-btn" type="button" aria-label="Open Chat">
                <svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/></svg>
            </button>

            <div id="ai-chat-box">
                <div class="ai-chat-header">
                    <div class="ai-chat-header-left">
                        <div class="ai-header-avatar">CS</div>
                        <div class="ai-chat-header-info">
                            <div class="ai-chat-title">Hỗ trợ trực tuyến</div>
                            <div class="ai-chat-status">
                                <span class="ai-dot-online"></span> Trực tuyến
                            </div>
                        </div>
                    </div>
                    <button id="ai-chat-close" type="button">✕</button>
                </div>

                <div class="ai-chat-messages" id="ai-chat-body"></div>

                <div class="ai-chat-footer-wrap">
                    <div class="ai-chat-input-area">
                        <div class="ai-input-wrap">
                            <input type="text" id="ai-chat-input" placeholder="Nhập tin nhắn..." autocomplete="off" />
                        </div>
                        <button type="button" id="ai-chat-send-btn" class="ai-chat-submit" aria-label="Gửi">
                            <svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
                        </button>
                    </div>
                    <div class="ai-chat-copyright">Powered by Cyber Services Việt Nam</div>
                </div>
            </div>
        </div>
        <?php
    }

    /* 5. LƯU LEAD */
    public function handle_save_lead() {
        check_ajax_referer('ai_chat_nonce_action', 'security');

        global $wpdb;
        $session_id  = isset($_POST['session_id']) ? sanitize_text_field($_POST['session_id']) : '';
        $name        = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
        $phone       = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
        $email       = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
        $current_url = isset($_POST['current_url']) ? esc_url_raw($_POST['current_url']) : '';

        if (empty($name) || empty($phone)) {
            wp_send_json_error(['error' => 'Vui lòng nhập đầy đủ tên và số điện thoại.']);
        }

        $table_leads = $wpdb->prefix . 'ai_chat_leads';
        // Chống duplicate: nếu session_id đã tồn tại thì cập nhật thay vì insert mới
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table_leads WHERE session_id = %s LIMIT 1",
            $session_id
        ));

        if ($existing) {
            $wpdb->update(
                $table_leads,
                [
                    'user_name'  => $name,
                    'user_phone' => $phone,
                    'user_email' => $email,
                    'page_url'   => $current_url
                ],
                ['session_id' => $session_id],
                ['%s', '%s', '%s', '%s'],
                ['%s']
            );
        } else {
            $wpdb->insert($table_leads, [
                'session_id' => $session_id,
                'user_name'  => $name,
                'user_phone' => $phone,
                'user_email' => $email,
                'page_url'   => $current_url
            ], ['%s', '%s', '%s', '%s', '%s']);
        }

        set_transient('ai_lead_' . $session_id, [
            'name'  => $name,
            'phone' => $phone,
            'email' => $email
        ], DAY_IN_SECONDS * 7);

        // Chuyển sang định dạng HTML cho Telegram
        $telegram_msg = "🎯 <b>CÓ KHÁCH HÀNG TIỀM NĂNG MỚI!</b>\n"
                      . "👤 <b>Họ tên:</b> " . esc_html($name) . "\n"
                      . "📞 <b>Số điện thoại:</b> <code>" . esc_html($phone) . "</code>\n"
                      . "📧 <b>Email:</b> " . ($email ? esc_html($email) : 'Chưa cung cấp') . "\n"
                      . "🔗 <b>Trang đang xem:</b> " . esc_url($current_url) . "\n"
                      . "🔑 ID: <code>{$session_id}</code>";
        
        $this->send_telegram_notification($telegram_msg);
        wp_send_json_success();
    }

    /* 6. GỌI API */
    private function call_chat_completion($messages, $api_key, $model, $endpoint) {
        $max_tokens = get_option('ai_chat_max_tokens', 500);
        $body_json = wp_json_encode([
            'model'       => $model,
            'messages'    => $messages,
            'stream'      => false,
            'temperature' => 0.2,
            'max_tokens'  => (int) $max_tokens
        ]);

        $response = wp_remote_post($endpoint, [
            'headers'     => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . trim($api_key)
            ],
            'body'        => $body_json,
            'timeout'     => 45,
            'sslverify'   => true
        ]);

        if (is_wp_error($response)) {
            return ['error' => 'Lỗi kết nối API WordPress: ' . $response->get_error_message()];
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if ($response_code !== 200) {
            $raw_msg = $data['error']['message'] ?? $data['message'] ?? '';
            if ($response_code == 429 || strpos($raw_msg, 'Resource exhausted') !== false) {
                return ['error' => 'Hệ thống đang quá tải lượt hỏi cùng lúc, anh/chị vui lòng thử lại sau giây lát hoặc liên hệ Hotline để được hỗ trợ trực tiếp ạ!'];
            }
            return ['error' => $raw_msg ?: ('API Error: Mã HTTP ' . $response_code)];
        }

        if (isset($data['choices'][0]['message']['content'])) {
            return ['reply' => trim($data['choices'][0]['message']['content'])];
        }

        return ['error' => 'Phản hồi từ AI không đúng định dạng.'];
    }

    /* 7. XỬ LÝ MESSAGE */
    public function handle_chat_message() {
        check_ajax_referer('ai_chat_nonce_action', 'security');

        global $wpdb;
        $session_id  = isset($_POST['session_id']) ? sanitize_text_field($_POST['session_id']) : '';
        $message     = isset($_POST['message']) ? sanitize_text_field($_POST['message']) : '';

        if (empty($session_id) || empty($message)) {
            wp_send_json_error(['error' => 'Dữ liệu tin nhắn rỗng.']);
        }

        // Rate limit
        $client_ip = sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
        $rate_limit_key = 'ai_rate_limit_' . md5($session_id . '_' . $client_ip);
        $msg_count = (int) get_transient($rate_limit_key);
        if ($msg_count >= 8) {
            wp_send_json_error(['error' => 'Bạn đang nhắn tin quá nhanh, vui lòng chờ khoảng 1 phút rồi thử lại nhé!']);
        }
        set_transient($rate_limit_key, $msg_count + 1, MINUTE_IN_SECONDS);

        $user_name = '';
        $lead_info = get_transient('ai_lead_' . $session_id);
        if (!empty($lead_info['name'])) {
            $user_name = $lead_info['name'];
        } else {
            $db_name = $wpdb->get_var($wpdb->prepare("SELECT user_name FROM {$wpdb->prefix}ai_chat_leads WHERE session_id = %s", $session_id));
            if ($db_name) {
                $user_name = $db_name;
            }
        }

        $table_chats = $wpdb->prefix . 'ai_chat_history';
        $raw_history = $wpdb->get_results($wpdb->prepare(
            "SELECT sender, message FROM $table_chats WHERE session_id = %s ORDER BY id DESC LIMIT 4", 
            $session_id
        ));

        $wpdb->insert($table_chats, [
            'session_id' => $session_id,
            'sender'     => 'user',
            'message'    => $message
        ], ['%s', '%s', '%s']);

        // Gửi thông báo Telegram (Đã fix lỗi parse HTML an toàn)
        $telegram_msg = "💬 <b>Khách hàng " . ($user_name ? esc_html($user_name) : 'Khách') . " nhắn:</b>\n"
                      . esc_html($message) . "\n\n"
                      . "<i>(Để trả lời, hãy bấm Reply/Trả lời trực tiếp vào tin nhắn này)</i>\n"
                      . "🔑 ID: <code>{$session_id}</code>";
        $this->send_telegram_notification($telegram_msg);

        // Nạp Cache bài viết
        $cached_posts = get_transient('ai_chat_posts_cache');
        if ($cached_posts === false) {
            $recent_posts = get_posts([
                'post_type'   => ['post', 'product'],
                'numberposts' => 4,
                'post_status' => 'publish'
            ]);
            $cached_posts = '';
            if (!empty($recent_posts)) {
                foreach ($recent_posts as $post) {
                    $excerpt = wp_strip_all_tags($post->post_excerpt ?: $post->post_content);
                    $cached_posts .= "- {$post->post_title}: " . mb_substr($excerpt, 0, 120) . "\n";
                }
            }
            set_transient('ai_chat_posts_cache', $cached_posts, HOUR_IN_SECONDS);
        }

        $context_data = get_option('ai_chat_custom_knowledge', '') . "\n" . $cached_posts;
        $system_prompt = get_option('ai_chat_system_prompt') . "\n(Tên khách hàng: " . ($user_name ?: 'Quý khách') . ")\n" . $context_data;

        $messages = [
            ['role' => 'system', 'content' => $system_prompt]
        ];

        // Giới hạn độ dài ngữ cảnh để tiết kiệm API Token (Cắt chuỗi 1000 ký tự)
        if (!empty($raw_history)) {
            $history = array_reverse($raw_history);
            foreach ($history as $h) {
                $messages[] = [
                    'role'    => ($h->sender === 'user') ? 'user' : 'assistant',
                    'content' => mb_substr($h->message, 0, 1000) 
                ];
            }
        }

        $messages[] = [
            'role'    => 'user',
            'content' => mb_substr($message, 0, 1000)
        ];

        $provider = get_option('ai_chat_provider', 'kira');
        $api_key  = get_option('ai_chat_api_key');
        $model    = get_option('ai_chat_model', 'kira-3.5-flash');

        if (empty($api_key)) {
            wp_send_json_error(['error' => 'Chưa cấu hình API Key trong trang quản trị!']);
        }

        if ($provider === 'kira') {
            $base_url = rtrim(get_option('ai_chat_kira_base_url', 'https://kiraai.vn'), '/');
            $endpoint = $base_url . '/api/v1/chat/completions';
        } else {
            $endpoint = 'https://api.openai.com/v1/chat/completions';
        }

        $call_result = $this->call_chat_completion($messages, $api_key, $model, $endpoint);

        if (isset($call_result['error'])) {
            wp_send_json_error(['error' => $call_result['error']]);
        }

        $bot_reply = $call_result['reply'];

        $wpdb->insert($table_chats, [
            'session_id' => $session_id,
            'sender'     => 'bot',
            'message'    => $bot_reply
        ], ['%s', '%s', '%s']);

        wp_send_json_success(['reply' => $bot_reply]);
    }

    public function load_chat_history() {
        check_ajax_referer('ai_chat_nonce_action', 'security');
        
        global $wpdb;
        $session_id = isset($_GET['session_id']) ? sanitize_text_field($_GET['session_id']) : '';
        $table_chats = $wpdb->prefix . 'ai_chat_history';

        if (empty($session_id)) {
            wp_send_json([]);
        }

        $chats = $wpdb->get_results($wpdb->prepare(
            "SELECT sender, message FROM $table_chats WHERE session_id = %s ORDER BY id ASC",
            $session_id
        ));

        wp_send_json($chats ?: []);
    }

    /* 8. TELEGRAM TRACKING - GOM THÔNG BÁO HÀNH TRÌNH, CẢNH BÁO TRANG MỤC TIÊU & ONSITE */

    // AJAX: Ghi nhận lượt xem trang của khách
    /* AJAX THEO DÕI LƯỢT XEM TOÀN SITE (mọi khách truy cập, kể cả không chat) */
    public function handle_track_site_view() {
        check_ajax_referer('ai_chat_nonce_action', 'security');

        // Rate-limit: mỗi session chỉ ghi tối đa 1 lượt / 6 giây để tránh spam
        $session_id = isset($_POST['session_id']) ? sanitize_text_field($_POST['session_id']) : '';
        $rl_key = 'ai_site_view_rl_' . md5($session_id);
        if (get_transient($rl_key)) {
            wp_send_json_success(['skipped' => true]); // Bỏ qua, chưa đủ thời gian
        }

        $url   = isset($_POST['url']) ? esc_url_raw($_POST['url']) : '';
        $path  = isset($_POST['path']) ? sanitize_text_field($_POST['path']) : '';
        $title = isset($_POST['title']) ? sanitize_text_field($_POST['title']) : '';

        if (empty($session_id) || empty($url)) {
            wp_send_json_error(['error' => 'Missing session_id or url']);
        }

        // Chuẩn hóa path
        if (empty($path)) {
            $parsed = wp_parse_url($url);
            $path = isset($parsed['path']) ? $parsed['path'] : '/';
            if (isset($parsed['query'])) {
                $path .= '?' . $parsed['query'];
            }
        }

        global $wpdb;
        $table_site_views = $wpdb->prefix . 'ai_chat_site_views';

        $wpdb->insert($table_site_views, [
            'session_id' => $session_id,
            'url'        => $url,
            'path'       => $path,
            'title'      => $title,
            'viewed_at'  => current_time('mysql')
        ], ['%s', '%s', '%s', '%s', '%s']);

        // Đánh dấu đã ghi để giãn cách (6 giây)
        set_transient($rl_key, 1, 6);

        wp_send_json_success(['logged' => true]);
    }

    public function handle_track_page() {
        check_ajax_referer('ai_chat_nonce_action', 'security');
        if (get_option('ai_chat_tracking_enabled', '1') !== '1') {
            wp_send_json_success(['skipped' => true]); // Tính năng đang tắt
        }

        global $wpdb;
        $table_views = $wpdb->prefix . 'ai_chat_page_views';

        $session_id = isset($_POST['session_id']) ? sanitize_text_field($_POST['session_id']) : '';
        $url        = isset($_POST['url']) ? esc_url_raw($_POST['url']) : '';
        $title      = isset($_POST['title']) ? sanitize_text_field($_POST['title']) : '';

        if (empty($session_id) || empty($url)) {
            wp_send_json_error(['error' => 'Missing session_id or url']);
        }

        $path = wp_parse_url($url, PHP_URL_PATH) ?: '/';
        $query = wp_parse_url($url, PHP_URL_QUERY);
        $full_path = $path . ($query ? '?' . $query : '');
        $now = current_time('mysql');

        // 1) Cập nhật thời gian rời đi cho trang trước (nếu chưa có left_at)
        $wpdb->query($wpdb->prepare(
            "UPDATE $table_views SET left_at = %s WHERE session_id = %s AND left_at IS NULL AND url <> %s",
            $now, $session_id, $url
        ));

        // 2) Upsert lượt xem cho URL hiện tại (không tạo duplicate khi reload)
        $existing_id = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table_views WHERE session_id = %s AND url = %s AND left_at IS NULL ORDER BY id DESC LIMIT 1",
            $session_id, $url
        ));
        if ($existing_id) {
            $wpdb->update($table_views, ['left_at' => null, 'updated_at' => $now], ['id' => $existing_id], ['%s', '%s'], ['%d']);
        } else {
            $wpdb->insert($table_views, [
                'session_id' => $session_id,
                'url'        => $url,
                'title'      => $title,
                'entered_at' => $now,
                'left_at'    => null,
                'updated_at' => $now
            ], ['%s', '%s', '%s', '%s', '%s', '%s']);
        }


        // 3) Cảnh báo trang mục tiêu (chỉ 1 lần mỗi URL)
        $keywords = array_map('trim', explode(',', get_option('ai_chat_target_keywords', 'bang-gia, pricing, thanh-toan, checkout, gio-hang, cart, landing')));
        $keywords = array_filter($keywords);
        $is_target = false;
        foreach ($keywords as $kw) {
            if ($kw && stripos($url, $kw) !== false) {
                $is_target = true;
                break;
            }
        }
        if ($is_target) {
            $flag_key = 'ai_chat_target_flag_' . md5($session_id . '|' . $url);
            if (!get_transient($flag_key)) {
                set_transient($flag_key, 1, DAY_IN_SECONDS);
                $this->send_telegram_notification(
                    "🚨 <b>CẢNH BÁO TRANG MỤC TIÊU</b>\n" .
                    "Khách hàng đang truy cập trang quan trọng:\n" .
                    "📍 <b>" . esc_html($title ?: $url) . "</b>\n" .
                    "🔗 <a href=\"" . esc_url($url) . "\">" . esc_html($full_path) . "</a>\n" .
                    "🆔 Session: " . esc_html($session_id) . "\n" .
                    "⏰ " . esc_html(current_time('d/m/Y H:i:s'))
                );
            }
        }

        // 4) Gom toàn bộ hành trình vào MỘT tin nhắn duy nhất (edit message)
        $views = $wpdb->get_results($wpdb->prepare(
            "SELECT url, title, entered_at, left_at FROM $table_views WHERE session_id = %s ORDER BY id ASC",
            $session_id
        ));

        $lines = [];
        foreach ($views as $v) {
            $line = "• " . esc_html($v->title ?: $v->url);
            $enter = strtotime($v->entered_at);
            if ($enter) $line .= " <i>(vào " . date('H:i', $enter) . ")</i>";
            if ($v->left_at) {
                $leave = strtotime($v->left_at);
                $dur = max(0, $leave - $enter);
                $mins = floor($dur / 60);
                $secs = $dur % 60;
                $line .= " <b>⏱ " . $mins . "p" . $secs . "s</b>";
            } else {
                $line .= " <b>⏳ đang xem</b>";
            }
            $lines[] = $line;
        }

        $username = $wpdb->get_var($wpdb->prepare(
            "SELECT name FROM {$wpdb->prefix}ai_chat_leads WHERE session_id = %s LIMIT 1",
            $session_id
        ));

        $prefix_text = "";
        if ($username) {
            $prefix_text .= "👤 <b>" . esc_html($username) . "</b>\n";
        }
        $prefix_text .= "🆔 " . esc_html($session_id) . "\n";

        $journey_text = "🧭 <b>HÀNH TRÌNH KHÁCH</b>\n" . $prefix_text . implode("\n", $lines);

        // Lấy msg_id đã lưu trước đó để edit tin nhắn
        $tracking_row = $wpdb->get_var($wpdb->prepare(
            "SELECT msg_id FROM $table_views WHERE session_id = %s AND msg_id IS NOT NULL ORDER BY id DESC LIMIT 1",
            $session_id
        ));

        if ($tracking_row) {
            $edit_ok = $this->send_telegram_edit_message($tracking_row, $journey_text);
            if (!$edit_ok) {
                // Tin cũ có thể đã bị xóa trên Telegram → gửi tin mới
                $msg_id = $this->send_telegram_notification($journey_text);
                if ($msg_id) {
                    $wpdb->query($wpdb->prepare(
                        "UPDATE $table_views SET msg_id = %s WHERE session_id = %s",
                        $msg_id, $session_id
                    ));
                }
            }
        } else {
            // Lần đầu: gửi tin mới và lưu message_id để lần sau edit
            $msg_id = $this->send_telegram_notification($journey_text);
            if ($msg_id) {
                $wpdb->update($table_views, ['msg_id' => $msg_id], ['session_id' => $session_id], ['%s'], ['%s']);
                $wpdb->query($wpdb->prepare(
                    "UPDATE $table_views SET msg_id = %s WHERE session_id = %s AND msg_id IS NULL",
                    $msg_id, $session_id
                ));
            }
        }

        // 5) Lên lịch cảnh báo onsite (chỉ 1 lần mỗi URL, tránh spam)
        $onsite_timeout = max(30, intval(get_option('ai_chat_onsite_timeout', 150)));
        $onsite_key = 'ai_chat_onsite_sched_' . md5($session_id . '|' . $url);
        if (!get_transient($onsite_key)) {
            set_transient($onsite_key, 1, $onsite_timeout + 60);
            wp_schedule_single_event(time() + $onsite_timeout, 'ai_chat_onsite_check', [$session_id, $url]);
        }

        wp_send_json_success(['journey' => $journey_text]);
    }

    // Callback WP-Cron: Kiểm tra khách còn dừng ở trang không → cảnh báo onsite
    public function onsite_check_callback($session_id, $url) {
        global $wpdb;
        $table_views = $wpdb->prefix . 'ai_chat_page_views';

        // Kiểm tra vẫn còn trên trang (left_at chưa được set)
        $still_on = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table_views WHERE session_id = %s AND url = %s AND left_at IS NULL ORDER BY id DESC LIMIT 1",
            $session_id, $url
        ));

        if (!$still_on) return; // Đã rời trang

        // Chỉ báo 1 lần mỗi URL
        $flag_key = 'ai_chat_onsite_flag_' . md5($session_id . '|' . $url);
        if (get_transient($flag_key)) return;
        set_transient($flag_key, 1, DAY_IN_SECONDS);

        $title = $wpdb->get_var($wpdb->prepare(
            "SELECT title FROM $table_views WHERE session_id = %s AND url = %s ORDER BY id DESC LIMIT 1",
            $session_id, $url
        ));

        $this->send_telegram_notification(
            "⏰ <b>CẢNH BÁO ONSITE</b>\n" .
            "Khách hàng đã dừng lại lâu tại:\n" .
            "📍 <b>" . esc_html($title ?: $url) . "</b>\n" .
            "🔗 <a href=\"" . esc_url($url) . "\">" . esc_html($url) . "</a>\n" .
            "🆔 Session: " . esc_html($session_id) . "\n" .
            "⏰ " . esc_html(current_time('d/m/Y H:i:s'))
        );
    }

    /* 8.1 GỬI TELEGRAM (Đổi sang Parse Mode HTML an toàn hơn) */
    private function send_telegram_notification($text) {
        $token   = get_option('ai_chat_telegram_token');
        $chat_id = get_option('ai_chat_telegram_chat_id');

        if (!$token || !$chat_id) return;

        $response = wp_remote_post("https://api.telegram.org/bot{$token}/sendMessage", [
            'body' => [
                'chat_id'    => $chat_id,
                'text'       => $text,
                'parse_mode' => 'HTML'
            ],
            'sslverify' => true
        ]);

        // Trả về message_id nếu thành công (dùng để edit về sau)
        if (!is_wp_error($response)) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            if (isset($body['ok']) && $body['ok'] && isset($body['result']['message_id'])) {
                return $body['result']['message_id'];
            }
        }
        return null;
    }

    // Gửi edit tin nhắn Telegram (gom hành trình) — trả về true nếu thành công
    private function send_telegram_edit_message($message_id, $text) {
        $token   = get_option('ai_chat_telegram_token');
        $chat_id = get_option('ai_chat_telegram_chat_id');

        if (!$token || !$chat_id || !$message_id) return false;

        $response = wp_remote_post("https://api.telegram.org/bot{$token}/editMessageText", [
            'body' => [
                'chat_id'    => $chat_id,
                'message_id' => $message_id,
                'text'       => $text,
                'parse_mode' => 'HTML'
            ],
            'sslverify' => true
        ]);

        if (is_wp_error($response)) return false;
        $body = json_decode(wp_remote_retrieve_body($response), true);
        return isset($body['ok']) && $body['ok'];
    }
}

new AISalesChatbox();