<?php
/**
 * Plugin Name: Kira AI
 * Plugin URI: https://kiraai.vn/
 * Description: Plugin tích hợp Kira AI API để sinh nội dung, viết bài hàng loạt, hẹn giờ xuất bản, viết lại tiêu đề, bài viết, tạo ảnh đại diện cho Post Types và Taxonomies.
 * Version: 1.2.0
 * Author: Kira AI
 * Author URI: https://kiraai.vn/
 * License: GPLv2 or later
 * Text Domain: kira-ai
 */

if (!defined('ABSPATH')) {
    exit;
}

class Kira_AI
{
    private static $instance = null;
    const LOGO_URL = 'https://cyberservices.vn/wp-content/uploads/2026/08/tach-nen-CS.png';

    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        $this->define_constants();
        $this->init_hooks();
    }

    private function define_constants()
    {
        define('KIRA_AI_VERSION', '1.2.0');
        define('KIRA_AI_DIR', plugin_dir_path(__FILE__));
        define('KIRA_AI_URL', plugin_dir_url(__FILE__));
    }

    private function init_hooks()
    {
        add_action('admin_menu', array($this, 'add_admin_menu'), 100);
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('admin_footer', array($this, 'render_modal_html'));
        
        // Single & Bulk AJAX endpoints
        add_action('wp_ajax_kira_ai_generate_post_text', array($this, 'ajax_generate_post_text'));
        add_action('wp_ajax_kira_ai_generate_post_image', array($this, 'ajax_generate_post_image'));

        // Hooks for row actions on existing posts
        add_filter('post_row_actions', array($this, 'add_post_row_actions'), 10, 2);
        add_filter('page_row_actions', array($this, 'add_post_row_actions'), 10, 2);

        // Hooks for row actions on existing taxonomies
        $enabled_taxonomies = get_option('kira_ai_taxonomies', array());
        if (is_array($enabled_taxonomies)) {
            foreach ($enabled_taxonomies as $taxonomy) {
                add_filter("{$taxonomy}_row_actions", array($this, 'add_term_row_actions'), 10, 2);
            }
        }

        // AJAX handlers for processing existing posts and terms
        add_action('wp_ajax_kira_ai_process_existing_post', array($this, 'ajax_process_existing_post'));
        add_action('wp_ajax_kira_ai_process_existing_term', array($this, 'ajax_process_existing_term'));
        add_action('wp_ajax_kira_ai_generate_standalone_image', array($this, 'ajax_generate_standalone_image'));
        add_action('wp_ajax_kira_ai_test_connection', array($this, 'ajax_test_connection'));
        add_action('wp_ajax_kira_ai_sync_models', array($this, 'ajax_sync_models'));
    }

    public function add_term_row_actions($actions, $term)
    {
        $enabled_taxonomies = get_option('kira_ai_taxonomies', array());
        if (!in_array($term->taxonomy, $enabled_taxonomies)) {
            return $actions;
        }

        $actions['kira_ai_term_gen_image'] = sprintf(
            '<a href="#" class="kira-ai-term-row-action kira-ai-row-action" data-action="term_gen_image" data-term-id="%d" data-term-name="%s" data-taxonomy="%s">%s</a>',
            $term->term_id,
            esc_attr($term->name),
            esc_attr($term->taxonomy),
            __('AI Tạo ảnh', 'kira-ai')
        );
        $actions['kira_ai_term_gen_desc'] = sprintf(
            '<a href="#" class="kira-ai-term-row-action kira-ai-row-action" data-action="term_gen_desc" data-term-id="%d" data-term-name="%s" data-taxonomy="%s">%s</a>',
            $term->term_id,
            esc_attr($term->name),
            esc_attr($term->taxonomy),
            __('AI Tạo mô tả', 'kira-ai')
        );

        return $actions;
    }

    public function add_post_row_actions($actions, $post)
    {
        $enabled_post_types = get_option('kira_ai_post_types', array());
        if (!in_array($post->post_type, $enabled_post_types)) {
            return $actions;
        }

        $actions['kira_ai_gen_image'] = sprintf(
            '<a href="#" class="kira-ai-row-action" data-action="gen_image" data-post-id="%d" data-post-title="%s">%s</a>',
            $post->ID,
            esc_attr($post->post_title),
            __('AI Tạo ảnh', 'kira-ai')
        );
        $actions['kira_ai_rewrite_title'] = sprintf(
            '<a href="#" class="kira-ai-row-action" data-action="rewrite_title" data-post-id="%d" data-post-title="%s">%s</a>',
            $post->ID,
            esc_attr($post->post_title),
            __('AI Viết lại Title', 'kira-ai')
        );
        $actions['kira_ai_rewrite_content'] = sprintf(
            '<a href="#" class="kira-ai-row-action" data-action="rewrite_content" data-post-id="%d" data-post-title="%s">%s</a>',
            $post->ID,
            esc_attr($post->post_title),
            __('AI Viết lại Nội dung', 'kira-ai')
        );

        return $actions;
    }

    public function add_admin_menu()
    {
        add_menu_page(
            'Cấu hình Kira AI',
            'Kira AI',
            'manage_options',
            'kira-ai-settings',
            array($this, 'render_settings_page'),
            'dashicons-admin-customizer',
            80
        );
    }

    public function render_settings_page()
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        if (isset($_POST['kira_ai_save']) && check_admin_referer('kira_ai_nonce_action', 'kira_ai_nonce_field')) {
            update_option('kira_ai_api_key', isset($_POST['kira_ai_api_key']) ? sanitize_text_field($_POST['kira_ai_api_key']) : '');
            update_option('kira_ai_text_model', isset($_POST['kira_ai_text_model']) ? sanitize_text_field($_POST['kira_ai_text_model']) : 'kira-3.5-flash');
            update_option('kira_ai_image_model', isset($_POST['kira_ai_image_model']) ? sanitize_text_field($_POST['kira_ai_image_model']) : 'kira-2.5-flash-image');

            $selected_post_types = isset($_POST['post_types']) ? array_map('sanitize_text_field', $_POST['post_types']) : array();
            $selected_taxonomies = isset($_POST['taxonomies']) ? array_map('sanitize_text_field', $_POST['taxonomies']) : array();

            update_option('kira_ai_post_types', $selected_post_types);
            update_option('kira_ai_taxonomies', $selected_taxonomies);

            echo '<div class="updated"><p>Cấu hình Kira AI đã được lưu thành công.</p></div>';
        }

        if (isset($_POST['kira_ai_clear_logs']) && check_admin_referer('kira_ai_clear_logs_action', 'kira_ai_clear_logs_field')) {
            update_option('kira_ai_api_logs', array());
            echo '<div class="updated"><p>Lịch sử Log API đã được xóa thành công.</p></div>';
        }

        $api_key = get_option('kira_ai_api_key', '');
        $text_model = get_option('kira_ai_text_model', 'kira-3.5-flash');
        $image_model = get_option('kira_ai_image_model', 'kira-2.5-flash-image');
        $models = $this->get_kira_models();
        $enabled_post_types = get_option('kira_ai_post_types', array());
        $enabled_taxonomies = get_option('kira_ai_taxonomies', array());
        $logs = get_option('kira_ai_api_logs', array());
        if (!is_array($logs)) {
            $logs = array();
        }

        $post_types = get_post_types(array('public' => true), 'objects');
        $taxonomies = get_taxonomies(array('public' => true), 'objects');
        ?>
        <div class="wrap kira-ai-admin-wrap">
            <h1>Kira AI - Cấu hình & Tạo bài viết hàng loạt</h1>
            <p>Hệ thống tự động hóa nội dung chuẩn SEO Top 1 Google & Sinh ảnh bản quyền gắn logo CyberServices.</p>

            <h2 class="nav-tab-wrapper" style="margin-bottom: 20px;">
                <a href="#settings" class="nav-tab nav-tab-active" id="kira-tab-settings-nav">Cấu hình chung</a>
                <a href="#bulk" class="nav-tab" id="kira-tab-bulk-nav">Tạo bài viết hàng loạt (Bulk)</a>
                <a href="#logs" class="nav-tab" id="kira-tab-logs-nav">Log API</a>
            </h2>

            <!-- TAB 1: CẤU HÌNH -->
            <div id="kira-tab-settings" class="kira-tab-content-wrapper">
                <form method="post" action=""
                    style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); max-width: 850px; margin-top: 10px;">
                    <?php wp_nonce_field('kira_ai_nonce_action', 'kira_ai_nonce_field'); ?>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="kira_ai_api_key">Kira AI API Key</label></th>
                            <td>
                                <div style="display: flex; gap: 10px; align-items: center; margin-bottom: 5px;">
                                    <input name="kira_ai_api_key" type="password" id="kira_ai_api_key"
                                        value="<?php echo esc_attr($api_key); ?>" class="regular-text"
                                        placeholder="Nhập API Key của bạn">
                                    <button type="button" id="kira-ai-test-connection-btn" class="button button-secondary">Kiểm tra kết nối</button>
                                </div>
                                <div id="kira-ai-connection-status" style="font-weight: 600; font-size: 13px; margin-bottom: 10px;"></div>
                                <p class="description">API Key được cấp bởi hệ thống <a href="https://kiraai.vn/" target="_blank" style="font-weight: 600; text-decoration: none;">Kira AI</a>.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="kira_ai_text_model">Model sinh văn bản</label></th>
                            <td>
                                <div style="display: flex; gap: 10px; align-items: center;">
                                    <select name="kira_ai_text_model" id="kira_ai_text_model" style="max-width: 350px; width: 100%;">
                                        <?php 
                                        if (!empty($models['text_models'])) {
                                            foreach ($models['text_models'] as $m) {
                                                echo '<option value="' . esc_attr($m['id']) . '" ' . selected($text_model, $m['id'], false) . '>' . esc_html($m['name']) . '</option>';
                                            }
                                        }
                                        ?>
                                    </select>
                                    <button type="button" id="kira-ai-sync-models-btn" class="button button-secondary" style="display: inline-flex; align-items: center; gap: 5px;">
                                        <span class="dashicons dashicons-update" style="font-size: 16px; width: 16px; height: 16px; line-height: 16px; margin: 0;"></span>
                                        Cập nhật model
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="kira_ai_image_model">Model sinh hình ảnh</label></th>
                            <td>
                                <select name="kira_ai_image_model" id="kira_ai_image_model" class="regular-text" style="max-width: 350px; width: 100%;">
                                    <?php 
                                    if (!empty($models['image_models'])) {
                                        foreach ($models['image_models'] as $m) {
                                            echo '<option value="' . esc_attr($m['id']) . '" ' . selected($image_model, $m['id'], false) . '>' . esc_html($m['name']) . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Áp dụng cho Post Types:</th>
                            <td>
                                <?php foreach ($post_types as $pt):
                                    $checked = in_array($pt->name, $enabled_post_types) ? 'checked' : '';
                                    ?>
                                    <label style="display: block; margin-bottom: 8px;">
                                        <input type="checkbox" name="post_types[]" value="<?php echo esc_attr($pt->name); ?>" <?php echo $checked; ?> />
                                        <?php echo esc_html($pt->label); ?> <span style="color: #888; font-size: 12px;">(<?php echo esc_html($pt->name); ?>)</span>
                                    </label>
                                <?php endforeach; ?>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Áp dụng cho Taxonomies:</th>
                            <td>
                                <?php foreach ($taxonomies as $tax):
                                    $checked = in_array($tax->name, $enabled_taxonomies) ? 'checked' : '';
                                    ?>
                                    <label style="display: block; margin-bottom: 8px;">
                                        <input type="checkbox" name="taxonomies[]" value="<?php echo esc_attr($tax->name); ?>" <?php echo $checked; ?> />
                                        <?php echo esc_html($tax->label); ?> <span style="color: #888; font-size: 12px;">(<?php echo esc_html($tax->name); ?>)</span>
                                    </label>
                                <?php endforeach; ?>
                            </td>
                        </tr>
                    </table>

                    <p class="submit">
                        <input type="submit" name="kira_ai_save" class="button button-primary" value="Lưu cấu hình" />
                    </p>
                </form>
            </div>

            <!-- TAB 2: TẠO BÀI VIẾT HÀNG LOẠT (BULK GENERATOR & SCHEDULE) -->
            <div id="kira-tab-bulk" class="kira-tab-content-wrapper" style="display: none;">
                <div class="kira-bulk-container" style="display: flex; gap: 24px; flex-wrap: wrap; margin-top: 10px;">
                    
                    <!-- Left: Bulk Form -->
                    <div style="flex: 1; min-width: 380px; max-width: 550px; background: #fff; padding: 24px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
                        <h3 style="margin-top: 0; font-size: 17px; border-bottom: 1px solid #e2e8f0; padding-bottom: 12px;">1. Thiết lập bài viết & Lên lịch</h3>
                        
                        <div class="kira-ai-form-group">
                            <label for="kira-bulk-post-type"><strong>Loại bài viết (Post Type):</strong></label>
                            <select id="kira-bulk-post-type" class="regular-text" style="width: 100%;">
                                <?php 
                                $bulk_post_types = array_filter($post_types, function($pt) use ($enabled_post_types) {
                                    return $pt->name !== 'attachment' && in_array($pt->name, $enabled_post_types);
                                });
                                if (empty($bulk_post_types)) {
                                    $bulk_post_types = array_filter($post_types, function($pt) {
                                        return $pt->name !== 'attachment';
                                    });
                                }
                                foreach ($bulk_post_types as $pt): 
                                ?>
                                    <option value="<?php echo esc_attr($pt->name); ?>"><?php echo esc_html($pt->label); ?> (<?php echo esc_html($pt->name); ?>)</option>
                                <?php endforeach; ?>
                            </select>
                            <?php if (empty(array_filter($post_types, function($pt) use ($enabled_post_types) { return $pt->name !== 'attachment' && in_array($pt->name, $enabled_post_types); }))): ?>
                                <p class="description" style="color: #d97706; margin-top: 6px;">Chưa có Post Type nào được bật trong Cấu hình chung. Đang hiển thị tất cả.</p>
                            <?php endif; ?>
                        </div>

                        <div class="kira-ai-form-group" style="margin-top: 15px;">
                            <label for="kira-bulk-keywords"><strong>Danh sách từ khóa chính (Mỗi dòng 1 từ khóa):</strong></label>
                            <textarea id="kira-bulk-keywords" rows="8" class="large-text" placeholder="Đất nền Tiền Hải&#10;Dịch vụ SEO tổng thể&#10;Thiết kế website chuẩn SEO..." style="font-size: 13.5px; line-height: 1.5;"></textarea>
                            <div style="margin-top: 6px; display: flex; justify-content: space-between; align-items: center;">
                                <span style="font-size: 12px; color: #64748b;" id="kira-bulk-kw-count">0 từ khóa được phát hiện</span>
                                <label class="button button-small" style="cursor: pointer;">
                                    <span>Import file .txt / .csv</span>
                                    <input type="file" id="kira-bulk-file-import" accept=".txt,.csv" style="display: none;">
                                </label>
                            </div>
                        </div>

                        <div class="kira-ai-form-group" style="margin-top: 15px;">
                            <label for="kira-bulk-prompt"><strong>Yêu cầu chung / Prompt bổ sung (Áp dụng cho toàn bộ):</strong></label>
                            <textarea id="kira-bulk-prompt" rows="3" class="large-text" placeholder="Ví dụ: Phân tích chuyên sâu, giọng văn chuyên nghiệp, cung cấp số liệu thực tế..."></textarea>
                        </div>

                        <div class="kira-ai-form-group" style="margin-top: 15px; border-top: 1px dashed #e2e8f0; padding-top: 15px;">
                            <label><strong>Chế độ xuất bản & Hẹn giờ:</strong></label>
                            <div style="margin: 8px 0;">
                                <label style="margin-right: 15px;"><input type="radio" name="kira_bulk_status" value="draft" checked> Lưu bản nháp (Draft)</label>
                                <label style="margin-right: 15px;"><input type="radio" name="kira_bulk_status" value="publish"> Đăng ngay lập tức (Publish)</label>
                                <label><input type="radio" name="kira_bulk_status" value="future"> Hẹn giờ đăng (Schedule)</label>
                            </div>

                            <div id="kira-bulk-schedule-options" style="display: none; background: #f8fafc; padding: 14px; border-radius: 6px; border: 1px solid #e2e8f0; margin-top: 10px;">
                                <div style="margin-bottom: 10px;">
                                    <label style="display: block; font-size: 12px; color: #475569; margin-bottom: 4px;">Thời gian bắt đầu đăng bài đầu tiên:</label>
                                    <input type="datetime-local" id="kira-bulk-start-time" class="regular-text" style="width: 100%;" value="<?php echo current_time('Y-m-d\TH:i', 0); ?>">
                                </div>
                                <div>
                                    <label style="display: block; font-size: 12px; color: #475569; margin-bottom: 4px;">Khoảng cách giữa các bài viết:</label>
                                    <div style="display: flex; gap: 8px; align-items: center;">
                                        <input type="number" id="kira-bulk-interval-val" value="2" min="1" style="width: 80px;">
                                        <select id="kira-bulk-interval-unit" style="flex: 1;">
                                            <option value="minutes">Phút</option>
                                            <option value="hours" selected>Giờ</option>
                                            <option value="days">Ngày</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="kira-ai-form-group" style="margin-top: 15px;">
                            <label style="display: inline-flex; align-items: center; cursor: pointer;">
                                <input type="checkbox" id="kira-bulk-gen-image" value="1" checked style="margin-right: 8px;">
                                <strong>Sinh 3 ảnh WebP thực tế & tự chèn Logo CyberServices</strong>
                            </label>
                        </div>

                        <div style="margin-top: 20px;">
                            <button type="button" id="kira-bulk-start-btn" class="button button-primary button-hero" style="width: 100%; justify-content: center; display: flex; align-items: center; gap: 8px;">
                                <span class="dashicons dashicons-controls-play"></span> Bắt đầu tạo hàng loạt
                            </button>
                            <button type="button" id="kira-bulk-pause-btn" class="button button-secondary button-hero" style="width: 100%; justify-content: center; display: none; margin-top: 8px; color: #d97706;">
                                <span class="dashicons dashicons-controls-pause"></span> Tạm dừng tiến trình
                            </button>
                        </div>
                    </div>

                    <!-- Right: Progress & Realtime Queue Table -->
                    <div style="flex: 1.6; min-width: 480px; background: #fff; padding: 24px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
                        <h3 style="margin-top: 0; font-size: 17px; border-bottom: 1px solid #e2e8f0; padding-bottom: 12px;">2. Hàng đợi & Tiến trình xử lý (AJAX Queue)</h3>

                        <div class="kira-bulk-progress-box" style="margin-bottom: 20px;">
                            <div style="display: flex; justify-content: space-between; font-weight: 600; margin-bottom: 6px; font-size: 13.5px;">
                                <span>Tiến độ hoàn thành:</span>
                                <span id="kira-bulk-progress-text">0 / 0 bài</span>
                            </div>
                            <div style="background: #e2e8f0; height: 16px; border-radius: 10px; overflow: hidden;">
                                <div id="kira-bulk-progress-bar" style="background: linear-gradient(135deg, #ea580c 0%, #22c55e 100%); width: 0%; height: 100%; transition: width 0.3s ease;"></div>
                            </div>
                        </div>

                        <div style="max-height: 480px; overflow-y: auto; border: 1px solid #e2e8f0; border-radius: 6px;">
                            <table class="wp-list-table widefat fixed striped" id="kira-bulk-table">
                                <thead>
                                    <tr>
                                        <th style="width: 45px;">STT</th>
                                        <th>Từ khóa</th>
                                        <th style="width: 140px;">Lên lịch</th>
                                        <th style="width: 150px;">Trạng thái</th>
                                        <th style="width: 80px;">Tác vụ</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td colspan="5" style="text-align: center; color: #94a3b8; padding: 30px 0;">Chưa có từ khóa nào trong hàng đợi.</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TAB 3: LOGS -->
            <div id="kira-tab-logs" class="kira-tab-content-wrapper" style="display: none;">
                <div style="background: #fff; padding: 24px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); max-width: 1000px; margin-top: 10px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid #f1f5f9; padding-bottom: 15px;">
                        <h3 style="margin: 0; font-size: 16px; color: #1e293b;">Lịch sử gọi API gần đây</h3>
                        <?php if (!empty($logs)): ?>
                            <form method="post" action="" class="kira-ai-clear-logs-form" style="display:inline-block;">
                                <?php wp_nonce_field('kira_ai_clear_logs_action', 'kira_ai_clear_logs_field'); ?>
                                <button type="button" class="button button-secondary kira-ai-clear-logs-trigger" style="color: #ef4444; border-color: #fca5a5;">Xóa tất cả Log</button>
                                <span class="kira-ai-clear-logs-confirm" style="display:none; margin-left:10px; font-weight:bold; color:#ef4444; font-size:13px;">
                                    Bạn chắc chắn muốn xóa?
                                    <button type="submit" name="kira_ai_clear_logs" class="button button-link" style="color:#ef4444; padding:0 5px; font-weight:bold;">[Đồng ý]</button>
                                    <button type="button" class="button button-link kira-ai-clear-logs-cancel" style="color:#64748b; padding:0 5px;">[Hủy]</button>
                                </span>
                            </form>
                        <?php endif; ?>
                    </div>

                    <?php if (empty($logs)): ?>
                        <p style="color: #64748b; font-style: italic;">Chưa có lịch sử gọi API nào được ghi lại.</p>
                    <?php else: ?>
                        <div class="kira-logs-list">
                            <?php foreach ($logs as $index => $log):
                                $status_text = $log['status'] === 'success' ? 'Thành công' : 'Thất bại';
                                $status_color = $log['status'] === 'success' ? '#22c55e' : '#ef4444';
                                $status_bg = $log['status'] === 'success' ? '#f0fdf4' : '#fef2f2';
                                $status_border = $log['status'] === 'success' ? '#bbf7d0' : '#fca5a5';
                                ?>
                                <details style="border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 14px; overflow: hidden; background: #f8fafc;">
                                    <summary style="padding: 14px 18px; font-weight: 600; cursor: pointer; display: flex; align-items: center; justify-content: space-between; background: #ffffff;">
                                        <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
                                            <span style="font-size: 12.5px; color: #64748b; font-family: monospace;"><?php echo esc_html($log['time']); ?></span>
                                            <span style="background: <?php echo $status_bg; ?>; color: <?php echo $status_color; ?>; border: 1px solid <?php echo $status_border; ?>; font-size: 11px; padding: 2px 8px; border-radius: 6px; font-weight: 600; text-transform: uppercase;"><?php echo $status_text; ?></span>
                                            <strong style="font-size: 14px; color: #0f172a;"><?php echo esc_html($log['keyword']); ?></strong>
                                        </div>
                                        <div style="font-size: 12px; color: #64748b;">
                                            <span>Model:</span>
                                            <code style="background: #f1f5f9; padding: 2px 6px; border-radius: 4px;"><?php echo esc_html($log['model']); ?></code>
                                        </div>
                                    </summary>
                                    <div style="padding: 20px; border-top: 1px solid #e2e8f0; background: #ffffff;">
                                        <div style="margin-bottom: 18px; border-left: 3px solid #ea580c; padding-left: 12px; background: #f8fafc; padding-top: 8px; padding-bottom: 8px; border-radius: 0 6px 6px 0;">
                                            <h4 style="margin: 0 0 6px 0; font-size: 12.5px; text-transform: uppercase; color: #c2410c;">Từ khóa & Prompt yêu cầu</h4>
                                            <p style="margin: 0 0 6px 0; font-size: 14px; color: #1e293b;"><strong>Từ khóa chính:</strong> <?php echo esc_html($log['keyword']); ?></p>
                                            <p style="margin: 0; font-size: 14px; color: #1e293b;"><strong>Yêu cầu (Prompt):</strong> <?php echo esc_html($log['prompt']); ?></p>
                                        </div>
                                        <div style="margin-bottom: 18px;">
                                            <h4 style="margin: 0 0 6px 0; font-size: 12.5px; text-transform: uppercase; color: #64748b;">Prompt đầu vào đầy đủ</h4>
                                            <pre style="background: #f8fafc; padding: 14px; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 12px; white-space: pre-wrap; margin: 0; max-height: 250px; overflow-y: auto;"><?php echo esc_html($log['input_full']); ?></pre>
                                        </div>
                                        <div>
                                            <h4 style="margin: 0 0 6px 0; font-size: 12.5px; text-transform: uppercase; color: #64748b;">Phản hồi đầu ra</h4>
                                            <?php if ($log['status'] === 'success'): ?>
                                                <pre style="background: #f8fafc; padding: 14px; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 12px; white-space: pre-wrap; margin: 0; max-height: 350px; overflow-y: auto;"><?php echo esc_html($log['output']); ?></pre>
                                            <?php else: ?>
                                                <?php if (!empty($log['error'])): ?>
                                                    <div style="background: #fef2f2; color: #991b1b; border: 1px solid #fee2e2; padding: 14px; border-radius: 8px; font-size: 13.5px; margin-bottom: 12px;">
                                                        <strong>Lỗi API:</strong> <?php echo esc_html($log['error']); ?>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </details>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <script>
                document.addEventListener('DOMContentLoaded', function () {
                    const settingsNav = document.getElementById('kira-tab-settings-nav');
                    const bulkNav = document.getElementById('kira-tab-bulk-nav');
                    const logsNav = document.getElementById('kira-tab-logs-nav');
                    
                    const settingsTab = document.getElementById('kira-tab-settings');
                    const bulkTab = document.getElementById('kira-tab-bulk');
                    const logsTab = document.getElementById('kira-tab-logs');

                    function switchTab(tabId) {
                        settingsNav.classList.remove('nav-tab-active');
                        bulkNav.classList.remove('nav-tab-active');
                        logsNav.classList.remove('nav-tab-active');

                        settingsTab.style.display = 'none';
                        bulkTab.style.display = 'none';
                        logsTab.style.display = 'none';

                        if (tabId === 'bulk') {
                            bulkNav.classList.add('nav-tab-active');
                            bulkTab.style.display = 'block';
                        } else if (tabId === 'logs') {
                            logsNav.classList.add('nav-tab-active');
                            logsTab.style.display = 'block';
                        } else {
                            settingsNav.classList.add('nav-tab-active');
                            settingsTab.style.display = 'block';
                        }
                    }

                    settingsNav.addEventListener('click', function (e) {
                        e.preventDefault();
                        switchTab('settings');
                        window.location.hash = 'settings';
                    });

                    bulkNav.addEventListener('click', function (e) {
                        e.preventDefault();
                        switchTab('bulk');
                        window.location.hash = 'bulk';
                    });

                    logsNav.addEventListener('click', function (e) {
                        e.preventDefault();
                        switchTab('logs');
                        window.location.hash = 'logs';
                    });

                    if (window.location.hash === '#bulk') {
                        switchTab('bulk');
                    } else if (window.location.hash === '#logs') {
                        switchTab('logs');
                    }

                    const triggerBtn = document.querySelector('.kira-ai-clear-logs-trigger');
                    const confirmSpan = document.querySelector('.kira-ai-clear-logs-confirm');
                    const cancelBtn = document.querySelector('.kira-ai-clear-logs-cancel');

                    if (triggerBtn && confirmSpan && cancelBtn) {
                        triggerBtn.addEventListener('click', function (e) {
                            e.preventDefault();
                            triggerBtn.style.display = 'none';
                            confirmSpan.style.display = 'inline-block';
                        });

                        cancelBtn.addEventListener('click', function (e) {
                            e.preventDefault();
                            confirmSpan.style.display = 'none';
                            triggerBtn.style.display = 'inline-block';
                        });
                    }
                });
            </script>
        </div>
        <?php
    }

    public function enqueue_admin_assets($hook)
    {
        $should_enqueue = false;
        $post_type = '';
        $taxonomy = '';

        if ('edit.php' === $hook) {
            $post_type = isset($_GET['post_type']) ? sanitize_text_field($_GET['post_type']) : 'post';
            $enabled_post_types = get_option('kira_ai_post_types', array());
            if (in_array($post_type, $enabled_post_types)) {
                $should_enqueue = true;
            }
        } elseif ('edit-tags.php' === $hook) {
            $taxonomy = isset($_GET['taxonomy']) ? sanitize_text_field($_GET['taxonomy']) : 'category';
            $enabled_taxonomies = get_option('kira_ai_taxonomies', array());
            if (in_array($taxonomy, $enabled_taxonomies)) {
                $should_enqueue = true;
            }
        } elseif ('upload.php' === $hook) {
            $enabled_post_types = get_option('kira_ai_post_types', array());
            if (in_array('attachment', $enabled_post_types)) {
                $should_enqueue = true;
            }
        } elseif ('toplevel_page_kira-ai-settings' === $hook) {
            $should_enqueue = true;
        }

        if (!$should_enqueue) {
            return;
        }

        wp_enqueue_style('kira-ai-admin-css', KIRA_AI_URL . 'assets/css/kira-ai-admin.css', array(), KIRA_AI_VERSION);
        wp_enqueue_script('kira-ai-admin-js', KIRA_AI_URL . 'assets/js/kira-ai-admin.js', array('jquery'), KIRA_AI_VERSION, true);
        wp_localize_script('kira-ai-admin-js', 'kira_ai_params', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('kira_ai_generate_nonce'),
            'post_type' => $post_type,
            'taxonomy' => $taxonomy,
            'is_media' => ('upload.php' === $hook),
            'admin_url' => admin_url()
        ));
    }

    public function render_modal_html()
    {
        if (isset($_GET['page']) && $_GET['page'] === 'kira-ai-settings') {
            return;
        }
        global $pagenow;

        $should_render = false;

        if ('edit.php' === $pagenow) {
            $post_type = isset($_GET['post_type']) ? sanitize_text_field($_GET['post_type']) : 'post';
            $enabled_post_types = get_option('kira_ai_post_types', array());
            if (in_array($post_type, $enabled_post_types)) {
                $should_render = true;
            }
        } elseif ('edit-tags.php' === $pagenow) {
            $taxonomy = isset($_GET['taxonomy']) ? sanitize_text_field($_GET['taxonomy']) : 'category';
            $enabled_taxonomies = get_option('kira_ai_taxonomies', array());
            if (in_array($taxonomy, $enabled_taxonomies)) {
                $should_render = true;
            }
        } elseif ('upload.php' === $pagenow) {
            $enabled_post_types = get_option('kira_ai_post_types', array());
            if (in_array('attachment', $enabled_post_types)) {
                $should_render = true;
            }
        }

        if (!$should_render) {
            return;
        }

        $post_type = isset($_GET['post_type']) ? sanitize_text_field($_GET['post_type']) : 'post';
        $post_type_object = get_post_type_object($post_type);
        $post_type_label = $post_type_object ? $post_type_object->labels->singular_name : 'Bài viết';
        ?>
        <div id="kira-ai-modal-backdrop" class="kira-ai-modal-backdrop">
            <div class="kira-ai-modal">
                <div class="kira-ai-modal-header">
                    <h3>
                        <span class="icon-glow"><span class="dashicons dashicons-admin-customizer"></span></span>
                        Tạo nội dung <?php echo esc_html($post_type_label); ?> với AI
                    </h3>
                    <button type="button" class="kira-ai-modal-close">&times;</button>
                </div>

                <div class="kira-ai-modal-body">
                    <div class="kira-ai-error-msg"></div>

                    <form id="kira-ai-form">
                        <div class="kira-ai-form-group">
                            <label for="kira-ai-keyword">Từ khóa chính (Focus Keyword)</label>
                            <input type="text" id="kira-ai-keyword" class="kira-ai-input" placeholder="Ví dụ: đất nền Tiền Hải, dịch vụ SEO..." required>
                        </div>

                        <div class="kira-ai-form-group">
                            <label for="kira-ai-prompt">Yêu cầu viết bài (Prompt)</label>
                            <textarea id="kira-ai-prompt" class="kira-ai-input kira-ai-textarea" placeholder="Nhập yêu cầu chi tiết của bạn để AI viết bài..." required></textarea>
                        </div>

                        <div class="kira-ai-form-group" style="margin-top: 15px;">
                            <label style="display: block; margin-bottom: 5px; font-weight: 600;">Chế độ xuất bản:</label>
                            <select id="kira-ai-post-status" class="kira-ai-input" style="margin-bottom: 10px;">
                                <option value="draft">Lưu bản nháp (Draft)</option>
                                <option value="publish">Xuất bản ngay (Publish)</option>
                            </select>
                        </div>

                        <div class="kira-ai-form-group" style="margin-top: 10px;">
                            <label style="display: inline-flex; align-items: center; font-weight: 500; cursor: pointer;">
                                <input type="checkbox" id="kira-ai-gen-image" value="1" checked style="margin-right: 8px; width: 16px; height: 16px;">
                                Tạo ảnh đại diện & tự chèn 2 ảnh WebP thực tế có Logo CyberServices
                            </label>
                        </div>
                    </form>

                    <div class="kira-ai-loading-container">
                        <div class="kira-ai-spinner"></div>
                        <div class="kira-ai-loading-text">AI đang soạn thảo nội dung...</div>
                        <div class="kira-ai-loading-subtext">Quá trình này có thể mất từ 30 giây đến 1 phút do AI phân tích chuyên sâu và chèn logo tự động.</div>

                        <ul class="kira-ai-progress-steps">
                            <li id="kira-step-text" class="step-pending">
                                <span class="step-icon"></span>
                                <span class="step-label">Soạn thảo văn bản & Tối ưu SEO</span>
                            </li>
                            <li id="kira-step-image" class="step-pending">
                                <span class="step-icon"></span>
                                <span class="step-label">Chụp 3 ảnh thực tế WebP & Chèn Logo CyberServices</span>
                            </li>
                            <li id="kira-step-save" class="step-pending">
                                <span class="step-icon"></span>
                                <span class="step-label">Lưu trữ bài viết & Hoàn tất</span>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="kira-ai-modal-footer">
                    <button type="button" class="kira-ai-btn kira-ai-btn-secondary">Hủy bỏ</button>
                    <button type="button" id="kira-ai-submit" class="kira-ai-btn kira-ai-btn-primary">
                        <span class="dashicons dashicons-admin-customizer"></span> Bắt đầu tạo bài viết
                    </button>
                </div>
            </div>
        </div>

        <div id="kira-ai-action-modal-backdrop" class="kira-ai-modal-backdrop">
            <div class="kira-ai-modal">
                <div class="kira-ai-modal-header">
                    <h3>
                        <span class="icon-glow"><span class="dashicons dashicons-admin-customizer"></span></span>
                        <span id="kira-ai-action-modal-title">AI Xử lý bài viết</span>
                    </h3>
                    <button type="button" class="kira-ai-action-modal-close kira-ai-modal-close">&times;</button>
                </div>

                <div class="kira-ai-modal-body">
                    <div class="kira-ai-action-error-msg kira-ai-error-msg"></div>

                    <form id="kira-ai-action-form">
                        <input type="hidden" id="kira-ai-action-post-id" value="">
                        <input type="hidden" id="kira-ai-action-type" value="">

                        <div class="kira-ai-form-group">
                            <p id="kira-ai-action-description" style="font-size: 13.5px; color: #475569; background: #f8fafc; padding: 12px; border-radius: 8px; border-left: 3px solid #ea580c; margin-top: 0; line-height: 1.5;"></p>
                        </div>

                        <div class="kira-ai-form-group">
                            <label for="kira-ai-action-custom-prompt">Yêu cầu bổ sung (Custom Prompt - Tùy chọn)</label>
                            <textarea id="kira-ai-action-custom-prompt" class="kira-ai-input kira-ai-textarea" placeholder="Nhập thêm các yêu cầu đặc biệt..." style="min-height: 80px;"></textarea>
                        </div>
                    </form>

                    <div class="kira-ai-action-loading-container kira-ai-loading-container" style="display:none;">
                        <div class="kira-ai-spinner"></div>
                        <div class="kira-ai-action-loading-text kira-ai-loading-text">AI đang xử lý yêu cầu...</div>
                        <div class="kira-ai-action-loading-subtext kira-ai-loading-subtext">Quá trình này có thể mất từ 15 đến 45 giây.</div>
                    </div>
                </div>

                <div class="kira-ai-modal-footer">
                    <button type="button" class="kira-ai-btn kira-ai-action-btn-secondary kira-ai-btn-secondary">Hủy bỏ</button>
                    <button type="button" id="kira-ai-action-submit" class="kira-ai-btn kira-ai-btn-primary">
                        <span class="dashicons dashicons-admin-customizer"></span> Xác nhận thực hiện
                    </button>
                </div>
            </div>
        </div>

        <div id="kira-ai-media-modal-backdrop" class="kira-ai-modal-backdrop">
            <div class="kira-ai-modal">
                <div class="kira-ai-modal-header">
                    <h3>
                        <span class="icon-glow"><span class="dashicons dashicons-admin-customizer"></span></span>
                        Tạo ảnh chụp thực tế với AI
                    </h3>
                    <button type="button" class="kira-ai-media-modal-close kira-ai-modal-close">&times;</button>
                </div>

                <div class="kira-ai-modal-body">
                    <div class="kira-ai-media-error-msg kira-ai-error-msg"></div>

                    <form id="kira-ai-media-form">
                        <div class="kira-ai-form-group">
                            <label for="kira-ai-media-prompt">Yêu cầu vẽ ảnh (Prompt)</label>
                            <textarea id="kira-ai-media-prompt" class="kira-ai-input kira-ai-textarea" placeholder="Mô tả bối cảnh ảnh thực tế bạn muốn tạo..." required></textarea>
                        </div>

                        <div class="kira-ai-form-group">
                            <label for="kira-ai-media-aspect-ratio">Kích thước ảnh (Aspect Ratio)</label>
                            <select id="kira-ai-media-aspect-ratio" class="kira-ai-input">
                                <option value="16:9">Ngang (16:9)</option>
                                <option value="9:16">Dọc (9:16)</option>
                                <option value="4:3">Ngang (4:3)</option>
                                <option value="3:4">Dọc (3:4)</option>
                                <option value="1:1">Vuông (1:1)</option>
                            </select>
                        </div>
                    </form>

                    <div class="kira-ai-media-loading-container kira-ai-loading-container" style="display:none;">
                        <div class="kira-ai-spinner"></div>
                        <div class="kira-ai-media-loading-text kira-ai-loading-text">AI đang chụp ảnh và gắn logo...</div>
                        <div class="kira-ai-media-loading-subtext kira-ai-loading-subtext">Quá trình này mất khoảng 15 đến 20 giây.</div>
                    </div>
                </div>

                <div class="kira-ai-modal-footer">
                    <button type="button" class="kira-ai-btn kira-ai-media-btn-secondary kira-ai-btn-secondary">Hủy bỏ</button>
                    <button type="button" id="kira-ai-media-submit" class="kira-ai-btn kira-ai-btn-primary">
                        <span class="dashicons dashicons-admin-customizer"></span> Bắt đầu tạo ảnh
                    </button>
                </div>
            </div>
        </div>
        <?php
    }

    private function build_realistic_photo_prompt($description)
    {
        return "A real, high-resolution authentic professional photograph of {$description}. " .
               "Real-life photography style, natural lighting, realistic textures, shot on 35mm DSLR lens, vivid details, 8k resolution, authentic atmosphere. " .
               "--negative prompt / strict avoidance: no 3D render, no CGI, no cartoon, no anime, no drawing, no artificial looking, no deformed bodies or extra limbs, " .
               "no text, no watermark, no logo, no captions, no subtitles, no words, no blurry details, no noise.";
    }

    /**
     * Build internal link context data for AI prompts.
     *
     * @param string $keyword         The focus keyword.
     * @param int    $exclude_post_id Post ID to exclude (for rewrite).
     * @return array{existing_titles_str: string, landing_pages_json: string, related_posts_json: string}
     */
    private function build_internal_link_context($keyword, $exclude_post_id = 0)
    {
        $query_args = array(
            'numberposts' => 40,
            'post_status' => 'publish',
            'post_type'   => array('post', 'page'),
        );
        if ($exclude_post_id) {
            $query_args['exclude'] = array($exclude_post_id);
        }

        $all_contents = get_posts($query_args);

        $scored_items          = array();
        $current_keyword_lower = mb_strtolower($keyword, 'UTF-8');
        $keyword_words         = array_filter(explode(' ', $current_keyword_lower), function ($w) {
            return mb_strlen($w) > 2;
        });

        foreach ($all_contents as $item) {
            $item_title_lower = mb_strtolower($item->post_title, 'UTF-8');
            $score            = 0;

            foreach ($keyword_words as $word) {
                if (strpos($item_title_lower, $word) !== false) {
                    $score += 2;
                }
            }

            if (strpos($item_title_lower, $current_keyword_lower) !== false) {
                $score += 6;
            }

            $is_landing_page = ($item->post_type === 'page');
            if ($is_landing_page && $score > 0) {
                $score += 8;
            }

            $scored_items[] = array(
                'item'            => $item,
                'score'           => $score,
                'is_landing_page' => $is_landing_page,
            );
        }

        usort($scored_items, function ($a, $b) {
            return $b['score'] - $a['score'];
        });

        $top_items       = array_slice($scored_items, 0, 30);
        $existing_titles = array();
        $landing_pages   = array();
        $related_posts   = array();

        foreach ($top_items as $entry) {
            $obj               = $entry['item'];
            $existing_titles[] = '"' . $obj->post_title . '"';

            $link_info = array(
                'title' => $obj->post_title,
                'url'   => get_permalink($obj->ID),
            );

            if ($entry['is_landing_page']) {
                $landing_pages[] = $link_info;
            } else {
                $related_posts[] = $link_info;
            }
        }

        return array(
            'existing_titles_str'  => !empty($existing_titles) ? implode(', ', $existing_titles) : 'Chưa có bài viết nào khác.',
            'landing_pages_json'   => !empty($landing_pages) ? wp_json_encode(array_slice($landing_pages, 0, 5), JSON_UNESCAPED_UNICODE) : '[]',
            'related_posts_json'   => !empty($related_posts) ? wp_json_encode(array_slice($related_posts, 0, 15), JSON_UNESCAPED_UNICODE) : '[]',
        );
    }

    /**
     * Get the standard CTA box HTML for AI prompts.
     *
     * @param string $keyword The focus keyword.
     * @return string
     */
    private function get_cta_box_prompt($keyword)
    {
        return "  <div style='background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color: #fff; padding: 30px; border-radius: 12px; text-align: center; margin: 40px 0; box-shadow: 0 10px 25px rgba(0,0,0,0.15);'>\n" .
            "    <h3 style='color: #38bdf8; margin-top: 0; font-size: 22px;'>Bạn Cần Tư Vấn Chuyên Sâu Về " . esc_attr($keyword) . "?</h3>\n" .
            "    <p style='color: #cbd5e1; font-size: 15.5px; line-height: 1.6; margin-bottom: 20px;'>Đừng ngần ngại liên hệ ngay với CyberServices để nhận tư vấn chi tiết, báo giá ưu đãi và giải pháp tối ưu nhất!</p>\n" .
            "    <div style='display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; align-items: center;'>\n" .
            "      <a href='https://cyberservices.vn/lien-he/' target='_blank' rel='noopener noreferrer' style='display: inline-block; background: #0284c7; color: #fff; padding: 12px 22px; border-radius: 8px; font-weight: bold; text-decoration: none;'>Liên Hệ Tư Vấn Ngay</a>\n" .
            "      <a href='https://zalo.me/0979875985' target='_blank' rel='noopener noreferrer' style='display: inline-block; background: #0068ff; color: #fff; padding: 12px 22px; border-radius: 8px; font-weight: bold; text-decoration: none;'>💬 Chat Zalo: 0979.875.985</a>\n" .
            "      <a href='tel:0979875985' style='display: inline-block; background: #16a34a; color: #fff; padding: 12px 22px; border-radius: 8px; font-weight: bold; text-decoration: none;'>📞 Hotline: 0979.875.985</a>\n" .
            "    </div>\n" .
            "  </div>\n";
    }

    /**
     * Insert images into post content after h2 tags.
     *
     * @param string $content     The post content HTML.
     * @param int    $attach_id_1 Attachment ID for image 1.
     * @param int    $attach_id_2 Attachment ID for image 2.
     * @param string $keyword     The focus keyword for alt text.
     * @return string Modified content.
     */
    private function insert_images_into_content($content, $attach_id_1, $attach_id_2, $keyword)
    {
        $parts       = explode('</h2>', $content);
        $new_content = '';

        if (count($parts) > 1) {
            foreach ($parts as $index => $part) {
                $new_content .= $part;
                if ($index < count($parts) - 1) {
                    $new_content .= '</h2>';
                }
                if ($index === 0 && $attach_id_1) {
                    $img_url_1    = wp_get_attachment_url($attach_id_1);
                    $new_content .= "\n\n<figure class='wp-block-image size-large' style='text-align:center; margin: 25px 0;'><img src='" . esc_url($img_url_1) . "' alt='" . esc_attr($keyword) . " - Ảnh 1' style='border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); width:100%; height:auto;' /></figure>\n\n";
                }
                if (($index === 2 || (count($parts) == 3 && $index === 1)) && $attach_id_2) {
                    $img_url_2    = wp_get_attachment_url($attach_id_2);
                    $new_content .= "\n\n<figure class='wp-block-image size-large' style='text-align:center; margin: 25px 0;'><img src='" . esc_url($img_url_2) . "' alt='" . esc_attr($keyword) . " - Ảnh 2' style='border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); width:100%; height:auto;' /></figure>\n\n";
                }
            }
            return $new_content;
        }

        return $content;
    }

    public function ajax_generate_post_text()
    {
        check_ajax_referer('kira_ai_generate_nonce');

        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Bạn không có quyền thực hiện tác vụ này.');
        }

        $api_key = get_option('kira_ai_api_key', '');
        if (empty($api_key)) {
            wp_send_json_error('Vui lòng cấu hình API Key trong mục Kira AI trước khi sử dụng.');
        }

        $post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : 'post';
        $keyword = isset($_POST['keyword']) ? sanitize_text_field($_POST['keyword']) : '';
        $prompt = isset($_POST['prompt']) ? sanitize_textarea_field($_POST['prompt']) : '';
        $post_status = isset($_POST['post_status']) ? sanitize_text_field($_POST['post_status']) : 'draft';
        $scheduled_time = isset($_POST['scheduled_time']) ? sanitize_text_field($_POST['scheduled_time']) : '';

        if (empty($keyword)) {
            wp_send_json_error('Vui lòng điền từ khóa chính.');
        }

        if (empty($prompt)) {
            $prompt = 'Viết bài viết chi tiết, chuyên sâu, phân tích toàn diện chuẩn SEO về chủ đề: ' . $keyword;
        }

        $text_model = get_option('kira_ai_text_model', 'kira-3.5-flash');
        $base_url = 'https://kiraai.vn';

        $link_context = $this->build_internal_link_context($keyword);
        $existing_titles_str = $link_context['existing_titles_str'];
        $landing_pages_json  = $link_context['landing_pages_json'];
        $related_posts_json  = $link_context['related_posts_json'];

        $system_msg = 'Bạn là một Chuyên gia SEO Master, một Copywriter thực chiến xuất sắc. Nhiệm vụ của bạn là tạo ra một bài viết chuẩn SEO Top 1 Google, mang lại giá trị thực tế cao nhất cho độc giả. Bạn luôn tuân thủ tuyệt đối các quy tắc định dạng và trả về kết quả JSON chuẩn.';

        $ai_prompt = "Nhiệm vụ của bạn là viết một bài viết hoàn toàn bằng tiếng Việt, chuẩn SEO Top 1 Google, bám sát các nguyên tắc sau:\n\n" .
            "1. THÔNG TIN CỐT LÕI & ĐỘ DÀI:\n" .
            "- Từ khóa chính: {$keyword}\n" .
            "- Yêu cầu chủ đề: {$prompt}\n" .
            "- ĐỘ DÀI MỤC TIÊU BẮT BUỘC: Bài viết phải RẤT DÀI, chuyên sâu, TỐI THIỂU TỪ 1800 ĐẾN 2200 TỪ.\n\n" .

            "2. CHIẾN LƯỢC INTERNAL LINK & ĐẨY SEO LANDING PAGE:\n" .
            "- Website ĐÃ CÓ các bài viết sau: [{$existing_titles_str}]. KHÔNG lặp lại nội dung đã viết.\n" .
            "- DANH SÁCH LANDING PAGE MỤC TIÊU (Ưu tiên số 1 để trỏ link đẩy SEO): {$landing_pages_json}\n" .
            "- DANH SÁCH BÀI VIẾT BỔ TRỢ LIÊN QUAN: {$related_posts_json}\n" .
            "- NGUYÊN TẮC ĐI LINK:\n" .
            "  + BẮT BUỘC chèn ít nhất 1-2 liên kết trỏ về LANDING PAGE mục tiêu có ngữ cảnh phù hợp nhất để đẩy sức mạnh SEO.\n" .
            "  + Chèn thêm 1-2 liên kết bổ trợ sang các bài viết liên quan.\n" .
            "  + Định dạng link: <a href='URL' target='_blank' title='Title'>Anchor Text tự nhiên, chứa từ khóa</a>.\n\n" .

            "3. QUY TẮC MỞ BÀI (SAPO):\n" .
            "- CÚ PHÁP BẮT BUỘC: Những từ đầu tiên của bài viết PHẢI chứa chính xác cụm từ khóa [{$keyword}] trực diện.\n\n" .

            "4. YÊU CẦU BỐ CỤC HTML & UI/UX ĐẶC BIỆT:\n" .
            "- Phân cấp thẻ <h2>, <h3> logic, rõ ràng. TUYỆT ĐỐI KHÔNG dùng <h1> trong thân bài.\n" .
            "- BẮT BUỘC có ít nhất 1 Bảng biểu (<table>) so sánh hoặc tóm tắt dữ liệu có Inline CSS đẹp mắt.\n" .
            "- BẮT BUỘC tạo các Box Callout 'Tóm tắt ý chính / Lời khuyên' nổi bật ở cuối mỗi phần quan trọng.\n" .
            "- Có mục FAQ (Câu hỏi thường gặp) với định dạng 3-5 câu hỏi đáp ngắn gọn ở gần cuối bài.\n\n" .

            "5. KHỐI KÊU GỌI HÀNH ĐỘNG & LIÊN HỆ (CTA BOX - BẮT BUỘC Ở CUỐI BÀI):\n" .
            "- BẮT BUỘC chèn chính xác Box CTA liên hệ/tư vấn chuẩn sau ở cuối bài:\n" .
            $this->get_cta_box_prompt($keyword) . "\n" .

            "6. KỶ LUẬT ĐỊNH DẠNG ĐẦU RA JSON:\n" .
            "- CHỈ SỬ DỤNG HTML THUẦN trong content. Dùng dấu nháy đơn (') cho thuộc tính HTML bên trong chuỗi.\n" .
            "- Trả về duy nhất cú pháp JSON chuẩn với các key:\n" .
            "  + \"title\": Tiêu đề hấp dẫn, chuẩn SEO (50-70 ký tự).\n" .
            "  + \"content\": Toàn bộ nội dung bài viết dạng HTML thuần (bắt buộc dài từ 1800 đến 2200 từ, đầy đủ Table, Box tóm tắt, FAQ, CTA Box).\n" .
            "  + \"seo_title\": Meta Title tối ưu CTR và công cụ tìm kiếm.\n" .
            "  + \"seo_description\": Meta Description 130-160 ký tự cuốn hút, tối ưu Rank Math/Yoast SEO.";

        $log_entry = array(
            'time' => current_time('Y-m-d H:i:s'),
            'post_type' => $post_type,
            'keyword' => $keyword,
            'prompt' => $prompt,
            'model' => $text_model,
            'status' => 'pending',
            'input_full' => "System message: " . $system_msg . "\n\nUser prompt:\n" . $ai_prompt,
            'output' => '',
            'error' => ''
        );

        $additional_args = array(
            'response_format' => array('type' => 'json_object')
        );
        $response = $this->call_kira_api($ai_prompt, $system_msg, $api_key, $text_model, $base_url, $additional_args);

        if (is_wp_error($response)) {
            $log_entry['status'] = 'error';
            $log_entry['error'] = $response->get_error_message();
            $this->add_api_log($log_entry);
            wp_send_json_error('Kira AI API Error: ' . $response->get_error_message());
        }

        $data = $this->clean_and_decode_json($response);
        if (!$data || empty($data['title']) || empty($data['content'])) {
            $log_entry['status'] = 'error';
            $log_entry['output'] = $response;
            $log_entry['error'] = 'AI returned invalid JSON format.';
            $this->add_api_log($log_entry);
            wp_send_json_error('Lỗi: AI trả về định dạng không đúng chuẩn JSON yêu cầu.');
        }

        $final_post_status = in_array($post_status, array('publish', 'draft', 'future')) ? $post_status : 'draft';

        $post_data = array(
            'post_title' => sanitize_text_field($data['title']),
            'post_content' => wp_kses_post($data['content']),
            'post_status' => $final_post_status,
            'post_type' => $post_type,
            'post_author' => get_current_user_id()
        );

        // Xử lý lên lịch xuất bản trong tương lai (Scheduled Publishing)
        if ($final_post_status === 'future' && !empty($scheduled_time)) {
            $timestamp = strtotime($scheduled_time);
            if ($timestamp && $timestamp > current_time('timestamp', 0)) {
                $post_data['post_date'] = wp_date('Y-m-d H:i:s', $timestamp);
                $post_data['post_date_gmt'] = get_gmt_from_date($post_data['post_date']);
                $post_data['edit_date'] = true;
            } else {
                $post_data['post_status'] = 'publish';
            }
        }

        $post_id = wp_insert_post($post_data);

        if (is_wp_error($post_id) || !$post_id) {
            $log_entry['status'] = 'error';
            $log_entry['output'] = $response;
            $log_entry['error'] = 'Could not create post in database.';
            $this->add_api_log($log_entry);
            wp_send_json_error('Không thể tạo bài viết trong cơ sở dữ liệu.');
        }

        $seo_title = !empty($data['seo_title']) ? sanitize_text_field($data['seo_title']) : sanitize_text_field($data['title']);
        $seo_desc = !empty($data['seo_description']) ? sanitize_text_field($data['seo_description']) : '';

        update_post_meta($post_id, 'rank_math_focus_keyword', $keyword);
        update_post_meta($post_id, 'rank_math_title', $seo_title);
        update_post_meta($post_id, 'rank_math_description', $seo_desc);

        update_post_meta($post_id, '_yoast_wpseo_focuskw', $keyword);
        update_post_meta($post_id, '_yoast_wpseo_title', $seo_title);
        update_post_meta($post_id, '_yoast_wpseo_metadesc', $seo_desc);

        $log_entry['status'] = 'success';
        $log_entry['output'] = $response;
        $this->add_api_log($log_entry);

        wp_send_json_success(array(
            'post_id' => $post_id,
            'title' => $data['title'],
            'status' => $post_data['post_status'],
            'scheduled_date' => !empty($post_data['post_date']) ? $post_data['post_date'] : '',
            'edit_url' => admin_url('post.php?post=' . $post_id . '&action=edit'),
            'view_url' => get_permalink($post_id)
        ));
    }

    public function ajax_generate_post_image()
    {
        check_ajax_referer('kira_ai_generate_nonce');

        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Bạn không có quyền thực hiện tác vụ này.');
        }

        $api_key = get_option('kira_ai_api_key', '');
        if (empty($api_key)) {
            wp_send_json_error('Vui lòng cấu hình API Key.');
        }

        $post_id = isset($_POST['post_id']) ? (int) $_POST['post_id'] : 0;
        $title = isset($_POST['title']) ? sanitize_text_field($_POST['title']) : '';

        if (!$post_id || empty($title)) {
            wp_send_json_error('Thiếu thông tin ID bài viết hoặc tiêu đề để vẽ ảnh.');
        }

        $keyword = get_post_meta($post_id, 'rank_math_focus_keyword', true);
        if (empty($keyword)) $keyword = get_post_meta($post_id, '_yoast_wpseo_focuskw', true);
        if (empty($keyword)) $keyword = $title;

        $image_model = get_option('kira_ai_image_model', 'kira-2.5-flash-image');
        $base_url = 'https://kiraai.vn';

        // 1. Ảnh đại diện Feature Image
        $feat_prompt = $this->build_realistic_photo_prompt("chủ đề: " . $title . ". Bố cục đẹp mắt, bối cảnh thực tế, ánh sáng ban ngày tự nhiên");
        $feat_response = $this->call_kira_image_api($feat_prompt, $api_key, $image_model, $base_url);
        
        if (!is_wp_error($feat_response)) {
            $feat_attach_id = $this->save_base64_image_as_webp_attachment($feat_response['b64_json'], $post_id, $title, $keyword . ' - Ảnh đại diện');
            if ($feat_attach_id) {
                set_post_thumbnail($post_id, $feat_attach_id);
            }
        }

        // 2. Ảnh thân bài 1 & 2
        $img1_prompt = $this->build_realistic_photo_prompt("góc nhìn toàn cảnh, phong cảnh bối cảnh thực tế sống động cho nội dung: " . $title);
        $img2_prompt = $this->build_realistic_photo_prompt("góc chụp cận cảnh, chi tiết chân thực, ánh sáng studio/đời thực cho chủ đề: " . $title);
        
        $attach_id_1 = 0;
        $attach_id_2 = 0;

        $img1_response = $this->call_kira_image_api($img1_prompt, $api_key, $image_model, $base_url);
        if (!is_wp_error($img1_response)) {
            $attach_id_1 = $this->save_base64_image_as_webp_attachment($img1_response['b64_json'], $post_id, $title . ' phần 1', $keyword . ' - Chi tiết 1');
        }

        $img2_response = $this->call_kira_image_api($img2_prompt, $api_key, $image_model, $base_url);
        if (!is_wp_error($img2_response)) {
            $attach_id_2 = $this->save_base64_image_as_webp_attachment($img2_response['b64_json'], $post_id, $title . ' phần 2', $keyword . ' - Chi tiết 2');
        }

        $content = get_post_field('post_content', $post_id);
        $new_content = $this->insert_images_into_content($content, $attach_id_1, $attach_id_2, $keyword);

        if ($new_content !== $content) {
            wp_update_post(array(
                'ID' => $post_id,
                'post_content' => $new_content
            ));
        }

        wp_send_json_success(array(
            'redirect_url' => admin_url('post.php?post=' . $post_id . '&action=edit'),
            'post_id' => $post_id
        ));
    }

    public function ajax_process_existing_post()
    {
        check_ajax_referer('kira_ai_generate_nonce');

        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Bạn không có quyền thực hiện tác vụ này.');
        }

        $api_key = get_option('kira_ai_api_key', '');
        if (empty($api_key)) {
            wp_send_json_error('Vui lòng cấu hình API Key.');
        }

        $post_id = isset($_POST['post_id']) ? (int) $_POST['post_id'] : 0;
        $action_type = isset($_POST['action_type']) ? sanitize_text_field($_POST['action_type']) : '';
        $custom_prompt = isset($_POST['custom_prompt']) ? sanitize_textarea_field($_POST['custom_prompt']) : '';

        if (!$post_id) {
            wp_send_json_error('Thiếu ID bài viết.');
        }

        if (!current_user_can('edit_post', $post_id)) {
            wp_send_json_error('Bạn không có quyền chỉnh sửa bài viết này.');
        }

        $post = get_post($post_id);
        if (!$post) {
            wp_send_json_error('Bài viết không tồn tại.');
        }

        $title = $post->post_title;
        $content = wp_strip_all_tags($post->post_content);

        $text_model = get_option('kira_ai_text_model', 'kira-3.5-flash');
        $image_model = get_option('kira_ai_image_model', 'kira-2.5-flash-image');
        $base_url = 'https://kiraai.vn';

        if ($action_type === 'gen_image') {
            $desc = "bài viết: " . $title . (!empty($custom_prompt) ? " (" . $custom_prompt . ")" : "");
            $image_prompt = $this->build_realistic_photo_prompt($desc);

            $keyword = get_post_meta($post_id, 'rank_math_focus_keyword', true);
            if (empty($keyword)) {
                $keyword = get_post_meta($post_id, '_yoast_wpseo_focuskw', true);
            }
            if (empty($keyword)) {
                $keyword = $title;
            }

            $log_entry = array(
                'time' => current_time('Y-m-d H:i:s'),
                'post_type' => $post->post_type,
                'keyword' => 'Tạo ảnh đời thực có Logo: ' . $title,
                'prompt' => $image_prompt,
                'model' => $image_model,
                'status' => 'pending',
                'input_full' => "Image Generation Prompt: " . $image_prompt,
                'output' => '',
                'error' => ''
            );

            $image_response = $this->call_kira_image_api($image_prompt, $api_key, $image_model, $base_url);

            if (is_wp_error($image_response)) {
                $log_entry['status'] = 'error';
                $log_entry['error'] = $image_response->get_error_message();
                $this->add_api_log($log_entry);
                wp_send_json_error('Lỗi sinh ảnh AI: ' . $image_response->get_error_message());
            }

            $attach_id = $this->save_base64_image_as_webp_attachment(
                $image_response['b64_json'],
                $post_id,
                $title,
                $keyword . ' - Ảnh đại diện'
            );

            if ($attach_id) {
                set_post_thumbnail($post_id, $attach_id);
                $log_entry['status'] = 'success';
                $log_entry['output'] = "Đã tạo và gán ảnh đại diện WebP có Logo thành công. Attachment ID: " . $attach_id;
                $this->add_api_log($log_entry);
                wp_send_json_success('Tạo ảnh đại diện đời thực thành công.');
            } else {
                $log_entry['status'] = 'error';
                $log_entry['error'] = 'Không thể lưu ảnh WebP vào Media Library.';
                $this->add_api_log($log_entry);
                wp_send_json_error('Không thể lưu ảnh WebP vào Media Library.');
            }

        } elseif ($action_type === 'rewrite_title') {
            $system_msg = 'Bạn là một chuyên gia viết tiêu đề và tối ưu hóa SEO. Bạn luôn trả về duy nhất tiêu đề mới dưới dạng văn bản thuần túy.';

            $ai_prompt = "Hãy viết lại tiêu đề bài viết sau đây dựa trên tiêu đề cũ và nội dung bài viết. Tiêu đề mới phải hấp dẫn, cuốn hút người đọc và tối ưu hóa chuẩn SEO.\n\n" .
                "Tiêu đề cũ: {$title}\n\n" .
                "Tóm tắt nội dung bài viết:\n" . wp_html_excerpt($content, 400) . "\n\n";

            if (!empty($custom_prompt)) {
                $ai_prompt .= "Yêu cầu bổ sung của người dùng: {$custom_prompt}\n\n";
            }

            $ai_prompt .= "Lưu ý quan trọng: Chỉ trả về tiêu đề mới dạng văn bản thuần túy (không ngoặc kép, không giải thích).";

            $log_entry = array(
                'time' => current_time('Y-m-d H:i:s'),
                'post_type' => $post->post_type,
                'keyword' => 'Viết lại Title: ' . $title,
                'prompt' => $custom_prompt,
                'model' => $text_model,
                'status' => 'pending',
                'input_full' => "System message: " . $system_msg . "\n\nUser prompt:\n" . $ai_prompt,
                'output' => '',
                'error' => ''
            );

            $response = $this->call_kira_api($ai_prompt, $system_msg, $api_key, $text_model, $base_url);

            if (is_wp_error($response)) {
                $log_entry['status'] = 'error';
                $log_entry['error'] = $response->get_error_message();
                $this->add_api_log($log_entry);
                wp_send_json_error('Kira AI API Error: ' . $response->get_error_message());
            }

            $new_title = trim($response);
            $new_title = trim($new_title, '"\'');

            $updated = wp_update_post(array(
                'ID' => $post_id,
                'post_title' => sanitize_text_field($new_title)
            ));

            if (is_wp_error($updated) || !$updated) {
                $log_entry['status'] = 'error';
                $log_entry['error'] = 'Could not update post title in database.';
                $this->add_api_log($log_entry);
                wp_send_json_error('Không thể cập nhật tiêu đề mới.');
            }

            $log_entry['status'] = 'success';
            $log_entry['output'] = $new_title;
            $this->add_api_log($log_entry);

            wp_send_json_success('Viết lại tiêu đề thành công.');

        } elseif ($action_type === 'rewrite_content') {
            $system_msg = 'Bạn là một Chuyên gia SEO Master, một Copywriter thực chiến xuất sắc. Nhiệm vụ của bạn là tối ưu và viết lại bài viết chuẩn SEO Top 1 Google. Bạn luôn tuân thủ tuyệt đối các quy tắc định dạng và trả về kết quả JSON chuẩn.';

            $keyword = get_post_meta($post_id, 'rank_math_focus_keyword', true);
            if (empty($keyword)) {
                $keyword = get_post_meta($post_id, '_yoast_wpseo_focuskw', true);
            }
            if (empty($keyword)) {
                $keyword = $title;
            }

            $link_context = $this->build_internal_link_context($keyword, $post_id);
            $existing_titles_str = $link_context['existing_titles_str'];
            $landing_pages_json  = $link_context['landing_pages_json'];
            $related_posts_json  = $link_context['related_posts_json'];

            $ai_prompt = "Nhiệm vụ của bạn là VIẾT LẠI và tối ưu toàn diện bài viết bằng tiếng Việt, chuẩn SEO Top 1 Google:\n\n" .
                "Tiêu đề cũ: {$title}\n\n" .
                "Nội dung cũ cần viết lại:\n" . wp_html_excerpt($post->post_content, 15000) . "\n\n" .
                "1. THÔNG TIN CỐT LÕI & ĐỘ DÀI:\n" .
                "- Từ khóa chính: {$keyword}\n" .
                "- Yêu cầu chỉnh sửa thêm: {$custom_prompt}\n" .
                "- ĐỘ DÀI MỤC TIÊU BẮT BUỘC: Bài viết sau khi viết lại phải RẤT DÀI, chuyên sâu, TỐI THIỂU TỪ 1800 ĐẾN 2200 TỪ.\n\n" .
                
                "2. CHIẾN LƯỢC INTERNAL LINK:\n" .
                "- Website ĐÃ CÓ các bài viết sau: [{$existing_titles_str}].\n" .
                "- DANH SÁCH LANDING PAGE MỤC TIÊU: {$landing_pages_json}\n" .
                "- DANH SÁCH BÀI VIẾT BỔ TRỢ: {$related_posts_json}\n" .
                "- BẮT BUỘC chèn ít nhất 1-2 liên kết trỏ về LANDING PAGE mục tiêu và 1-2 link bài viết liên quan.\n\n" .
                
                "3. QUY TẮC MỞ BÀI (SAPO):\n" .
                "- Những từ đầu tiên của bài viết PHẢI chứa chính xác từ khóa [{$keyword}].\n\n" .
                
                "4. YÊU CẦU BỐ CỤC:\n" .
                "- Phân cấp thẻ <h2>, <h3> logic. KHÔNG dùng <h1> trong thân bài.\n" .
                "- BẮT BUỘC có ít nhất 1 Bảng biểu (<table>) và các Box Callout tóm tắt ý chính.\n" .
                "- Có mục FAQ (3-5 câu hỏi đáp ngắn gọn) ở gần cuối bài.\n\n" .
                
                "5. KHỐI KÊU GỌI HÀNH ĐỘNG & LIÊN HỆ (CTA BOX - BẮT BUỘC Ở CUỐI BÀI):\n" .
                "- BẮT BUỘC chèn chính xác khối CTA sau:\n" .
                $this->get_cta_box_prompt($keyword) . "\n" .
                
                "6. KỶ LUẬT ĐỊNH DẠNG ĐẦU RA JSON:\n" .
                "- Trả về JSON chuẩn với các key: \"title\", \"content\" (HTML thuần 1800-2200 từ), \"seo_title\", \"seo_description\".";

            $log_entry = array(
                'time'       => current_time('Y-m-d H:i:s'),
                'post_type'  => $post->post_type,
                'keyword'    => 'Viết lại & Tối ưu chuẩn SEO: ' . $title,
                'prompt'     => $custom_prompt,
                'model'      => $text_model,
                'status'     => 'pending',
                'input_full' => "System message: " . $system_msg . "\n\nUser prompt:\n" . $ai_prompt,
                'output'     => '',
                'error'      => ''
            );

            $additional_args = array(
                'response_format' => array('type' => 'json_object')
            );
            $response = $this->call_kira_api($ai_prompt, $system_msg, $api_key, $text_model, $base_url, $additional_args);

            if (is_wp_error($response)) {
                $log_entry['status'] = 'error';
                $log_entry['error'] = $response->get_error_message();
                $this->add_api_log($log_entry);
                wp_send_json_error('Kira AI API Error: ' . $response->get_error_message());
            }

            $data = $this->clean_and_decode_json($response);
            if (!$data || empty($data['content'])) {
                $log_entry['status'] = 'error';
                $log_entry['error'] = 'AI returned empty or invalid JSON format.';
                $this->add_api_log($log_entry);
                wp_send_json_error('Lỗi: AI trả về định dạng không đúng chuẩn JSON.');
            }

            $new_post_title = !empty($data['title']) ? sanitize_text_field($data['title']) : $title;
            $new_post_content = wp_kses_post($data['content']);

            $image_model = get_option('kira_ai_image_model', 'kira-2.5-flash-image');

            $feat_prompt = $this->build_realistic_photo_prompt("chủ đề: " . $new_post_title . ". Ánh sáng tự nhiên chân thực, bố cục hài hòa");
            $feat_response = $this->call_kira_image_api($feat_prompt, $api_key, $image_model, $base_url);
            if (!is_wp_error($feat_response)) {
                $feat_attach_id = $this->save_base64_image_as_webp_attachment($feat_response['b64_json'], $post_id, $new_post_title, $keyword . ' - Ảnh đại diện');
                if ($feat_attach_id) {
                    set_post_thumbnail($post_id, $feat_attach_id);
                }
            }

            $img1_prompt = $this->build_realistic_photo_prompt("bối cảnh rộng thực tế về: " . $new_post_title);
            $img2_prompt = $this->build_realistic_photo_prompt("góc chụp chi tiết thực tế về: " . $new_post_title);
            
            $attach_id_1 = 0;
            $attach_id_2 = 0;

            $img1_response = $this->call_kira_image_api($img1_prompt, $api_key, $image_model, $base_url);
            if (!is_wp_error($img1_response)) {
                $attach_id_1 = $this->save_base64_image_as_webp_attachment($img1_response['b64_json'], $post_id, $new_post_title . ' phần 1', $keyword . ' - Chi tiết 1');
            }

            $img2_response = $this->call_kira_image_api($img2_prompt, $api_key, $image_model, $base_url);
            if (!is_wp_error($img2_response)) {
                $attach_id_2 = $this->save_base64_image_as_webp_attachment($img2_response['b64_json'], $post_id, $new_post_title . ' phần 2', $keyword . ' - Chi tiết 2');
            }

            $final_content = $this->insert_images_into_content($new_post_content, $attach_id_1, $attach_id_2, $keyword);

            $updated = wp_update_post(array(
                'ID'           => $post_id,
                'post_title'   => $new_post_title,
                'post_content' => $final_content
            ));

            if (is_wp_error($updated) || !$updated) {
                $log_entry['status'] = 'error';
                $log_entry['error'] = 'Could not update post content in database.';
                $this->add_api_log($log_entry);
                wp_send_json_error('Không thể cập nhật nội dung mới.');
            }

            update_post_meta($post_id, 'rank_math_focus_keyword', $keyword);
            if (!empty($data['seo_title'])) {
                update_post_meta($post_id, 'rank_math_title', sanitize_text_field($data['seo_title']));
                update_post_meta($post_id, '_yoast_wpseo_title', sanitize_text_field($data['seo_title']));
            }
            if (!empty($data['seo_description'])) {
                update_post_meta($post_id, 'rank_math_description', sanitize_text_field($data['seo_description']));
                update_post_meta($post_id, '_yoast_wpseo_metadesc', sanitize_text_field($data['seo_description']));
            }

            $log_entry['status'] = 'success';
            $log_entry['output'] = "Viết lại thành công và chèn 3 ảnh đời thực có Logo cho bài ID: " . $post_id;
            $this->add_api_log($log_entry);

            wp_send_json_success('Viết lại nội dung, tạo 3 ảnh đời thực gắn Logo CyberServices thành công.');
        } else {
            wp_send_json_error('Hành động không hợp lệ.');
        }
    }

    public function ajax_process_existing_term()
    {
        check_ajax_referer('kira_ai_generate_nonce');

        if (!current_user_can('manage_categories')) {
            wp_send_json_error('Bạn không có quyền thực hiện tác vụ này.');
        }

        $api_key = get_option('kira_ai_api_key', '');
        if (empty($api_key)) {
            wp_send_json_error('Vui lòng cấu hình API Key.');
        }

        $term_id = isset($_POST['term_id']) ? (int) $_POST['term_id'] : 0;
        $taxonomy = isset($_POST['taxonomy']) ? sanitize_text_field($_POST['taxonomy']) : '';
        $action_type = isset($_POST['action_type']) ? sanitize_text_field($_POST['action_type']) : '';
        $custom_prompt = isset($_POST['custom_prompt']) ? sanitize_textarea_field($_POST['custom_prompt']) : '';

        if (!$term_id || empty($taxonomy)) {
            wp_send_json_error('Thiếu thông tin phân loại.');
        }

        $term = get_term($term_id, $taxonomy);
        if (!$term || is_wp_error($term)) {
            wp_send_json_error('Phân loại không tồn tại.');
        }

        $name = $term->name;
        $desc = $term->description;

        $text_model = get_option('kira_ai_text_model', 'kira-3.5-flash');
        $image_model = get_option('kira_ai_image_model', 'kira-2.5-flash-image');
        $base_url = 'https://kiraai.vn';

        if ($action_type === 'term_gen_image') {
            $desc_term = "danh mục hoặc địa điểm: " . $name . (!empty($desc) ? " - " . wp_strip_all_tags($desc) : "") . (!empty($custom_prompt) ? " - " . $custom_prompt : "");
            $image_prompt = $this->build_realistic_photo_prompt($desc_term);

            $log_entry = array(
                'time' => current_time('Y-m-d H:i:s'),
                'post_type' => 'taxonomy_' . $taxonomy,
                'keyword' => 'Tạo ảnh phân loại đời thực: ' . $name,
                'prompt' => $image_prompt,
                'model' => $image_model,
                'status' => 'pending',
                'input_full' => "Image Generation Prompt: " . $image_prompt,
                'output' => '',
                'error' => ''
            );

            $image_response = $this->call_kira_image_api($image_prompt, $api_key, $image_model, $base_url);

            if (is_wp_error($image_response)) {
                $log_entry['status'] = 'error';
                $log_entry['error'] = $image_response->get_error_message();
                $this->add_api_log($log_entry);
                wp_send_json_error('Lỗi sinh ảnh AI: ' . $image_response->get_error_message());
            }

            $attach_id = $this->save_base64_image_as_webp_attachment(
                $image_response['b64_json'],
                0,
                $name,
                $name
            );

            if ($attach_id) {
                if (function_exists('update_field')) {
                    update_field('term_image', $attach_id, 'term_' . $term_id);
                } else {
                    update_term_meta($term_id, 'term_image', $attach_id);
                }

                $log_entry['status'] = 'success';
                $log_entry['output'] = "Đã tạo ảnh đại diện phân loại WebP có Logo thành công ID: " . $attach_id;
                $this->add_api_log($log_entry);
                wp_send_json_success('Tạo ảnh đại diện thành công.');
            } else {
                $log_entry['status'] = 'error';
                $log_entry['error'] = 'Không thể giải mã và lưu trữ file ảnh vào Media Library.';
                $this->add_api_log($log_entry);
                wp_send_json_error('Không thể lưu ảnh vào Media Library.');
            }

        } elseif ($action_type === 'term_gen_desc') {
            $system_msg = 'Bạn là một chuyên gia biên tập nội dung chuẩn SEO. Bạn luôn trả về đoạn mô tả mới dưới dạng văn bản ngắn gọn, súc tích và hấp dẫn.';
            $ai_prompt = "Hãy viết một đoạn mô tả chi tiết khoảng 100-150 từ cho phân loại/danh mục có tên là: \"{$name}\". Chuẩn SEO, mạch lạc.\n\n";

            if (!empty($custom_prompt)) {
                $ai_prompt .= "Yêu cầu bổ sung: {$custom_prompt}\n\n";
            }

            $ai_prompt .= "Lưu ý quan trọng: Chỉ trả về đoạn văn bản thuần túy, không có tiêu đề, không bọc dấu ngoặc kép.";

            $log_entry = array(
                'time' => current_time('Y-m-d H:i:s'),
                'post_type' => 'taxonomy_' . $taxonomy,
                'keyword' => 'Tạo mô tả phân loại: ' . $name,
                'prompt' => $custom_prompt,
                'model' => $text_model,
                'status' => 'pending',
                'input_full' => "System message: " . $system_msg . "\n\nUser prompt:\n" . $ai_prompt,
                'output' => '',
                'error' => ''
            );

            $response = $this->call_kira_api($ai_prompt, $system_msg, $api_key, $text_model, $base_url);

            if (is_wp_error($response)) {
                $log_entry['status'] = 'error';
                $log_entry['error'] = $response->get_error_message();
                $this->add_api_log($log_entry);
                wp_send_json_error('Kira AI API Error: ' . $response->get_error_message());
            }

            $new_desc = trim($response);
            $new_desc = trim($new_desc, '"\'');

            $updated = wp_update_term($term_id, $taxonomy, array(
                'description' => sanitize_textarea_field($new_desc)
            ));

            if (is_wp_error($updated)) {
                $log_entry['status'] = 'error';
                $log_entry['error'] = $updated->get_error_message();
                $this->add_api_log($log_entry);
                wp_send_json_error('Không thể cập nhật mô tả mới.');
            }

            $log_entry['status'] = 'success';
            $log_entry['output'] = $new_desc;
            $this->add_api_log($log_entry);

            wp_send_json_success('Tạo mô tả phân loại thành công.');
        } else {
            wp_send_json_error('Hành động không hợp lệ.');
        }
    }

    public function ajax_generate_standalone_image()
    {
        check_ajax_referer('kira_ai_generate_nonce');

        if (!current_user_can('upload_files')) {
            wp_send_json_error('Bạn không có quyền tải tệp lên.');
        }

        $api_key = get_option('kira_ai_api_key', '');
        if (empty($api_key)) {
            wp_send_json_error('Vui lòng cấu hình API Key.');
        }

        $prompt = isset($_POST['prompt']) ? sanitize_textarea_field($_POST['prompt']) : '';
        $aspect_ratio = isset($_POST['aspect_ratio']) ? sanitize_text_field($_POST['aspect_ratio']) : '16:9';

        if (empty($prompt)) {
            wp_send_json_error('Vui lòng nhập yêu cầu vẽ ảnh.');
        }

        $image_model = get_option('kira_ai_image_model', 'kira-2.5-flash-image');
        $base_url = 'https://kiraai.vn';

        $image_prompt = $this->build_realistic_photo_prompt($prompt);

        $log_entry = array(
            'time' => current_time('Y-m-d H:i:s'),
            'post_type' => 'attachment',
            'keyword' => 'Sinh ảnh thực tế (' . $aspect_ratio . '): ' . wp_html_excerpt($prompt, 50),
            'prompt' => $image_prompt,
            'model' => $image_model,
            'status' => 'pending',
            'input_full' => "Image Generation Prompt: " . $image_prompt . " (Aspect Ratio: " . $aspect_ratio . ")",
            'output' => '',
            'error' => ''
        );

        $image_response = $this->call_kira_image_api($image_prompt, $api_key, $image_model, $base_url, $aspect_ratio);

        if (is_wp_error($image_response)) {
            $log_entry['status'] = 'error';
            $log_entry['error'] = $image_response->get_error_message();
            $this->add_api_log($log_entry);
            wp_send_json_error('Lỗi sinh ảnh AI: ' . $image_response->get_error_message());
        }

        $attach_id = $this->save_base64_image_as_webp_attachment(
            $image_response['b64_json'],
            0,
            $prompt,
            $prompt
        );

        if ($attach_id) {
            $log_entry['status'] = 'success';
            $log_entry['output'] = "Đã sinh ảnh tự do thành công có chèn Logo CyberServices. Attachment ID: " . $attach_id;
            $this->add_api_log($log_entry);
            wp_send_json_success('Tạo ảnh thành công.');
        } else {
            $log_entry['status'] = 'error';
            $log_entry['error'] = 'Không thể giải mã và lưu trữ file ảnh vào Media Library.';
            $this->add_api_log($log_entry);
            wp_send_json_error('Không thể lưu ảnh vào Media Library.');
        }
    }

    private function call_kira_image_api($prompt, $api_key, $model, $base_url, $aspect_ratio = '16:9')
    {
        $endpoint = rtrim($base_url, '/') . '/api/v1/images/generations';

        $payload = array(
            'prompt' => $prompt,
            'model' => $model,
            'aspect_ratio' => $aspect_ratio
        );

        $max_retries = 2;
        $last_error  = null;

        for ($attempt = 0; $attempt <= $max_retries; $attempt++) {
            $response = wp_remote_post($endpoint, array(
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $api_key
                ),
                'body' => wp_json_encode($payload),
                'timeout' => 90
            ));

            if (is_wp_error($response)) {
                $last_error = $response;
                if ($attempt < $max_retries) {
                    usleep(500000 * ($attempt + 1));
                }
                continue;
            }

            $body         = wp_remote_retrieve_body($response);
            $response_code = wp_remote_retrieve_response_code($response);
            $data         = json_decode($body, true);

            // Retry on server errors (5xx)
            if ($response_code >= 500 && $attempt < $max_retries) {
                usleep(500000 * ($attempt + 1));
                continue;
            }

            if ($response_code !== 200) {
                $err_msg = 'Máy chủ phản hồi mã lỗi HTTP: ' . $response_code;
                if (isset($data['error'])) {
                    $err = $data['error'];
                    $err_msg = is_array($err) ? ($err['message'] ?? $err_msg) : (string) $err;
                }
                return new WP_Error('kira_ai_image_error', $err_msg);
            }

            if (isset($data['error'])) {
                $err     = $data['error'];
                $err_msg = is_array($err) ? ($err['message'] ?? 'Lỗi không xác định khi sinh ảnh.') : (string) $err;
                return new WP_Error('kira_ai_image_error', $err_msg);
            }

            $image_info = $data['data'][0] ?? null;
            if (!$image_info || empty($image_info['b64_json'])) {
                return new WP_Error('kira_ai_image_empty', 'Không nhận được dữ liệu ảnh từ API.');
            }

            return $image_info;
        }

        if ($last_error) {
            return $last_error;
        }

        return new WP_Error('kira_ai_image_error', 'Lỗi không xác định khi gọi API sinh ảnh Kira AI.');
    }

    private function apply_cyberservices_logo(&$main_image)
    {
        if (!$main_image || !function_exists('imagecopyresampled')) {
            return;
        }

        $logo_url = self::LOGO_URL;
        $logo_transient_key = 'kira_ai_cs_logo_cache';
        $logo_data = get_transient($logo_transient_key);

        if (!$logo_data) {
            $response = wp_remote_get($logo_url, array('timeout' => 10));
            if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                $logo_data = wp_remote_retrieve_body($response);
                set_transient($logo_transient_key, $logo_data, 7 * DAY_IN_SECONDS);
            }
        }

        if (empty($logo_data)) {
            return;
        }

        $logo_resource = @imagecreatefromstring($logo_data);
        if (!$logo_resource) {
            return;
        }

        $img_width = imagesx($main_image);
        $img_height = imagesy($main_image);

        $logo_w = imagesx($logo_resource);
        $logo_h = imagesy($logo_resource);

        $target_logo_w = (int) ($img_width * 0.18);
        if ($target_logo_w < 100) $target_logo_w = 100;
        if ($target_logo_w > $logo_w) $target_logo_w = $logo_w;

        $target_logo_h = (int) ($logo_h * ($target_logo_w / $logo_w));

        $margin_right = (int) ($img_width * 0.03);
        $margin_top = (int) ($img_height * 0.03);

        $dest_x = $img_width - $target_logo_w - $margin_right;
        $dest_y = $margin_top;

        imagealphablending($main_image, true);
        imagesavealpha($main_image, true);

        imagecopyresampled(
            $main_image,
            $logo_resource,
            $dest_x,
            $dest_y,
            0,
            0,
            $target_logo_w,
            $target_logo_h,
            $logo_w,
            $logo_h
        );

        imagedestroy($logo_resource);
    }

    private function save_base64_image_as_webp_attachment($b64_data, $post_id, $title, $alt_text = '')
    {
        if (preg_match('/^data:image\/(\w+);base64,/i', $b64_data, $type_matches)) {
            $b64_data = substr($b64_data, strpos($b64_data, ',') + 1);
        }

        $img_data = base64_decode($b64_data);
        if (!$img_data) {
            return false;
        }

        if (!function_exists('imagecreatefromstring') || !function_exists('imagewebp')) {
            error_log('Kira AI: Thư viện PHP GD không được bật trên server.');
            return false;
        }

        $image = @imagecreatefromstring($img_data);
        if (!$image) {
            return false;
        }

        $this->apply_cyberservices_logo($image);

        $safe_title = sanitize_file_name($title);
        $filename_title = wp_html_excerpt($safe_title, 50, '');
        if (empty($filename_title)) {
            $filename_title = 'kira-ai-image';
        }
        
        $filename = $filename_title . '-' . time() . '.webp';
        $upload_dir = wp_upload_dir();

        if (!file_exists($upload_dir['path'])) {
            wp_mkdir_p($upload_dir['path']);
        }

        $filepath = $upload_dir['path'] . '/' . $filename;
        
        if (!imagewebp($image, $filepath, 85)) {
            imagedestroy($image);
            return false;
        }
        imagedestroy($image);

        $attachment = array(
            'post_mime_type' => 'image/webp',
            'post_title'     => sanitize_text_field(wp_html_excerpt($title, 80, '...')),
            'post_content'   => sanitize_text_field($title), 
            'post_excerpt'   => sanitize_text_field($title), 
            'post_status'    => 'inherit'
        );

        $attach_id = wp_insert_attachment($attachment, $filepath, $post_id);
        if (!$attach_id || is_wp_error($attach_id)) {
            return false;
        }

        $final_alt = !empty($alt_text) ? $alt_text : $title;
        update_post_meta($attach_id, '_wp_attachment_image_alt', sanitize_text_field($final_alt));

        require_once ABSPATH . 'wp-admin/includes/image.php';
        $attach_data = wp_generate_attachment_metadata($attach_id, $filepath);
        wp_update_attachment_metadata($attach_id, $attach_data);

        return $attach_id;
    }

    private function call_kira_api($prompt, $system_msg, $api_key, $model, $base_url, $additional_args = array())
    {
        $endpoint = rtrim($base_url, '/') . '/api/v1/chat/completions';

        $messages = array();
        if (!empty($system_msg)) {
            $messages[] = array(
                'role' => 'system',
                'content' => $system_msg
            );
        }
        $messages[] = array(
            'role' => 'user',
            'content' => $prompt
        );

        $payload = array(
            'model' => $model,
            'messages' => $messages,
            'stream' => false,
            'temperature' => 0.7
        );

        if (!empty($additional_args)) {
            $payload = array_merge($payload, $additional_args);
        }

        $max_retries = 2;
        $last_error  = null;

        for ($attempt = 0; $attempt <= $max_retries; $attempt++) {
            $response = wp_remote_post($endpoint, array(
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $api_key
                ),
                'body' => wp_json_encode($payload),
                'timeout' => 120
            ));

            if (is_wp_error($response)) {
                $last_error = $response;
                if ($attempt < $max_retries) {
                    usleep(500000 * ($attempt + 1));
                }
                continue;
            }

            $response_code = wp_remote_retrieve_response_code($response);
            $body          = wp_remote_retrieve_body($response);

            if ($response_code === 200) {
                $data = json_decode($body, true);

                if (isset($data['error'])) {
                    return new WP_Error('kira_ai_error', $data['error']['message'] ?? 'Lỗi không xác định từ Kira AI.');
                }

                return $data['choices'][0]['message']['content'] ?? '';
            }

            // Retry on server errors (5xx)
            if ($response_code >= 500 && $attempt < $max_retries) {
                usleep(500000 * ($attempt + 1));
                continue;
            }

            $data    = json_decode($body, true);
            $err_msg = isset($data['error']['message']) ? $data['error']['message'] : '';
            if (empty($err_msg)) {
                $err_msg = 'Máy chủ phản hồi mã lỗi HTTP: ' . $response_code;
            }
            return new WP_Error('kira_ai_http_error', $err_msg);
        }

        if ($last_error) {
            return $last_error;
        }

        return new WP_Error('kira_ai_unknown_error', 'Lỗi không xác định khi gọi API Kira AI.');
    }

    private function clean_and_decode_json($raw_content)
    {
        $clean_content = trim($raw_content);

        if (preg_match('/```json\s*([\s\S]*?)\s*```/i', $clean_content, $matches)) {
            $clean_content = trim($matches[1]);
        } elseif (preg_match('/```\s*([\s\S]*?)\s*```/i', $clean_content, $matches)) {
            $clean_content = trim($matches[1]);
        }

        $first_brace = strpos($clean_content, '{');
        $last_brace = strrpos($clean_content, '}');
        if ($first_brace !== false && $last_brace !== false && $last_brace > $first_brace) {
            $clean_content = substr($clean_content, $first_brace, $last_brace - $first_brace + 1);
        }

        $decoded = json_decode($clean_content, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            return $decoded;
        }

        $escaped_content = preg_replace_callback(
            '/"([^"\\\\]|\\\\.)*"/',
            function ($matches) {
                return str_replace(
                    array("\r", "\n", "\t"),
                    array('', '\n', '\t'),
                    $matches[0]
                );
            },
            $clean_content
        );

        $decoded = json_decode($escaped_content, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            return $decoded;
        }

        error_log('Kira AI JSON Decode Failed: ' . json_last_error_msg() . ' | Raw Content: ' . $raw_content);

        return false;
    }

    public function ajax_test_connection()
    {
        check_ajax_referer('kira_ai_generate_nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Bạn không có quyền thực hiện tác vụ này.');
        }

        $api_key = isset($_POST['api_key']) ? sanitize_text_field($_POST['api_key']) : '';
        $text_model = isset($_POST['text_model']) ? sanitize_text_field($_POST['text_model']) : 'kira-3.5-flash';

        if (empty($api_key)) {
            wp_send_json_error('Vui lòng nhập API Key.');
        }

        $base_url = 'https://kiraai.vn';
        $test_prompt = 'Hãy trả về duy nhất chữ "OK" để xác nhận kết nối hoạt động.';
        $system_msg = 'Bạn là trợ lý hệ thống kiểm tra kết nối API.';

        $response = $this->call_kira_api($test_prompt, $system_msg, $api_key, $text_model, $base_url);

        if (is_wp_error($response)) {
            wp_send_json_error($response->get_error_message());
        }

        if (empty($response)) {
            wp_send_json_error('Kết nối thành công nhưng nhận được phản hồi trống từ API.');
        }

        wp_send_json_success();
    }

    public function ajax_sync_models()
    {
        check_ajax_referer('kira_ai_generate_nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Bạn không có quyền thực hiện tác vụ này.');
        }

        $models = $this->get_kira_models(true);
        wp_send_json_success($models);
    }

    public function get_kira_models($force_refresh = false)
    {
        $cache_key = 'kira_ai_models_cache';
        $models = $force_refresh ? false : get_transient($cache_key);

        if (false === $models) {
            $response = wp_remote_get('https://kiraai.vn/api/v1/models', array(
                'timeout' => 15
            ));

            if (!is_wp_error($response)) {
                $response_code = wp_remote_retrieve_response_code($response);
                $body = wp_remote_retrieve_body($response);

                if (200 === $response_code) {
                    $data = json_decode($body, true);
                    if (isset($data['data']) && is_array($data['data'])) {
                        $text_models = array();
                        $image_models = array();

                        foreach ($data['data'] as $model) {
                            if (isset($model['status']) && 'active' !== $model['status']) {
                                continue;
                            }

                            $model_id = $model['id'] ?? '';
                            $model_name = $model['name'] ?? $model_id;
                            $model_desc = $model['description'] ?? '';
                            $model_type = $model['type'] ?? '';

                            if (empty($model_id)) {
                                continue;
                            }

                            $model_entry = array(
                                'id' => $model_id,
                                'name' => $model_name,
                                'description' => $model_desc
                            );

                            if ('chat' === $model_type) {
                                $text_models[] = $model_entry;
                            } elseif ('image' === $model_type) {
                                $image_models[] = $model_entry;
                            }
                        }

                        if (!empty($text_models) || !empty($image_models)) {
                            $models = array(
                                'text_models' => $text_models,
                                'image_models' => $image_models
                            );
                            set_transient($cache_key, $models, DAY_IN_SECONDS);
                        }
                    }
                }
            }
        }

        if (empty($models)) {
            $models = array(
                'text_models' => array(
                    array('id' => 'kira-3.5-flash', 'name' => 'Kira 3.5 Flash', 'description' => 'Nhanh nhất, đề xuất'),
                    array('id' => 'kira-3-flash-preview', 'name' => 'kira-3-flash-preview', 'description' => 'Thử nghiệm tốc độ'),
                    array('id' => 'kira-2.5-flash', 'name' => 'kira-2.5-flash', 'description' => 'Model nhẹ, cơ bản'),
                    array('id' => 'kira-2.5-pro', 'name' => 'kira-2.5-pro', 'description' => 'Mạnh mẽ, lập luận logic cao'),
                ),
                'image_models' => array(
                    array('id' => 'kira-2.5-flash-image', 'name' => 'kira-2.5-flash-image', 'description' => 'Model sinh ảnh chân thực chất lượng cao'),
                    array('id' => 'kira-3.1-flash-image-preview', 'name' => 'kira-3.1-flash-image-preview', 'description' => 'Mới, chất lượng cao'),
                    array('id' => 'kira-3-pro-image-preview', 'name' => 'kira-3-pro-image-preview', 'description' => 'Chi tiết cao, sắc nét'),
                )
            );
        }

        return $models;
    }

    private function add_api_log($log_entry)
    {
        $logs = get_option('kira_ai_api_logs', array());
        if (!is_array($logs)) {
            $logs = array();
        }

        array_unshift($logs, $log_entry);

        if (count($logs) > 30) {
            $logs = array_slice($logs, 0, 30);
        }

        update_option('kira_ai_api_logs', $logs, false);
    }
}

function kira_ai_init()
{
    return Kira_AI::get_instance();
}
add_action('init', 'kira_ai_init');