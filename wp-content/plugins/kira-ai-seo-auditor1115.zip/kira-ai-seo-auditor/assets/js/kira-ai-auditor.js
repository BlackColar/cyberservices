/**
 * Kira AI - Competitor Outline & NLP Keyword Auditor (Live Sidebar)
 * 
 * Reads from the Gutenberg editor via wp.data (fallback to #content textarea
 * for the Classic Editor), tracks heading checklist & keyword density in realtime.
 */
jQuery(document).ready(function ($) {
    var params = window.kira_ai_auditor_params || {};
    if (!params || !params.ajax_url) {
        return;
    }

    // Mount points
    var $modal = $('#kira-auditor-modal');
    var $modalBody = $('#kira-auditor-modal-body');
    var $root = $('#kira-ai-auditor-root');
    var $launcher = $('#kira-ai-auditor-launcher');

    // PRIMARY: render into the meta box root (#kira-ai-auditor-root inside <details>).
    // The <details>/<summary> element handles open/close natively (no JS needed to expand).
    // MODAL: FAB also opens the full-size modal if present.
    var $panel = $root;
    if (!$panel.length) {
        return;
    }
    // Keep $root = $panel for all rendering functions
    $root = $panel;
    // NOTE: do NOT hide $root — browser controls visibility via <details>.
    // If modal missing, clicking the summary reveals this panel natively.

    var postId = parseInt($launcher.data('post-id'), 10) || parseInt(params.post_id, 10) || 0;
    var nonce = params.nonce;
    var hasApiKey = params.has_api_key || false;

    // Capture JS errors so the modal can show what went wrong
    window.onerror = function (msg, source, lineno) {
        var $err = $modalBody.find('.kira-auditor-js-error');
        if (!$err.length && $modalBody.length) {
            $modalBody.prepend('<div class="kira-auditor-js-error">⚠️ Lỗi JavaScript: ' + escapeHtml(String(msg).slice(0, 300)) + ' (dòng ' + (lineno || '?') + ')</div>');
        }
    };

    /**
     * Resolve the current post ID from the best available source:
     * Gutenberg store → #post_ID hidden field → localized params.
     */
    function resolvePostId() {
        var id = 0;
        if (window.wp && window.wp.data && wp.data.select('core/editor')) {
            try {
                var gId = wp.data.select('core/editor').getCurrentPostId();
                if (gId) {
                    id = parseInt(gId, 10);
                }
            } catch (e) { /* ignore */ }
        }
        if (!id) {
            var $field = $('#post_ID');
            if ($field.length) {
                id = parseInt($field.val(), 10) || 0;
            }
        }
        if (!id) {
            id = parseInt(params.post_id, 10) || 0;
        }
        return id;
    }

    /**
     * Push new content into the editor using the best available API:
     * Gutenberg store → TinyMCE instance → #content textarea.
     *
     * @param {string} content New HTML content.
     * @return {boolean} true if pushed successfully.
     */
    function pushContentToEditor(content) {
        // 1. Gutenberg
        if (window.wp && window.wp.data && wp.data.dispatch('core/editor')) {
            try {
                wp.data.dispatch('core/editor').editPost({ content: content });
                return true;
            } catch (e) { /* fall through */ }
        }

        // 2. Classic Editor with TinyMCE (Visual tab)
        var $textarea = $('#content');
        if (typeof window.tinymce !== 'undefined') {
            try {
                var ed = window.tinymce.get('content');
                if (ed) {
                    ed.setContent(content);
                    ed.save(); // sync back to textarea
                    return true;
                }
            } catch (e) { /* fall through */ }
        }

        // 3. Plain textarea (Classic Editor Text tab)
        if ($textarea.length) {
            $textarea.val(content).trigger('change');
            return true;
        }

        return false;
    }

    // Live data store (holds last fetched outline & keywords)
    var state = {
        hasData: false,
        title: '',
        outline: [],          // raw outline from AI
        outlineStatus: [],    // outline with met/partial/missing
        keywords: [],         // target keywords list
        keywordStatus: [],    // keywords with counts
        missingTopics: [],
        competitor: {},
        score: null,          // SEO score data
        focusKeyword: '',
        recommendedWordCount: 0,
        loading: false,
        activeTab: 'headings'
    };

    // ================= Utilities =================
    function escapeHtml(str) {
        if (!str) return '';
        return $('<div>').text(String(str)).html();
    }

    function debounce(fn, wait) {
        var t;
        return function () {
            var args = arguments, ctx = this;
            clearTimeout(t);
            t = setTimeout(function () {
                fn.apply(ctx, args);
            }, wait || 800);
        };
    }

    /**
     * Đổ HTML vào CẢ sidebar root lẫn modal body (nếu có) để hai nơi đồng bộ.
     */
    function fillPanels(containerClass, html) {
        var $rootC = $root.find(containerClass);
        if ($rootC.length) $rootC.html(html);
        if ($modalBody.length && $modalBody[0] !== $root[0]) {
            var $modalC = $modalBody.find(containerClass);
            if ($modalC.length) $modalC.html(html);
        }
    }

    /**
     * Tìm element: ưu tiên trong context (container chứa nút được bấm),
     * fallback sidebar root → modal body.
     * Tránh đọc nhầm textarea của sidebar khi người dùng nhập trong modal (và ngược lại).
     */
    function saFind(selector, context) {
        // 1. Ưu tiên context (không có 2 textarea giống nhau trong cùng container)
        if (context && context.length) {
            var $ctx = context.find(selector);
            if ($ctx.length) return $ctx;
        }
        // 2. Fallback sidebar root
        var $el = $root.find(selector);
        if (!$el.length) {
            // 3. Fallback modal body
            if ($modalBody.length && $modalBody[0] !== $root[0]) {
                $el = $modalBody.find(selector);
            }
        }
        return $el;
    }

    /**
     * Get current editor content:
     * - Gutenberg:      wp.data.select('core/editor').getEditedPostContent()
     * - Classic/TinyMCE: active editor instance → textarea fallback
     */
    function getEditorContent() {
        // 1. Gutenberg
        if (window.wp && window.wp.data && wp.data.select('core/editor')) {
            try {
                var content = wp.data.select('core/editor').getEditedPostContent();
                if (typeof content === 'string') {
                    return content;
                }
            } catch (e) { /* ignore */ }
        }

        // 2. Classic Editor with TinyMCE (Visual tab)
        if (typeof window.tinymce !== 'undefined') {
            try {
                var ed = window.tinymce.get('content');
                if (ed && !ed.isHidden()) {
                    var tinymceContent = ed.getContent();
                    if (typeof tinymceContent === 'string') {
                        return tinymceContent;
                    }
                }
            } catch (e) { /* ignore */ }
        }

        // 3. Plain textarea (#content / classic text tab)
        var $textarea = $('#content');
        if ($textarea.length) {
            return $textarea.val() || '';
        }
        return '';
    }

    // ================= AJAX Helpers =================
    function doAjax(action, data, onSuccess, onError) {
        data = data || {};
        data.action = action;
        data._ajax_nonce = nonce;
        // Resolve post id dynamically (important for new auto-draft posts)
        data.post_id = resolvePostId() || postId;

        $.ajax({
            url: params.ajax_url,
            type: 'POST',
            data: data,
            dataType: 'json',
            timeout: 180000,
            success: function (resp) {
                if (resp && resp.success) {
                    if (onSuccess) onSuccess(resp.data);
                } else {
                    var msg = (resp && resp.data) ? resp.data : 'Đã xảy ra lỗi không xác định.';
                    if (onError) onError(msg);
                }
            },
            error: function () {
                if (onError) onError('Không thể kết nối đến máy chủ. Vui lòng kiểm tra lại.');
            }
        });
    }

    // ================= Rendering =================
    function init() {
        if (!$root.length) return;
        // If no API key, show a notice
        if (!hasApiKey) {
            $root.html(
                '<div class="kira-auditor-box">' +
                '<div class="kira-auditor-error">⚠️ ' + escapeHtml(params.i18n.error_api_key) +
                ' <a href="' + (window.kira_ai_params ? kira_ai_params.admin_url + 'admin.php?page=kira-ai-settings' : '#') + '" target="_blank">Cấu hình ngay</a></div>' +
                '</div>'
            );
            return;
        }

        // Render the UI (into #kira-ai-auditor-root inside <details>)
        renderShell();

        // New auto-draft posts have no post ID yet — skip AJAX, just show setup UI.
        var currentPostId = resolvePostId() || postId;
        if (!currentPostId) {
            return;
        }

        // Load saved data
        doAjax('kira_sa_auditor_get_data', {}, function (data) {
            state.hasData = data.has_data;
            state.title = data.title || '';
            state.outline = data.outline || [];
            state.outlineStatus = data.outline_status || [];
            state.keywords = data.keywords || [];
            state.keywordStatus = data.keyword_status || [];
            state.missingTopics = data.missing_topics || [];
            state.competitor = data.competitor || {};
            state.focusKeyword = data.focus_keyword || '';
            state.recommendedWordCount = data.recommended_word_count || 0;

            // Show detected editor mode for clarity
            var editorMode = detectEditorMode();
            var $mode = $root.find('.kira-auditor-mode');
            if ($mode.length) {
                $mode.html(editorMode);
            }

            renderAll();

            // Start live polling of editor content
            startLiveMonitor();
        }, function (msg) {
            $root.find('.kira-auditor-error').remove();
            $root.find('.kira-auditor-setup').after('<div class="kira-auditor-error">' + escapeHtml(msg) + '</div>');
            renderShell();
        });
    }

    function renderShell() {
        var html = '';

        // ==== Guide bar ====
        html += '<div class="kira-auditor-guide">';
        html += '<div class="kira-auditor-guide-title">📖 Cách dùng</div>';
        html += '<ol class="kira-auditor-guide-list">' +
            '<li>Dán <strong>URL đối thủ</strong> xuống dưới → bấm <strong>Phân tích</strong></li>' +
            '<li>Bấm <strong>✨ Tạo dàn ý chuẩn SEO</strong></li>' +
            '<li><strong>Viết bài tại khung soạn thảo bên phải</strong> (phần lớn của trang)</li>' +
            '<li>Trở lại sidebar này: bấm <strong>+ Chèn nhanh</strong> để thêm heading vào bài (xuất hiện ngay cuối bài viết)</li>' +
            '<li>Badge Xanh/Vàng/Đỏ tự cập nhật khi bạn viết</li>' +
            '</ol>';
        html += '</div>';

        // ==== Setup section ====
        html += '<div class="kira-auditor-setup">';
        html += '<div class="kira-auditor-setup-title">🔍 Phân tích đối thủ & Tạo dàn ý</div>';

        html += '<div class="kira-auditor-mode"></div>';
        html += '<label class="kira-auditor-label">URL bài viết đối thủ <em style="color:#94a3b8;font-weight:400;">(mỗi dòng 1 URL, tối đa 5)</em></label>';
        html += '<div class="kira-auditor-url-row">';
        html += '<textarea class="kira-auditor-url" rows="2" placeholder="https://doithu1.com/bai-viet...&#10;https://doithu2.com/bai-viet..."></textarea>';
        html += '<button type="button" class="kira-auditor-btn kira-auditor-btn-ghost kira-auditor-scrape-btn">Phân tích</button>';
        html += '</div>';

        html += '<label class="kira-auditor-label" style="margin-top:8px;">Từ khóa mục tiêu (Focus Keyword)</label>';
        html += '<input type="text" class="kira-auditor-focus-kw" placeholder="Ví dụ: dịch vụ SEO tổng thể"/>';

        html += '<label class="kira-auditor-label" style="margin-top:8px;">Yêu cầu bổ sung (Prompt) <em style="color:#94a3b8;font-weight:400;">tùy chọn</em></label>';
        html += '<textarea class="kira-auditor-extra-prompt" rows="2" placeholder="VD: nhấn mạnh giá rẻ, thêm bảng so sánh..."></textarea>';

        html += '<button type="button" class="kira-auditor-btn kira-auditor-btn-primary kira-auditor-generate-btn" style="width:100%; margin-top:10px;">✨ Tạo dàn ý chuẩn SEO từ đối thủ</button>';
        html += '<button type="button" class="kira-auditor-btn kira-auditor-btn-ghost kira-auditor-auto-fix-btn" style="width:100%; margin-top:6px; border-color:#22c55e; color:#15803d;">🚀 AI Tự động bổ sung bài viết</button>';

        html += '<div class="kira-auditor-scrape-preview" style="display:none;">' +
            '<div class="kira-auditor-preview-title"></div>' +
            '<div class="kira-auditor-preview-meta"></div>' +
            '<div class="kira-auditor-preview-headings"></div>' +
            '<div class="kira-auditor-preview-keywords"></div>' +
            '</div>';
        html += '<div class="kira-auditor-status"></div>';
        html += '</div>';

        // ==== Tabs ====
        html += '<div class="kira-auditor-tabs">';
        html += '<button type="button" class="kira-auditor-tab kira-auditor-tab-active" data-tab="headings">📋 ' + escapeHtml(params.i18n.tab_headings) + '</button>';
        html += '<button type="button" class="kira-auditor-tab" data-tab="keywords">🎯 ' + escapeHtml(params.i18n.tab_keywords) + '</button>';
        html += '<button type="button" class="kira-auditor-tab" data-tab="score">🏆 SEO Score</button>';
        html += '</div>';

        // ==== Tab content containers ====
        html += '<div class="kira-auditor-tab-panel kira-auditor-tab-panel-active" data-panel="headings">';
        html += '<div class="kira-auditor-headings-list"></div>';
        html += '</div>';

        html += '<div class="kira-auditor-tab-panel" data-panel="keywords">';
        html += '<div class="kira-auditor-keywords-list"></div>';
        html += '</div>';

        html += '<div class="kira-auditor-tab-panel" data-panel="score">';
        html += '<div class="kira-auditor-score-list"></div>';
        html += '</div>';

        $root.html(html);
        // Đồng bộ nội dung vào modal body (nếu modal tồn tại) — tránh modal chỉ "Đang tải..."
        if ($modalBody.length && $modalBody[0] !== $root[0]) {
            $modalBody.html(html);
        }
    }

    // ================= Open/Close =================
    function openPanel() {
        // 1. Open the native <details> panel (summary body becomes visible)
        var $details = $launcher.find('details.kira-auditor-details');
        if ($details.length) {
            $details.attr('open', 'open');
        } else {
            $root.show();
        }
        // 2. Also open modal if available
        if ($modal.length) {
            $modal.removeClass('kira-auditor-modal-hidden');
        }
    }

    function closePanel() {
        // Only close modal (inline panel stays open so user can see tabs)
        if ($modal.length) {
            $modal.addClass('kira-auditor-modal-hidden');
        }
    }

    // Bind using event delegation — always works.
    // The <summary> click is handled natively by the browser; FAB & modal need JS.
    function bindLaunchers() {
        $(document).on('click', '#kira-auditor-fab', openPanel);
        $(document).on('click', '.kira-auditor-modal-close', closePanel);
        $(document).on('click', '.kira-auditor-modal-overlay', closePanel);

        // ===== Delegation cho mọi nút (hoạt động theo ping ở cả sidebar lẫn modal) =====
        // Auto-fix
        $(document).on('click', '.kira-auditor-auto-fix-btn-static, .kira-auditor-auto-fix-btn', handleAutoFix);
        // Tabs — scope TRONG container chứa nút được bấm (sidebar/modal không ảnh hưởng lẫn nhau)
        $(document).on('click', '.kira-auditor-tab', function () {
            var tab = $(this).data('tab');
            state.activeTab = tab;
            var $wrap = $(this).closest('.kira-auditor-tabs').parent();
            $wrap.find('.kira-auditor-tab').removeClass('kira-auditor-tab-active');
            $(this).addClass('kira-auditor-tab-active');
            $wrap.find('.kira-auditor-tab-panel').removeClass('kira-auditor-tab-panel-active');
            $wrap.find('.kira-auditor-tab-panel[data-panel="' + tab + '"]').addClass('kira-auditor-tab-panel-active');
        });
        // Chèn từ khóa: AI viết câu có chứa từ khóa & chèn vào bài
        $(document).on('click', '.kira-auditor-kw-insert-btn', function () {
            insertKeywordSentence($(this).data('keyword') || '', $(this));
        });
        // Scrape / Generate
        $(document).on('click', '.kira-auditor-scrape-btn', handleScrape);
        $(document).on('click', '.kira-auditor-generate-btn', handleGenerate);
        // Heading actions
        $(document).on('click', '.kira-auditor-insert-btn', function () {
            insertHeading($(this).data('heading'), $(this).data('level'), $(this));
        });
        $(document).on('click', '.kira-auditor-write-btn', function () {
            generateSectionIntro($(this).data('heading'), $(this).data('keywords') || [], $(this));
        });
        $(document).on('click', '.kira-auditor-copy-btn', function () {
            copyToClipboard($(this).data('heading') || '');
        });
        // Keyword copy
        $(document).on('click', '.kira-auditor-kw-name', function () {
            var text = $(this).text();
            copyToClipboard(text);
        });
    }

    function renderAll() {
        renderHeadingsTab();
        renderKeywordsTab();
        renderScoreTab();

        // Banner "Dàn ý đã tạo" — cập nhật NỘI DUNG (không remove+prepend lại → hết nhảy layout)
        var $info = $root.find('.kira-auditor-found-info');
        if (state.hasData && state.title) {
            if ($info.length) {
                $info.html('<strong>Dàn ý đã được tạo:</strong> ' + escapeHtml(state.title));
            } else {
                $root.find('.kira-auditor-setup').prepend(
                    '<div class="kira-auditor-found-info"><strong>Dàn ý đã được tạo:</strong> ' + escapeHtml(state.title) + '</div>'
                );
            }
        } else if ($info.length) {
            $info.remove();
        }
    }

    // ================= Tab 1: Heading Checklist =================
    function renderHeadingsTab() {
        var $container = $root.find('.kira-auditor-headings-list');
        if (!$container.length) return;

        if (!state.hasData || (!state.outlineStatus.length && !state.outline.length)) {
            $container.html(
                '<div class="kira-auditor-empty">Chưa có dàn ý. Hãy dán URL đối thủ ở trên và bấm <strong>Tạo dàn ý chuẩn SEO</strong> để bắt đầu.</div>'
            );
            return;
        }

        var items = state.outlineStatus.length ? state.outlineStatus : state.outline;
        var html = '';

        html += '<div class="kira-auditor-section-title">Dàn ý mẫu & Trạng thái bài viết</div>';

        items.forEach(function (item, idx) {
            var level = item.level || 'h2';
            var text = item.text || '';
            var status = item.status || 'missing';
            var notes = item.notes || '';
            var keywords = item.keywords || [];

            var badgeHtml = '';
            var cls = '';
            if (status === 'met') {
                cls = 'kira-auditor-status-met';
                badgeHtml = '<span class="kira-auditor-badge kira-auditor-badge-met">✓ Đã có</span>';
            } else if (status === 'partial') {
                cls = 'kira-auditor-status-partial';
                badgeHtml = '<span class="kira-auditor-badge kira-auditor-badge-partial">◐ Một phần</span>';
            } else {
                cls = 'kira-auditor-status-missing';
                badgeHtml = '<span class="kira-auditor-badge kira-auditor-badge-missing">✗ Thiếu</span>';
            }

            var kwHtml = '';
            if (keywords.length) {
                kwHtml = '<div class="kira-auditor-item-keywords">' + keywords.map(function (k) {
                    return '<span class="kira-auditor-mini-tag">' + escapeHtml(k) + '</span>';
                }).join('') + '</div>';
            }

            var notesHtml = notes ? '<div class="kira-auditor-item-notes">💡 ' + escapeHtml(notes) + '</div>' : '';

            var insertBtn = '';
            if (status !== 'met') {
                insertBtn = '<button type="button" class="kira-auditor-insert-btn" data-level="' + escapeHtml(level) + '" data-heading="' + escapeHtml(text) + '" data-index="' + idx + '">+ Chèn nhanh</button>';
                // AI section writer button (only for H2 to keep sidebar tidy)
                if (level === 'h2') {
                    var kwJson = JSON.stringify(keywords || []);
                    insertBtn += '<button type="button" class="kira-auditor-write-btn" data-heading="' + escapeHtml(text) + '" data-keywords="' + escapeHtml(kwJson) + '" data-index="' + idx + '" title="AI viết đoạn mở đầu cho mục này">✍️ Viết đoạn</button>';
                }
            }
            insertBtn += '<button type="button" class="kira-auditor-copy-btn" data-heading="' + escapeHtml(text) + '" title="Copy heading để tự dán vào bài">📋 Copy</button>';

            html += '<div class="kira-auditor-heading-item ' + cls + '">' +
                '<div class="kira-auditor-heading-row">' +
                '<span class="kira-auditor-level-tag">' + escapeHtml(level.toUpperCase()) + '</span>' +
                '<span class="kira-auditor-heading-text">' + escapeHtml(text) + '</span>' +
                badgeHtml +
                insertBtn +
                '</div>' +
                kwHtml +
                notesHtml +
                '</div>';
        });

        // Missing topics (content gap)
        if (state.missingTopics && state.missingTopics.length) {
            html += '<div class="kira-auditor-section-title" style="margin-top:16px;">🧩 Chủ đề đối thủ đang thiếu (Content Gap)</div>';
            state.missingTopics.forEach(function (topic) {
                html += '<div class="kira-auditor-gap-topic">➤ ' + escapeHtml(topic) + '</div>';
            });
        }

        // Đồng bộ cả modal body (nếu có) — tránh modal bị "Đang tải..."
        fillPanels('.kira-auditor-headings-list', html);

        // Bind insert buttons
        $container.find('.kira-auditor-insert-btn').on('click', function () {
            var heading = $(this).data('heading');
            var level = $(this).data('level');
            insertHeading(heading, level, $(this));
        });

        // Bind AI section writer buttons
        $container.find('.kira-auditor-write-btn').on('click', function () {
            var heading = $(this).data('heading');
            var keywords = $(this).data('keywords') || [];
            generateSectionIntro(heading, keywords, $(this));
        });

        // Bind copy buttons
        $container.find('.kira-auditor-copy-btn').on('click', function () {
            var heading = $(this).data('heading') || '';
            copyToClipboard(heading);
        });
    }

    // ================= Tab 2: Keyword Tracker =================
    function renderKeywordsTab() {
        var $container = $root.find('.kira-auditor-keywords-list');
        if (!$container.length) return;

        // Nguồn ưu tiên: dữ liệu track thực tế trong bài → fallback mục tiêu từ AI (chưa track)
        var items = state.keywordStatus.length ? state.keywordStatus : state.keywords;

        if (!state.hasData || !items.length) {
            var emptyHtml = '<div class="kira-auditor-empty">Chưa có danh sách từ khóa mục tiêu.<br/>Tạo dàn ý từ URL đối thủ để nhận danh sách từ khóa + tần suất đề xuất.</div>';
            // Nếu đã scrape đối thủ nhưng chưa tạo dàn ý → hiển thị gợi ý từ khóa đối thủ
            if (state.competitorKeywords && state.competitorKeywords.length) {
                emptyHtml += renderCompetitorKeywords();
            }
            $container.html(emptyHtml);
            fillPanels('.kira-auditor-keywords-list', emptyHtml);
            return;
        }

        var metCount = 0;
        var partialCount = 0;
        var missingCount = 0;
        var untrackedCount = 0;
        var itemsHtml = '';

        items.forEach(function (kw) {
            var keyword = kw.keyword || '';
            var count = typeof kw.count === 'number' ? kw.count : 0;
            var recommended = parseInt(kw.recommended_freq, 10) || 1;
            if (recommended < 1) recommended = 1;
            var status = kw.status || 'missing';
            var places = kw.suggested_places || [];
            var isTracked = kw.tracked === true;

            var badgeClass = 'kira-auditor-badge-missing';
            var badgeText = 'Chưa dùng';
            var countText = count + '/' + recommended;
            var progressPct = 0;
            var progressHtml = '';

            if (isTracked) {
                // Dữ liệu thực tế đã đếm trong bài viết
                if (status === 'met') {
                    badgeClass = 'kira-auditor-badge-met';
                    badgeText = '✓ Đủ';
                    metCount++;
                } else if (status === 'partial') {
                    badgeClass = 'kira-auditor-badge-partial';
                    badgeText = '◐ Đang viết';
                    partialCount++;
                } else {
                    missingCount++;
                }
                progressPct = Math.min(100, Math.round((count / recommended) * 100));
                progressHtml = '<div class="kira-auditor-progress"><div style="width:' + progressPct + '%"></div></div>';
            } else {
                // Mục tiêu từ AI chưa track trong bài viết → không đoán trạng thái
                badgeClass = 'kira-auditor-badge-partial';
                badgeText = '⏳ Chờ viết bài';
                countText = '— / ' + recommended;
                untrackedCount++;
            }

            var placesHtml = '';
            if (places && places.length) {
                placesHtml = '<div class="kira-auditor-kw-places">' + places.map(function (p) {
                    return '<span>' + escapeHtml(p) + '</span>';
                }).join('') + '</div>';
            }

            itemsHtml += '<div class="kira-auditor-kw-item">' +
                '<div class="kira-auditor-kw-row">' +
                '<span class="kira-auditor-kw-name" title="Click để copy từ khóa">' + escapeHtml(keyword) + '</span>' +
                '<span class="kira-auditor-kw-count">' + countText + '</span>' +
                '<span class="kira-auditor-badge ' + badgeClass + '">' + badgeText + '</span>' +
                '<button type="button" class="kira-auditor-kw-insert-btn" data-keyword="' + escapeHtml(keyword) + '" title="AI viết câu có chứa từ khóa này và chèn vào bài">✚ Chèn từ khóa</button>' +
                '</div>' +
                progressHtml +
                placesHtml +
                '</div>';
        });

        // Kết hợp HTML theo thứ tự: Tiêu đề → Summary → Danh sách từ khóa → Gợi ý đối thủ
        var html = '';
        html += '<div class="kira-auditor-section-title">Từ khóa mục tiêu & Tần suất đề xuất</div>';

        var summaryParts = [];
        if (metCount + partialCount + missingCount > 0) {
            summaryParts.push('✓ Đủ <strong>' + metCount + '</strong>');
            summaryParts.push('◐ Đang viết <strong>' + partialCount + '</strong>');
            summaryParts.push('✗ Thiếu <strong>' + missingCount + '</strong>');
        }
        if (untrackedCount > 0) {
            summaryParts.push('⏳ Chờ viết bài <strong>' + untrackedCount + '</strong>');
        }
        if (summaryParts.length) {
            html += '<div class="kira-auditor-kw-summary">' + summaryParts.join(' · ') + '</div>';
        }

        html += itemsHtml;

        // Từ khóa đối thủ đã scrape (gợi ý bổ sung)
        if (state.competitorKeywords && state.competitorKeywords.length) {
            html += renderCompetitorKeywords();
        }

        // Đồng bộ cả modal body (nếu có)
        fillPanels('.kira-auditor-keywords-list', html);

        // Click keyword to copy
        $container.find('.kira-auditor-kw-name').on('click', function () {
            var text = $(this).text();
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(function () {
                    showToast('Đã copy từ khóa: ' + text, 'success');
                }).catch(function () { legacyCopy(text); });
            } else {
                legacyCopy(text);
            }
        });
    }

    /**
     * Render danh sách từ khóa đối thủ đã phân tích (dạng tag, chỉ để tham khảo).
     */
    function renderCompetitorKeywords() {
        var kws = state.competitorKeywords || [];
        if (!kws.length) return '';
        var html = '<div class="kira-auditor-section-title" style="margin-top:14px;">🔍 Từ khóa đối thủ đang dùng (gợi ý)</div>';
        html += '<div class="kira-auditor-competitor-kws">' + kws.slice(0, 12).map(function (k) {
            return '<span class="kira-auditor-mini-tag">' + escapeHtml(k.keyword) + '</span>';
        }).join('') + '</div>';
        html += '<div class="kira-auditor-preview-empty">Đây là gợi ý từ nội dung đối thủ — dàn ý AI sẽ chọn lọc các từ khóa thực sự phù hợp với bài viết của bạn.</div>';
        return html;
    }

    // ================= Tab 3: SEO Score =================
    function renderScoreTab() {
        var $container = $root.find('.kira-auditor-score-list');
        if (!$container.length) return;

        if (!state.hasData) {
            $container.html(
                '<div class="kira-auditor-empty">Tạo dàn ý từ URL đối thủ để xem <strong>điểm SEO tổng thể</strong> cho bài viết của bạn.</div>'
            );
            return;
        }

        var score = state.score;
        if (!score) {
            $container.html(
                '<div class="kira-auditor-empty">Đang tính điểm... vui lòng chờ một chút.</div>'
            );
            return;
        }

        var scoreVal = score.score || 0;

        // Color based on score
        var scoreColor = '#ef4444';
        var scoreLabel = 'Cần cải thiện';
        if (scoreVal >= 80) {
            scoreColor = '#22c55e';
            scoreLabel = 'Rất tốt';
        } else if (scoreVal >= 60) {
            scoreColor = '#f59e0b';
            scoreLabel = 'Khá';
        } else if (scoreVal >= 40) {
            scoreColor = '#f97316';
            scoreLabel = 'Trung bình';
        }

        var r = 20;
        var c = 2 * Math.PI * r;
        var offset = c - ((scoreVal / 100) * c);

        var html = '';
        html += '<div class="kira-auditor-score-hero">';
        html += '<svg viewBox="0 0 52 52" class="kira-auditor-score-ring">' +
            '<circle class="bg" cx="26" cy="26" r="20" fill="none" stroke="#e2e8f0" stroke-width="5"/>' +
            '<circle class="fg" cx="26" cy="26" r="20" fill="none" stroke="' + scoreColor + '" stroke-width="5" stroke-dasharray="' + c + '" stroke-dashoffset="' + offset + '" stroke-linecap="round"/>' +
            '</svg>';
        html += '<div class="kira-auditor-score-number" style="color:' + scoreColor + ';">' + scoreVal + '</div>';
        html += '<div class="kira-auditor-score-label" style="color:' + scoreColor + ';">' + scoreLabel + '</div>';
        html += '</div>';

        // Word count CTA
        if (score.needs_more_words && score.needs_more_words > 0) {
            html += '<div class="kira-auditor-score-cta">📝 Cần thêm <strong>~' + score.needs_more_words + ' từ</strong> để đạt độ dài khuyến nghị.</div>';
        } else if (score.word_count && score.word_count > 0) {
            html += '<div class="kira-auditor-score-cta kira-auditor-score-cta-ok">✅ Đạt độ dài khuyến nghị: ' + score.word_count + ' từ.</div>';
        }

        // Checklist
        html += '<div class="kira-auditor-score-checklist">';
        if (score.items && score.items.length) {
            score.items.forEach(function (item) {
                var ok = item.status === 'met';
                var icon = ok ? '✅' : '⚠️';
                var cls = ok ? 'kira-auditor-score-item-ok' : 'kira-auditor-score-item-warn';
                html += '<div class="kira-auditor-score-item ' + cls + '">' +
                    '<span class="kira-auditor-score-item-icon">' + icon + '</span>' +
                    '<div class="kira-auditor-score-item-body">' +
                    '<div class="kira-auditor-score-item-label">' + escapeHtml(item.label) + '</div>' +
                    '<div class="kira-auditor-score-item-detail">' + escapeHtml(item.detail || '') + '</div>' +
                    '</div>' +
                    '</div>';
            });
        }
        html += '</div>';

        fillPanels('.kira-auditor-score-list', html);
    }

    // ================= Generate Section Intro (AI Writer) =================
    function generateSectionIntro(heading, keywords, $btn) {
        var focusKw = saFind('.kira-auditor-focus-kw', $btn.closest('.kira-auditor-setup')).val() || state.focusKeyword || '';
        if (!focusKw) {
            showToast('Vui lòng nhập từ khóa mục tiêu trước.', 'error');
            return;
        }

        $btn.prop('disabled', true).html('<span class="kira-auditor-spin"></span> Đang viết...');

        doAjax('kira_sa_auditor_generate_section', {
            focus_keyword: focusKw,
            heading: heading,
            keywords: keywords || []
        }, function (data) {
            $btn.prop('disabled', false).text('✍️ Viết đoạn');
            if (data && data.html) {
                insertHtmlIntoEditor(data.html);
            } else {
                showToast('AI trả về nội dung trống. Vui lòng thử lại.', 'error');
            }
        }, function (msg) {
            $btn.prop('disabled', false).text('✍️ Viết đoạn');
            showToast(msg, 'error');
        });
    }

    /**
     * Insert raw HTML into the editor (support Gutenberg + Classic).
     */
    function insertHtmlIntoEditor(html) {
        var currentContent = getEditorContent();
        var newContent = currentContent ? currentContent + '\n\n' + html + '\n\n' : html;

        var pushed = pushContentToEditor(newContent);

        if (pushed) {
            showToast('Đã chèn đoạn văn mẫu vào bài viết.', 'success');
            setTimeout(refreshStatus, 300);
        } else {
            showToast('Không thể chèn vào trình soạn thảo.', 'error');
        }
    }

    // ================= Insert Keyword Sentence (AI) =================
    /**
     * AI viết 1 câu tự nhiên có chứa từ khóa → chèn vào cuối bài viết.
     */
    function insertKeywordSentence(keyword, $btn) {
        if (!keyword) {
            showToast('Thiếu từ khóa cần chèn.', 'error');
            return;
        }
        var focusKw = state.focusKeyword || saFind('.kira-auditor-focus-kw').val() || '';

        $btn.prop('disabled', true).html('<span class="kira-auditor-spin"></span> Đang viết...');

        doAjax('kira_sa_auditor_generate_keyword_sentence', {
            keyword: keyword,
            focus_keyword: focusKw
        }, function (data) {
            $btn.prop('disabled', false).html('✚ Chèn từ khóa');
            if (data && data.html) {
                insertHtmlIntoEditor(data.html);
            } else {
                showToast('AI trả về nội dung trống. Vui lòng thử lại.', 'error');
            }
        }, function (msg) {
            $btn.prop('disabled', false).html('✚ Chèn từ khóa');
            showToast(msg, 'error');
        });
    }

    // ================= Scrape Handler (multi-URL) =================
    function handleScrape() {
        var $setup = $(this).closest('.kira-auditor-setup');
        var raw = saFind('.kira-auditor-url', $setup).val() || '';
        var urls = raw.split('\n').map(function (u) {
            return $.trim(u);
        }).filter(function (u) {
            return u.length > 0;
        });

        if (!urls.length) {
            showStatus(params.i18n.no_url, 'error');
            return;
        }
        // Cap at 5 URLs
        if (urls.length > 5) {
            urls = urls.slice(0, 5);
            showStatus('Chỉ phân tích tối đa 5 URL đối thủ. Đã lấy 5 URL đầu tiên.', 'info');
        }

        var $btn = $(this);
        if (!$btn.is('.kira-auditor-scrape-btn')) $btn = saFind('.kira-auditor-scrape-btn', $setup);
        $btn.prop('disabled', true).text('Đang phân tích ' + urls.length + ' URL...');
        showStatus(params.i18n.scraping, 'loading');

        doAjax('kira_sa_auditor_scrape_urls', { urls: urls }, function (data) {
            $btn.prop('disabled', false).text('Phân tích');

            // Store merged competitor data in state for generate step
            state.competitor = {
                title: data.title,
                meta_description: data.meta_description,
                headings: data.headings,
                sources_count: data.sources_count || 1,
                word_count: data.word_count || 0
            };
            state.competitorKeywords = data.keywords || [];

            // Render preview (cả sidebar lẫn modal)
            var $preview = saFind('.kira-auditor-scrape-preview');
            $preview.show();
            var $previewM = $modalBody.find('.kira-auditor-scrape-preview');
            if ($previewM.length && $modalBody[0] !== $root[0]) $previewM.show();

            var srcCount = data.sources_count || 1;
            var headingHtml = '<div class="kira-auditor-preview-label">Cấu trúc Heading đã merge từ ' + srcCount + ' nguồn (' + (data.headings || []).length + ' heading)</div>';
            if (data.headings && data.headings.length) {
                headingHtml += data.headings.slice(0, 18).map(function (h) {
                    var srcTag = h.sources && h.sources > 1 ? ' <span class="kira-auditor-mini-tag" style="background:#dcfce7;color:#15803d;border-color:#bbf7d0;">' + h.sources + ' nguồn</span>' : '';
                    return '<div class="kira-auditor-preview-h"><span class="kira-auditor-level-tag">' + escapeHtml(h.level.toUpperCase()) + '</span> ' + escapeHtml(h.text) + srcTag + '</div>';
                }).join('');
            } else {
                headingHtml += '<div class="kira-auditor-preview-empty">Không tìm thấy heading</div>';
            }

            var kwHtml = '<div class="kira-auditor-preview-label" style="margin-top:10px;">Từ khóa & thực thể quan trọng (Top ' + (data.keywords || []).length + ')</div>';
            if (data.keywords && data.keywords.length) {
                kwHtml += '<div class="kira-auditor-preview-kws">' + data.keywords.slice(0, 12).map(function (k) {
                    return '<span class="kira-auditor-mini-tag">' + escapeHtml(k.keyword) + '</span>';
                }).join('') + '</div>';
            } else {
                kwHtml += '<div class="kira-auditor-preview-empty">Sử dụng heading merge + từ khóa mục tiêu để tạo dàn ý</div>';
            }

            $preview.find('.kira-auditor-preview-title').html('<strong>Phân tích ' + srcCount + ' đối thủ:</strong> ' + escapeHtml(data.title || 'Không có tiêu đề'));
            $preview.find('.kira-auditor-preview-meta').html(
                '<span class="kira-auditor-mini-tag">📊 Độ dài trung bình ~' + (data.word_count || 1800) + ' từ</span>' +
                (data.meta_description ? ' ' + escapeHtml(data.meta_description) : '')
            );
            $preview.find('.kira-auditor-preview-headings').html(headingHtml);
            $preview.find('.kira-auditor-preview-keywords').html(kwHtml);

            showStatus('Phân tích ' + srcCount + ' đối thủ thành công! Nhập từ khóa mục tiêu rồi bấm <strong>✨ Tạo dàn ý chuẩn SEO</strong>.', 'success');
        }, function (msg) {
            $btn.prop('disabled', false).text('Phân tích');
            showStatus(msg, 'error');
        });
    }

    // ================= Generate Outline Handler =================
    function handleGenerate() {
        var $setup = $(this).closest('.kira-auditor-setup');
        var focusKw = $.trim(saFind('.kira-auditor-focus-kw', $setup).val());
        if (!focusKw) {
            showStatus(params.i18n.no_kw, 'error');
            return;
        }

        // Ensure competitor data exists
        if (!state.competitor || (!state.competitor.title && (!state.competitor.headings || !state.competitor.headings.length))) {
            showStatus('Hãy phân tích URL đối thủ trước khi tạo dàn ý.', 'error');
            return;
        }

        var extraPrompt = $.trim(saFind('.kira-auditor-extra-prompt', $setup).val());

        var $btn = $(this);
        if (!$btn.is('.kira-auditor-generate-btn')) $btn = saFind('.kira-auditor-generate-btn', $setup);
        $btn.prop('disabled', true).html('<span class="kira-auditor-spin"></span> AI đang tạo dàn ý...');
        showStatus(params.i18n.generating, 'loading');

        doAjax('kira_sa_auditor_generate_outline', {
            focus_keyword: focusKw,
            extra_prompt: extraPrompt,
            competitor: state.competitor,
            competitor_keywords: state.competitorKeywords || []
        }, function (data) {
            $btn.prop('disabled', false).html('✨ Tạo dàn ý chuẩn SEO từ đối thủ');

            // Update state — KHÔNG ghi đè keywordStatus (giữ số liệu track thực tế cũ)
            // để tránh hiển thị "⏳ Chờ viết bài" tạm thời trước khi refreshStatus chạy.
            state.hasData = true;
            state.title = data.title || '';
            state.outline = data.outline || [];
            state.outlineStatus = data.outline || []; // will be refreshed via live monitor
            state.keywords = data.target_keywords || [];
            // Giữ nguyên keywordStatus nếu đã có dữ liệu track, nếu không thì dùng mục tiêu từ AI
            if (!state.keywordStatus || !state.keywordStatus.length) {
                state.keywordStatus = data.target_keywords || [];
            }
            state.missingTopics = data.missing_topics || [];
            state.focusKeyword = focusKw;
            if (state.competitor && state.competitor.word_count) {
                state.recommendedWordCount = state.competitor.word_count;
            }

            renderAll();

            // Refresh with live content
            refreshStatus();

            showStatus('✅ Dàn ý đã sẵn sàng! <strong>Viết bài tại khung soạn thảo lớn bên phải.</strong> Quay lại tab Heading Checklist để xem trạng thái. Bấm <strong>+ Chèn nhanh</strong> ở heading đang Đỏ để thêm ngay vào bài.', 'success');
        }, function (msg) {
            $btn.prop('disabled', false).html('✨ Tạo dàn ý chuẩn SEO từ đối thủ');
            showStatus(msg, 'error');
        });
    }

    // ================= Insert Heading (Client-side) =================
    /**
     * Append a heading to editor content, supporting both Gutenberg
     * block markup and classic/raw HTML content.
     *
     * @param {string} content     Current editor HTML content.
     * @param {string} headingText Heading text (unescaped).
     * @param {string} level       h1|h2|h3|h4.
     * @return {string} New content with heading appended.
     */
    function appendHeadingToContent(content, headingText, level) {
        content = content || '';

        var levelNum = parseInt(String(level || 'h2').replace('h', ''), 10);
        if (isNaN(levelNum) || levelNum < 1 || levelNum > 4) {
            levelNum = 2;
        }

        var html = '<h' + levelNum + '>' + headingText + '</h' + levelNum + '>';
        var trimmed = $.trim(content);

        // Gutenberg block markup detected → insert a proper heading block
        if (content.indexOf('<!-- wp:') !== -1) {
            var block = '\n<!-- wp:heading {"level":' + levelNum + '} -->\n' + html + '\n<!-- /wp:heading -->\n';
            return trimmed ? trimmed + block : block;
        }

        // Classic / raw HTML content
        return trimmed ? trimmed + '\n\n' + html + '\n\n' : html;
    }

    function insertHeading(heading, level, $btn) {
        $btn.prop('disabled', true);

        // 1. Build new content from the live editor state
        var currentContent = getEditorContent();
        var newContent = appendHeadingToContent(currentContent, heading, level);

        // 2. Push through the unified API (Gutenberg → TinyMCE → textarea)
        var pushed = pushContentToEditor(newContent);

        if (!pushed) {
            $btn.prop('disabled', false);
            showToast('Không thể chèn heading vào trình soạn thảo.', 'error');
            return;
        }

        $btn.prop('disabled', false);
        showToast(params.i18n.inserted, 'success');

        // 3. Refresh audit status after a short delay so the editor store has updated
        setTimeout(refreshStatus, 300);
    }

    // ================= Auto-Fix Handler =================
    function handleAutoFix() {
        var $btn = $(this);
        if (!$btn.is('.kira-auditor-auto-fix-btn')) {
            $btn = saFind('.kira-auditor-auto-fix-btn');
        }
        $btn.prop('disabled', true).html('<span class="kira-auditor-spin"></span> AI đang bổ sung...');

        var content = getEditorContent();

        doAjax('kira_sa_auditor_auto_fix', { content: content }, function (data) {
            $btn.prop('disabled', false).html('🚀 AI Tự động bổ sung bài viết');

            var pushed = false;
            if (data && data.html_append) {
                var newContent = content + '\n\n' + data.html_append;
                pushed = pushContentToEditor(newContent);
            }

            if (pushed) {
                showToast('✅ Đã bổ sung ' + (data.added_headings || 0) + ' heading + ' + (data.ai_sections || 0) + ' đoạn AI vào bài viết. Hãy cuộn xuống cuối để xem!', 'success');
                setTimeout(refreshStatus, 500);
            } else {
                showToast('Không thể chèn vào trình soạn thảo.', 'error');
            }
        }, function (msg) {
            $btn.prop('disabled', false).html('🚀 AI Tự động bổ sung bài viết');
            showToast(msg, 'error');
        });
    }

    // ================= Editor mode detection =================
    function detectEditorMode() {
        if (window.wp && window.wp.data && wp.data.select('core/editor')) {
            return '🟦 Gutenberg Editor';
        }
        if (typeof window.tinymce !== 'undefined' && window.tinymce.get('content')) {
            return '📝 Classic Editor (Visual)';
        }
        if ($('#content').length) {
            return '📝 Classic Editor';
        }
        return 'Unknown';
    }

    // ================= Live Monitor =================
    var liveTimer = null;

    function startLiveMonitor() {
        if (liveTimer) {
            clearInterval(liveTimer);
        }
        // Interval dự phòng THƯA (15 giây) — chỉ để bù trừ nếu editor không fire event.
        // Không còn poll 2 giây/lần → giảm tải AJAX đáng kể.
        liveTimer = setInterval(function () {
            if (state.loading) return;
            var content = getEditorContent();
            if (content !== lastMonitoredContent) {
                lastMonitoredContent = content;
                refreshStatus();
            }
        }, 15000);

        // Lắng nghe thay đổi Gutenberg → refresh ngay khi có thay đổi
        if (window.wp && window.wp.data && wp.data.subscribe) {
            var lastContent = getEditorContent();
            wp.data.subscribe(function () {
                var content = getEditorContent();
                if (content !== lastContent) {
                    lastContent = content;
                    lastMonitoredContent = content;
                    debouncedRefreshStatus();
                }
            });
        }

        // Classic editor: listen to input events
        $(document).on('input', '#content', function () {
            lastMonitoredContent = getEditorContent();
            debouncedRefreshStatus();
        });
    }

    var lastMonitoredContent = '';
    var debouncedRefreshStatus = debounce(refreshStatus, 1200);

    function refreshStatus() {
        if (state.loading) return;
        state.loading = true;

        var content = getEditorContent();

        doAjax('kira_sa_auditor_refresh_status', { content: content }, function (data) {
            state.outlineStatus = data.outline_status || state.outlineStatus;
            state.keywordStatus = data.keyword_status || state.keywordStatus;
            state.score = data.score || state.score;
            state.loading = false;
            renderHeadingsTab();
            renderKeywordsTab();
            renderScoreTab();
        }, function () {
            state.loading = false;
        });
    }

    // ================= Status / Toast =================
    function showStatus(msg, type) {
        var cls = 'kira-auditor-status-info';
        if (type === 'success') cls = 'kira-auditor-status-success';
        if (type === 'error') cls = 'kira-auditor-status-error';
        if (type === 'loading') cls = 'kira-auditor-status-loading';
        var $status = $root.find('.kira-auditor-status');
        if ($status.length) $status.attr('class', 'kira-auditor-status ' + cls).html(msg);
        if ($modalBody.length && $modalBody[0] !== $root[0]) {
            var $statusM = $modalBody.find('.kira-auditor-status');
            if ($statusM.length) $statusM.attr('class', 'kira-auditor-status ' + cls).html(msg);
        }
    }

    function showToast(message, type) {
        $('.kira-auditor-toast').remove();
        var icon = '';
        if (type === 'success') {
            icon = '<span class="dashicons dashicons-yes" style="color:#22c55e;"></span>';
        } else if (type === 'error') {
            icon = '<span class="dashicons dashicons-warning" style="color:#ef4444;"></span>';
        } else {
            icon = '<span class="dashicons dashicons-update spin" style="color:#ea580c;"></span>';
        }
        var $toast = $('<div class="kira-auditor-toast kira-auditor-toast-' + (type || 'info') + '">' + icon + '<span>' + escapeHtml(message) + '</span></div>');
        $('body').append($toast);
        $toast.each(function () { this.offsetHeight; });
        $toast.addClass('kira-auditor-toast-show');
        if (type !== 'loading') {
            setTimeout(function () {
                $toast.removeClass('kira-auditor-toast-show');
                setTimeout(function () { $toast.remove(); }, 300);
            }, 3500);
        }
    }

    // ================= Copy heading to clipboard (fallback) =================
    function copyToClipboard(text) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(function () {
                showToast('Đã copy heading vào clipboard. Dán (Ctrl+V) vào vị trí bất kỳ trong bài viết.', 'success');
            }).catch(function () { legacyCopy(text); });
        } else {
            legacyCopy(text);
        }
    }

    function legacyCopy(text) {
        var $tmp = $('<textarea>').val(text).appendTo('body').select();
        try {
            document.execCommand('copy');
            showToast('Đã copy heading vào clipboard. Dán (Ctrl+V) vào bài viết.', 'success');
        } catch (e) {
            showToast('Không copy được. Hãy bôi đen heading và bấm Ctrl+C.', 'error');
        }
        $tmp.remove();
    }

    // ================= Boot =================
    bindLaunchers();
    init();
});
