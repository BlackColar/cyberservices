<?php
/**
 * Uninstall - AI Sales Assistant Chatbox
 * Dọn sạch DB & options khi xóa plugin khỏi WordPress.
 *
 * Chỉ chạy khi người dùng xóa plugin từ trang quản trị WP.
 * (WordPress sẽ định nghĩa hằng số WP_UNINSTALL_PLUGIN khi gọi file này)
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

global $wpdb;

$table_leads = $wpdb->prefix . 'ai_chat_leads';
$table_chats = $wpdb->prefix . 'ai_chat_history';
$table_views = $wpdb->prefix . 'ai_chat_page_views';

// Xóa bảng dữ liệu
$wpdb->query("DROP TABLE IF EXISTS $table_views");
$wpdb->query("DROP TABLE IF EXISTS $table_chats");
$wpdb->query("DROP TABLE IF EXISTS $table_leads");

// Xóa các option cài đặt
$options = [
    'ai_chat_provider',
    'ai_chat_api_key',
    'ai_chat_kira_base_url',
    'ai_chat_model',
    'ai_chat_system_prompt',
    'ai_chat_custom_knowledge',
    'ai_chat_telegram_token',
    'ai_chat_telegram_chat_id',
    'ai_chat_max_tokens',
    'ai_chat_tracking_enabled',
    'ai_chat_target_keywords',
    'ai_chat_onsite_timeout',
    'ai_chat_db_version',
];

foreach ($options as $opt) {
    delete_option($opt);
}

// Xóa các transient liên quan
delete_transient('ai_chat_posts_cache');
$wpdb->query(
    "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_ai_lead_%' OR option_name LIKE '_transient_ai_rate_limit_%' OR option_name LIKE '_transient_ai_chat_target_flag_%' OR option_name LIKE '_transient_ai_chat_onsite_%'"
);
